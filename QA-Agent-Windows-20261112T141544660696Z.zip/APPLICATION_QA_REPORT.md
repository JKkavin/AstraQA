# AI QA Agent application report

Updated: 12 November 2026.

Transfer readiness: maintained documentation and saved-suite READMEs now link to the company-laptop guide. `scripts/prepare_transfer.py` creates a source ZIP, manifest/hashes, and consistent usage backup while excluding credentials, raw browser evidence, downloaded reports, caches, and machine-specific state. Pinned dependencies match the working environment and `pip check` passes. The setup script checks Python 3.11 64-bit, installs dependencies/Chromium, initializes private settings, and writes a local verification report. Destination RMM/VPN access remains a separate baseline check.

A fresh extracted package, initialized without a real API key, passed **132 local tests** using the existing working interpreter/dependencies. This checks package completeness and portable source paths; it does not claim a fresh install or live destination-network validation. See `reports/TRANSFER_PACKAGE_REPORT.md` and the ten-step quick start.

## Dashboard and workflows

Saved replay wait correction: generation now emits readiness calls before every step and persists a versioned `wait_policy` in suite configuration. Shared execution waits for the next actionable control and asynchronously loaded dropdown option using bounded readiness windows, while saved-pytest instrumentation uses native waits without AI. Discovery retains AI-assisted waiting. Old shared-executor suites benefit without regenerating or overwriting reviewed source. The same generated script passed three progressively slower local runs, and the existing RMM suite passed two fresh-browser reruns, each saving a nonempty 34,675-byte report without AI wait decisions.

RMM report workflow now supports one end-to-end case with a nonempty-download final outcome. Discovery repair is visible beside discovery cases; saved-test AI healing and rerun options are visible under Saved regression suites. Browser closure is runner-owned, terminal verified outcomes avoid an extra model call, synthetic negative-login values are explicitly permitted, and single-case draft planning rejects split results. Download metadata from child pytest runs is returned to the dashboard. A live `rmm_audit360` test passed with all requested filters, healing enabled, and a valid 34,675-byte XLSX. The final optimized run used zero AI calls; 128 local regression tests passed. See `reports/RMM_COMPLETION_REPORT.md` for reports, costs, and limitations.

The primary dashboard workflow is now website-first discovery. `POST /qa/discover-suite` accepts up to ten independent scenarios with explicit expected visible text. It discovers each in a fresh browser, requires the requested final assertion, and saves a separate pytest function for each only when all scenarios pass. Generated suites receive unique names, preserving existing suites. The report labels discovery separately from subsequent pytest replay. Requirement-based draft generation and single-task exploration remain available as alternatives.

Verification: 120 regression tests passed, including a real local discovery-to-generated-pytest replay with two independent passing cases. Dashboard HTTP, JavaScript, case-template, and mobile-overflow checks passed after relaunch. This verification used mocked AI planning without paid API requests; the new five-case OrangeHRM template remains ready for a user-initiated live discovery run.

The FastAPI application serves a responsive dashboard with navigation for planning, browser testing, report validation, knowledge documents, and settings. Local access through `127.0.0.1`, `localhost`, or IPv6 loopback does not require entering an API token. Remote requests require `QA_API_TOKEN`; setting `QA_ALLOW_LOCAL_NO_TOKEN=false` requires it locally as well. Token-free browser requests must be same-origin, and the normal launch script disables proxy-header interpretation.

Build a test plan generates application-specific pytest sources, case data, Page Objects, and configuration under `generated_suites/`. Review generated selectors and assertions before running them. Generating a new plan for the same application rewrites that suite; retain manual changes separately if regenerating it.

Inspect a test page discovers controls and executes the requested bounded workflow. It is separate from generated pytest execution. Saved credentials are resolved locally only for explicitly requested sign-in actions and are not sent to the model. Chromium stays visible and can remain open for review; use Close browser to end its session.

Run this regression suite executes the selected saved application suite. Run project tests executes only `tests/`, including deterministic browser regression checks. Result-producing dashboard actions run one at a time, clear previous output, and restore controls after failures. Pytest writes unique HTML and JUnit XML reports; per-test rows and counts are read from the current XML, including setup errors and skipped cases.

## Knowledge, models, and report validation

PDF documents can provide retrieved context for planning and analysis. Ollama embeddings use ChromaDB storage with a TF-IDF fallback. Gemini uses the configured model order and bounded requests; Ollama requests also have bounded timeouts. Provider errors are reported rather than treated as successful test evidence.

Report validation compares CSV, TSV, XLSX, or JSON against another file or configured parameterized SQL Server/Databricks queries. It reports missing records, duplicate keys, schema differences, and value mismatches. It does not send report rows to the model. File downloads and query credentials remain local. Runtime limits and defaults are configurable in Application settings.

Optional integrations include the stdio MCP interface and n8n workflow/Docker Compose files.

## Verification

The latest full application suite passed 101 tests, including request lifecycle, report parsing, local access controls, browser discovery, and report comparison. Earlier application-endpoint verification showed 84 passed; the final expanded suite now passes 101 tests. The five live OrangeHRM workflows passed again: valid login, invalid-login error, dashboard access, employee search, and logout. The reviewed OrangeHRM test searches an existing record selected at runtime and uses only the public demo credentials displayed on that site.

See `DEBUG_VERIFICATION.md` for evidence and practical limits. Live database servers were not exercised; connector behavior was tested with mocks. Previously saved application suites are retained, but this update does not claim that every historical suite was rerun. The shared executor has no built-in application-specific login or logout selectors.


## OpenAI trial integration

The selected provider is now OpenAI with `gpt-6.1-terra`. Activation requires a funded API account and `OPENAI_API_KEY` in the private `.env`; missing keys produce an actionable error and do not invoke another provider. The Responses API uses strict structured outputs, low reasoning effort, bounded text-only requests, and no automatic paid retries. Existing action and suite validators remain in use.

A private SQLite usage ledger provides cross-process atomic reservations, reported input/output/cached token accounting, and estimated charges. The trial defaults to $4.50 lifetime application spending and $0.10 reserved maximum per call. Uncertain calls keep their reservations. The dashboard exposes activation status and usage through the protected `/qa/ai/usage` endpoint. This is app-local tracking and not a provider account-balance query. INR is illustrative, and other applications' usage and taxes are excluded.

Gemini and Ollama remain optional providers. The reviewed OrangeHRM suite remains executable without paid AI calls. See README for phone activation and budget details; live OpenAI quality and billing access are pending until a key is supplied.


## Explicit recovery and diagnosis

DOM inspection now includes associated labels, stable test IDs, and disabled state; native button captions are captured correctly. The discovery result exposes DOM inspection counts, exact-semantic locator repair evidence, and failure classification. Locator repair is limited to unambiguous fresh DOM candidates and retains the original failure. It does not rewrite arbitrary saved suites or blindly replay dispatched clicks.

Saved-suite execution accepts an explicit `auto_rerun` option, default false. One retry is permitted for verified failed pytest node IDs with transient navigation, network, or browser-closure symptoms. Passing tests are not rerun. The original and retry reports are both linked, original failed evidence is retained, and recovered cases are marked FLAKY with PASS_WITH_RETRY overall. Assertion/configuration/locator failures and suite timeouts do not receive automatic retries. Deterministic diagnosis never claims a proven application root cause from symptoms alone.


## Saved-test AI healing pipeline

The agent now captures saved pytest failure screenshots, DOM metadata, and supported failed locator/source identity through a subprocess pytest plugin. Reviewed repeat-safe tests may explicitly opt in to OpenAI locator repair. A proposal is restricted to one observed semantic candidate; the engine validates intent, source hashes, literal locator edits, and unchanged assertion ASTs. The retry executes only failed cases once in an isolated suite copy, then validates the candidate again before dispatch.

Original files are not permanently changed. Repair-assisted successes are HEALED/PASS_AFTER_HEALING, with initial errors and both run reports retained. A combined final report includes screenshots, DOM records, proposal review information, and measured proposal usage. Complex/dynamic locators and unreviewed workflows require manual intervention.

Existing suites can be listed and run without regeneration using the dashboard selector or GET /qa/suites. Enrollment is explicit in suite_config.json and defaults off for new plans. See EXPERT_QA_WORKFLOW.md for operating limits and the live local demonstration.
# Adaptive page waiting update

Page readiness now uses document state, visible content, and loading indicators before actions. Persistent loading can receive a bounded AI wait-or-stop decision from redacted page evidence. Condition checks end waits early, and fresh readiness is checked after the model responds. Existing task/suite limits and API accounting remain enforced. Decision evidence is available in the dashboard and combined reports. Verification: 111 full-suite regressions passed, plus 11 final readiness checks passed using mocked AI and local pages. This is bounded adaptive waiting, not a guarantee that every site or timeout can recover.

