# Company laptop — quick start

Updated 12 November 2026. Full details: [transfer guide](TRANSFER_TO_COMPANY_LAPTOP.md).

1. Ask IT for company-approved **Python 3.11.x, 64-bit, with the Python launcher** on a supported Windows 11 x64 laptop. Keep your company VPN available. PyCharm, Docker, Node.js, Ollama, and Gemini are not needed for the current OpenAI/RMM workflow.
2. Copy the prepared **QA-Agent-Windows-...zip** and matching checksum from `transfer/` using an approved method. It includes source, saved suites, documents, and usage accounting, but excludes real keys/passwords, downloaded reports, and temporary data.
3. Extract into a writable folder, preferably a short path such as `C:\QAAgent`. Open the folder containing `setup_company_laptop.cmd`.
4. Check `py -3.11 --version` in Command Prompt. It must show Python 3.11.x.
5. Double-click **setup_company_laptop.cmd**. Wait for **Setup and local tests passed**. It installs Python dependencies and Playwright Chromium automatically and writes `reports/company-setup-check.html`.
6. Open the generated **.env** in a text editor. Set `LLM_PROVIDER=openai`, your permitted `OPENAI_API_KEY`, and the authorized RMM `QA_USERNAME` / `QA_PASSWORD`. Keep the existing model/budget defaults and generated workspace token. Enter actual secrets locally; do not send them in chat.
7. Keep the included **usage/** folder to preserve spending history. Restore private runtime settings/PDFs/database configuration separately only if needed. Never copy the old `.venv`.
8. Connect to company VPN if required. Double-click **start_qa_agent.cmd** and leave that window open. Wait for server startup.
9. Open **http://127.0.0.1:8000/**. Check OpenAI is selected and the usage totals are carried over.
10. Click **Load saved suites → rmm_audit360 → Run selected suite**. Start with a clean baseline; enable **AI locator healing for reviewed saved tests** when you want its controlled repair behavior. Review the final report and **Save file** action.

The application code/features are the same, but network access, credentials, permissions, and report availability must be verified on the company laptop. The setup checks local behavior; the RMM baseline verifies destination access. Saved loading waits do not use AI; new discovery/planning, failure analysis, or enabled healing can use API tokens.
