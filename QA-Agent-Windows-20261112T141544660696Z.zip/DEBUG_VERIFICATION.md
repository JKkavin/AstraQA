# Debug verification

## Company transfer verification — 12 November 2026

Prepared the source package with an SQLite backup of usage accounting while excluding private credential/configuration files, raw evidence, reports/downloaded data, virtual environments, caches, and temporary state. Its package test verifies file exclusions, per-file hashes, and committed WAL-backed ledger restoration/integrity. All captured dependency pins match the installed working environment; `pip check` reports no broken requirements.

Extracted the ZIP into a fresh folder, confirmed no private .env was present, initialized new blank-key settings, and ran the complete local suite: **132 passed**, with the existing third-party fixture deprecation warning. The extracted-copy run used this machine's existing interpreter/dependencies, not a fresh dependency installation or the actual company laptop. No live RMM run or paid AI call was started by these checks. Evidence: `reports/company-transfer-verification.html`. Destination installation, certificates/VPN, credentials, and a live RMM baseline still require verification there.

Verified on 11 November 2026.

## Changes

- Unified test runs, PDF uploads, and report comparisons under one request lifecycle. Old output is cleared at the start, concurrent actions are disabled, and controls recover after errors.
- Added readable HTTP/JSON error messages and validation before requests.
- Added fresh JUnit XML alongside each unique HTML test report. Dashboard summaries and per-test results come from the current run's XML, including failures, setup errors, and skips.
- Bounded Gemini and Ollama requests; retained the configured model fallback order.
- Kept local token-free access limited to loopback clients with local hostnames and same-origin browser requests. Remote access still requires a token. The launch script disables proxy header interpretation.
- Updated accessible navigation names and verified mobile overflow behavior.
- Hardened the public OrangeHRM suite to search an employee that exists at runtime rather than depending on a fixed shared-demo record.

## Validation

- Full application regression suite: 52 passed in 15.45 seconds after cleanup.
- Live OrangeHRM suite: 5 passed in 42.01 seconds (login, invalid login, dashboard, employee search, logout).
- Browser regression coverage includes repeated runs, overlapping-action prevention, non-JSON server failures, input validation, current-file comparisons, structured results, local token-free UI, and mobile width.
- Local authentication regression coverage includes remote clients, cross-origin requests, hostname checks, and explicitly requiring tokens.

Reports: `reports/debug-regression.html` and `reports/orangehrm-final-debug.html`.

## Practical limits

AI generation still depends on provider availability and quota. A timeout or quota error is reported rather than a fabricated success. Generated plans still require selector/assertion review. The public OrangeHRM demo and its shared data can change. SQL Server and Databricks integrations are covered with mocked connection tests; no live database credentials or server were supplied for end-to-end database verification.

The test run emits one deprecation warning from the installed pytest browser plugin about a session fixture. It does not affect the successful checks.

## Documentation and cleanup

README, the application report, the laptop transfer guide, and OrangeHRM suite instructions were updated to the final behavior. Obsolete transfer archives, development caches, duplicate development screenshots, old server logs, and superseded OrangeHRM run reports were removed. Current verification reports, the latest dashboard report and its XML, one latest OrangeHRM screenshot per workflow, saved application suites, RMM evidence, private settings, downloads, and environment files remain. Caches may be recreated during subsequent runs.

Cleanup removed 65 files (3,716,822 bytes, about 3.5 MiB). After cleanup, all 52 application tests passed again, source compilation succeeded, and the dashboard plus both retained verification reports returned HTTP 200.


## OpenAI Terra integration — 12 November 2026

- Added the official OpenAI SDK and Responses API support for planning, adaptive browser decisions, and failure analysis. Structured plans still pass the existing validators.
- Added a private SQLite ledger for actual reported input/output/cached tokens and estimated cost. Atomic reservations enforce a $4.50 application trial budget with a $0.10 per-call cap; uncertain calls keep their reservation. This does not read or enforce the provider account's total balance.
- Added the dashboard AI trial budget panel, activation status, recent calls, and USD/illustrative INR display. Keys are read only on the server from the private .env file. No paid retries, hosted tools, or silent provider fallback are enabled.
- Full regression suite: 67 passed in 24.79 seconds, with the same existing third-party pytest fixture deprecation warning. New coverage includes cached-token costing, concurrent reservations, budget rejection before requests, missing keys, failed/uncertain calls, incomplete responses, routing, protected usage access, and mobile usage-panel rendering.
- Dependency check: no broken requirements. Running dashboard and usage endpoint both returned HTTP 200 after relaunch.
- At verification: OpenAI selected, model gpt-6.1-terra, key not configured, zero calls/tokens/cost, $4.50 available application budget. No live OpenAI requests were made. Activation and model-quality verification remain pending a funded API key.

Evidence: reports/openai-integration-tests.html. Preserve usage/openai.sqlite3 for this trial and do not reset it as generic cleanup output.


## OpenAI activation verified — 12 November 2026

One small live structured-output request to gpt-6.1-terra succeeded using the privately configured key. Reported usage: 1,130 input tokens and 38 output tokens. Estimated standard API cost: $0.00132 (approximately INR 0.12408 at the configured illustrative INR 94/USD rate). No held reservation remains from this completed check. Remaining tracked application budget: $4.49868 out of $4.50. This is not a provider account-balance measurement. Only the connectivity/structured-output check was performed; no new live website workflow was executed.


## Recovery and diagnostics — 12 November 2026

Implemented explicit DOM inspection summaries, failure classification, conservative discovery locator repair, and opt-in automatic rerun of transient failed pytest cases. Original failures and first/second HTML reports remain available; successful retries are marked FLAKY/PASS_WITH_RETRY. Assertion failures and skipped retries cannot be converted into clean passes. Repair does not rewrite arbitrary saved test source or replay a dispatched click/download.

A regression test found and fixed an existing snapshot bug: native button captions were incorrectly read from the empty value property instead of visible text. Missing and non-unique targets now have distinct diagnostic messages.

Validation: all 84 application tests passed through the running application's /tests/run endpoint, with zero failed/skipped tests. A real local pytest fixture verifies one failed-node rerun, no replay of already passing tests, original evidence preservation, and the skipped-retry failure guard. Browser fixtures verify unique locator repair, refusal of ambiguous/password-type changes, disabling healing, no duplicate click after dispatch, and rendering of recovery evidence. The existing third-party pytest fixture deprecation warning remains. No paid AI calls were required for these checks.

The server was relaunched; dashboard HTTP 200 and the opt-in rerun control were verified. Final integrated report: reports/test-report-9eb52283b2ed45148809a051485b76ec.html. Additional recovery report: reports/recovery-verification.html.

Limits: symptom classification is not a proven application root cause. Automated locator repair is limited to discovery with a known before/after semantic identity; missing baseline or ambiguous candidates require review/re-planning. Automatic reruns are off by default and must only be enabled for suites safe to repeat.


## Saved pytest AI healing — completed 12 November 2026

The complete saved-test pipeline is implemented: pytest failure → masked screenshot/current DOM/locator source capture → repeat-safe policy check → OpenAI selection of one observed semantic candidate → literal locator-only edit in an isolated copy → unchanged-assertion/source integrity checks → one failed-test retry with fresh-page semantic validation → combined final report.

Final automated regression suite: 101 passed in 64.39 seconds. The single existing third-party pytest fixture deprecation warning remains. Tests cover direct and declarative Page Object repairs, wrong AI selectors, ambiguity, assertion protection, password types, changed retry DOM, source/configuration changes, truncated DOM refusal, conflicting accessible names, HTML escaping, measured proposal usage, saved-suite selection, protected listing, and explicit opt-in.

Live local demonstration: healing_demo completed with one normal PASS and one HEALED test, PASS_AFTER_HEALING overall, after one real Terra proposal. Original source hash and assertions were unchanged. The proposal reported 249 input tokens, 56 output tokens, and $0.000529 estimated standard cost (approximately INR 0.05 at configured INR 94/USD). The fixture contains only local synthetic HTML and text and makes no target-application network requests. Original/retry evidence and locator review data remain available.

Demonstration final report: reports/generated/healing_demo-9149762ad831452ca8f12e42a509d979-final.html.
The existing OrangeHRM suite separately passed all five live read-only workflows without healing: reports/generated/orangehrm-89c4cc74043f4da68cf11b3171bc46a5-final.html.
Full regression evidence: reports/expert-qa-verification.html.

The dashboard now lists saved suites so reviewed sources need not be regenerated. OrangeHRM's five existing test functions and the local demonstration are enrolled. New plans default to unreviewed. AI healing and transient reruns are both opt-in. Only literal supported locators can be repaired; complex/dynamic/ambiguous cases remain failures for human review. No automatic permanent-apply endpoint exists. Detailed operating instructions are in EXPERT_QA_WORKFLOW.md.
# Page-aware timeout verification

Verified the adaptive waiting update with 111 passing full-suite regressions, followed by all 11 readiness tests passing after the final readiness recheck adjustment. Cases cover ready pages without AI, a short loading probe, capped AI waits, stalled-page decision limits, explicit AI stop, invalid durations, expired deadlines, and a page becoming ready during the AI decision. Tests use local pages and mocked wait decisions, without paid API calls. The only warning was the existing third-party pytest fixture deprecation. Full regression HTML: `reports/expert-qa-verification.html`.

## Website-first suite workflow verification

Saved replay wait fix: **131 regression tests passed** after generation began emitting readiness checks before every step and storing a versioned suite wait policy. An unchanged generated script passed three local runs with progressively slower 120/500/900 ms conditions, delayed options, a disabled button, and delayed report preparation, with AI calls prohibited. Deadline/missing-option behavior passed. Existing RMM saved source passed two additional fresh-browser runs, each downloading a 34,675-byte report with no AI wait events. Detailed evidence: `reports/REPLAY_WAIT_FIX_REPORT.md`.

Validation follow-up: 14 dashboard tests passed after replacing the generic missing-case message with indexed field-specific errors, invalid-field marking, and focus. A mocked request check confirms that missing expected text makes no discovery request and selecting nonempty-download submits successfully with blank expected_text. Documentation clarifies that draft requirements do not populate the discovery Steps field automatically.

RMM follow-up: **128 local regression tests passed**, with only the existing third-party fixture deprecation. Added coverage includes one-case download outcomes, empty/missing download refusal, one-action terminal completion without another AI call, real local download-to-generated-pytest replay, download evidence classification, explicit single-case planning, and visible healing controls. A stale test expecting the old rerun label was updated to the new saved-test label.

Live RMM validation passed one pytest/POM case with reviewed healing enabled. The optimized run took 51.32 seconds, recorded no adaptive AI decisions, emitted no warnings, and saved a valid nonempty 34,675-byte XLSX. The earlier run passed but made two page-wait calls (1,994 input + 76 output tokens, estimated USD 0.002374 / INR 0.22 at 94 INR/USD); native readiness conditions eliminated those calls on the final run. No locator repair was needed. Report details: `reports/RMM_COMPLETION_REPORT.md`.

Final UI verification: 13 dashboard tests passed after placing result/download actions before diagnostics. The restarted app returned HTTP 200 for root, final QA report, and the 34,675-byte protected download. The suite API lists rmm_audit360 with one test and reviewed healing. Live local rendering exposed Save file, Rerun saved tests, and the healing checkbox without JavaScript errors; these UI checks made no AI calls.

Follow-up dashboard simplification: all 12 dashboard tests passed after adding discovery reruns and saved-test reruns after success or failure. Coverage verifies that discovery repeats the original submitted payload, expanding saved evidence causes no discovery request, and saved reruns submit the correct suite options. Repeated evidence/screenshot links are collapsed by default. No paid AI calls were used in these UI checks.

The complete regression suite now passes **120 tests**. New coverage checks independent requested assertions, refusal to save incomplete/wrong outcomes, failure isolation, authentication and request validation, OrangeHRM template submission, and the distinction between discovery and pytest replay. A local HTTP fixture was discovered through the real API with a mocked planner; it generated two separate pytest functions, and both passed in a real child pytest/browser run. Replay did not invoke the action planner. The shared Playwright event loop required the direct async unit-test helper to run on its own thread; the full run passed after that test isolation fix.

The application was relaunched and returned HTTP 200. Its new discovery API is present in OpenAPI. The five-case example loaded without JavaScript errors, and a 390 px viewport had no horizontal overflow. These checks used local fixtures/mocked planning and did not spend API credit or rerun the new OrangeHRM discovery flow against the public demo. The existing third-party pytest fixture deprecation remains the sole warning. Current report: `reports/expert-qa-verification.html`.

