# Saved-test failure investigation and controlled healing

Updated 12 November 2026.

For another laptop, use [the quick start](COMPANY_LAPTOP_QUICK_START.md) and [transfer guide](TRANSFER_TO_COMPANY_LAPTOP.md). Transfer the whole suite, Page Objects, wait policy, shared runner, and reviewed healing configuration together. The prepared ZIP excludes raw evidence and downloaded reports; preserve selected originals separately when needed. Its usage-ledger backup prevents an accidental budget-history reset. New machines must verify credentials, network access, and a baseline before relying on repair-assisted runs.

## Operator workflow

For the supplied RMM story, select saved suite `rmm_audit360`: it contains one end-to-end report test with verified stable controls and reviewed healing contracts. The report download is the final assertion, not a required arbitrary text string. The RMM POM uses native condition waits through known loading phases to avoid unnecessary AI calls. Saved pytest download metadata is captured so **Save file** appears in results. Stable literal fields/buttons support healing; dynamic dropdown lookups, ambiguity, assertion failures, and incomplete DOM evidence remain refusal cases. See the completion report for actual run results; healing was enabled but not needed.

For a new application, start with **Discover on the website first**. Add separate cases with steps and final expected visible text. Discovery opens fresh sessions and executes observed actions before generating any suite source. A suite is saved only if every case passes and each final action verifies its requested expected text. Unique suite names preserve existing reviewed suites. Review the saved scripts, then run the regression suite separately; discovery is not a pytest execution. Use the OrangeHRM example for five editable workflows (the employee-search example checks a no-match result). New suites are not automatically enrolled in healing.

1. Open the dashboard and click **Load saved suites** under Saved regression suites. Select a suite; its saved target URL is loaded into the application URL field. This does not regenerate or overwrite the suite.
2. Review the suite source and confirm that the specific workflow is safe to repeat. OrangeHRM's existing five public-demo workflows and the synthetic `healing_demo` are enrolled. Newly generated suites are not enrolled automatically.
3. Enable **AI locator healing for reviewed saved tests** if you want the pipeline. Leave it off for an ordinary baseline run. The separate automatic-rerun checkbox controls transient network/navigation retries; healing itself permits one validated isolated retry.
4. Run the selected suite. A failure captures a masked screenshot, current DOM metadata, phase, node ID, and, when supported, the exact failed locator and its source location.
5. Healing considers only a locator confirmed missing before dispatch. The engine checks that the test is enrolled, derives its intended control from a literal locator or a reviewed CSS contract, and requires one semantically matching observed candidate. No AI request is made when those prerequisites fail.
6. OpenAI may select that candidate or decline. It cannot submit Python code, change expected values, or alter assertions. Its proposal is checked again, then a locator-only edit is made in an isolated `.qa_runs/` suite copy. Source/configuration hashes and assertion ASTs are checked before retry.
7. Only affected failed tests are retried, once, in a fresh pytest process/browser context. The proposed locator is semantically revalidated on the retry page before the action. Passing tests are not replayed. There is no second repair loop.
8. Open **Final QA report**. It includes original errors, final statuses, initial/retry report links, screenshots, DOM evidence, proposal/review metadata, and reported proposal-token costs. A repair-assisted success is **HEALED / PASS_AFTER_HEALING**, never a clean first-run PASS.
9. Review the locator-only proposal before manually saving any permanent change. There is deliberately no automatic permanent-apply endpoint. The original suite remains unchanged by the repair engine.

## Enrollment

A reviewed suite can use this configuration in its `suite_config.json`:

```json
{
  "target_url": "https://your-authorized-application.example/",
  "healing_policy": {
    "safe_to_repeat": true,
    "allow_ai_healing": true,
    "eligible_tests": ["test_read_only_workflow"],
    "locator_contracts": {}
  }
}
```

Eligible entries can be exact pytest node IDs or test-function names. Review source and fixtures before approving repeat safety. Re-generating a plan resets enrollment to false and replaces its generated sources; preserve reviewed modifications before regenerating.

For an otherwise opaque CSS locator, a reviewed semantic contract is required, for example `"locator_contracts": {"#old-login": {"tag": "button", "text": "Login"}}`. It is still refused if there is no unique observed match. Password values can only be directed to password inputs.

The API is `POST /qa/suite/{slug}/run` with `{ "target_url": "...", "auto_heal": true, "auto_rerun": false }`. `GET /qa/suites` lists existing suites and their review status. Both follow the same local/remote authentication rules as other QA endpoints.

## Supported repairs and refusal rules

Supported source adapters are simple literal Page locator factories (`get_by_placeholder`, `get_by_label`, named `get_by_role`, `get_by_text`, `get_by_test_id`, reviewed `locator`) and literal declarative target dictionaries used by the generated Page Object executor. Complex locator chains, runtime-computed source expressions, iframe-specific factories, or ambiguous source locations require manual review.

The engine refuses assertion changes, ambiguous or unobserved selectors, conflicting accessible names, unreviewed tests, incomplete DOM control lists, password-type mismatches, source/configuration changes since the first run, and invalid proposals. It does not heal application assertion failures, navigation errors, or post-dispatch click failures. The separate transient rerun capability can retry eligible network/navigation symptoms once, but does not resolve assertions or skipped retries.

At most two failed tests are considered for AI repair per run by default (`suite_healing_max_cases`, configurable from 1 to 5). All real OpenAI proposal calls use the existing token ledger, $4.50 application trial budget, and per-call reservation cap. SDK retries are disabled. A reservation is retained if billing is uncertain. Screenshots are saved for review; the proposal API receives redacted intent and candidate DOM metadata, not raw screenshots or form values. This deliberately reduces token use and exposure.

## Evidence and limits

Replay waits are now part of generated scripts and their saved `wait_policy`. Page readiness is checked before each step; control readiness and dependent-option availability use the recorded readiness window, bounded by the task/suite deadline. Saved-pytest loading checks use native browser conditions rather than asking AI again. Existing assertions and repair refusal rules remain. Local verification replays an identical generated file three times against progressively slower page, dropdown, button, and download conditions, with AI calls prohibited and its source hash unchanged.

Page-aware waiting first probes observed loading conditions without an AI call. Persistent loading is summarized to the configured model, which may request a bounded wait or stop. Fresh readiness is checked after each decision and waiting ends early when the condition clears. The default limits are three decisions, ten seconds per requested wait, and sixty seconds readiness time, further limited by the task/suite deadline. Decisions appear in `adaptive_waiting` evidence and final reports. AI wait decisions apply to discovery. Saved-suite readiness uses native browser conditions without AI; arbitrary third-party code retains its own waits. Configure limits in the dashboard. Waiting cannot weaken assertions or bypass the spending cap.

Private isolated suite copies and their plans are in `.qa_runs/`; original sources are not modified and `.env`/key files are not copied. Masked images, DOM JSON, proposal JSON, and combined final reports are under `reports/generated/`. Preserve relevant artifacts when investigating a failure; copies can be removed after review once no run is active. Keep `usage/` to retain budget accounting.

Failure classification and AI explanations remain hypotheses until verified; a successful replay does not prove that the original application behavior was correct. There is no guarantee that arbitrary locators or applications can be healed. DOM snapshots are intentionally bounded, and incomplete snapshots are refused for saved-test healing. Review screenshots and final assertions before accepting a repair.

## Verified live demonstrations

The `healing_demo` fixture uses local HTML and synthetic input only. Its original Username locator is intentionally stale. A live Terra proposal selected the uniquely matching Username input, the temporary copy passed with its original assertion unchanged, and the original source hash remained unchanged. That proposal reported 249 input and 56 output tokens, estimated $0.000529 (about INR 0.05 at the configured illustrative rate).

The existing OrangeHRM suite also passed all five live workflows without healing enabled. The demonstration establishes the controlled pipeline, not universal healing ability. See DEBUG_VERIFICATION.md and the final reports for verification evidence.
