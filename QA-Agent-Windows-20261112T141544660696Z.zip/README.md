# AI QA Agent

Local application for a human-reviewed QA workflow: requirements and PDFs feed a plan, Playwright inspects an authorized web page, and the configured model proposes QA checks. Pytest tests use Playwright with a Page Object Model example. FastAPI exposes the backend; MCP exposes knowledge search and page inspection; n8n can trigger the backend.

## Moving to a company laptop

Start with [the ten-step quick start](COMPANY_LAPTOP_QUICK_START.md) and [full transfer guide](TRANSFER_TO_COMPANY_LAPTOP.md). Build the current package with `.venv\Scripts\python.exe -B scripts\prepare_transfer.py`; the ZIP and SHA-256 sidecar appear in `transfer/`. Sources, all saved suite configuration, docs, and a consistent usage-ledger backup are included. Real credential files, downloaded company reports, raw evidence, virtual environments, and temporary data are excluded. Setup installs the pinned dependencies and Chromium, initializes private settings, and runs local checks. Source-package summaries can reference original HTML/screenshots that require a separate private evidence transfer.

## Recommended: website first, then regression scripts

Start with **Discover on the website first**. Enter the application URL and one independent case per requirement, including its steps and final expected visible text. Enable saved credentials only for cases that need your configured test account. **Use OrangeHRM example** fills five editable scenarios, including a no-match employee search. It does not start a run.

Click **Discover cases & save verified suite**. Each case opens a fresh visible browser session; the AI observes actual controls and chooses one action at a time. The final executed action must verify your exact requested expected-text value. Each browser closes when its case finishes. Discovery continues across independent case failures, but saves no suite unless every case passes. Up to ten cases are accepted; each has its configured task deadline and shares the existing API budget.

After all cases pass, the app writes a new uniquely named suite with a separate pytest function per case and links its discovery evidence. Existing reviewed suites are preserved. These are browser discovery results: **pytest has not run yet**. Review the scripts and click **Run this regression suite** for a separate regression result. Repeat runs execute the saved actions instead of asking AI to plan every step. Newly discovered suites require review before enrollment in saved-test AI healing.

Discovery results include **Rerun discovery**, which repeats the submitted cases and URL even if form inputs have since changed. This repeats AI planning and can consume tokens. Saved-suite results include **Rerun saved tests** after either success or failure. Evidence and screenshots are grouped in an optional section: opening these saved files does not make AI requests or consume tokens. Existing reports are retained.

API: `POST /qa/discover-suite` accepts `application`, `target_url`, and `cases`, where each case has `name`, `steps`, `expected_text`, and optional `use_saved_credentials` (default false). It returns per-case discovery results, evidence, counts with zero pytest runs, and `generated_suite` only after all cases pass. Expected text is a visible-text assertion, not an API/database or hidden-state check.

For report workflows, set `expected_outcome: "nonempty_download"`; `expected_text` is then optional. A successful final download action and nonzero saved-file evidence are required. `heal_locators` controls conservative discovery repair for that request. The UI exposes this under the cases; saved pytest AI healing is separately visible under Saved regression suites. Successful terminal assertions/downloads end discovery without an extra AI completion call, and browser closure is handled by the runner. Successful pytest downloads now appear in the dashboard with **Save file**.

Submission validation identifies each case and missing field and focuses the first invalid input. For downloads, choose **Final outcome → Nonempty report download**; no expected visible text is required. Put the workflow in that case's **Steps to perform** field, and remove unused blank cases. The separate draft requirements field does not automatically populate discovery cases. Validation failures do not start a test or paid AI request.

Use **Use RMM report workflow** to populate the supplied Audit 360 story as exactly one case. The already verified `rmm_audit360` suite is available under **Load saved suites**; prefer running it instead of rediscovering the same workflow. Enable **AI locator healing for reviewed saved tests** for its reviewed stable controls. The actual result link is **Download Report**, with `aria-label="Click here to download report"`. Its POM waits for organization context, dependent dropdown options, selected values, and loading conditions before proceeding. Credentials resolve only from the private environment. Dynamic dropdown source or ambiguous/incomplete evidence may require manual repair.

**Draft from requirements** also has **Keep this story as one end-to-end test case**. This sends `single_case: true` to `/qa/plan`; a split response is rejected. Draft locators remain unverified until inspected. See `reports/RMM_COMPLETION_REPORT.md` for live verification and token usage.

## 1. Install and run

Use Python 3.11, 64-bit. Create the virtual environment on a new machine; skip that command if `.venv` already exists.

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m playwright install chromium
python scripts/init_env.py
```

This workspace already has a private `.env` with a generated `QA_API_TOKEN`; never commit or share it. Local access at `127.0.0.1` works without entering a token. Remote access requires the token. Set `QA_ALLOW_LOCAL_NO_TOKEN=false` in `.env` to require it everywhere. The sample n8n workflow contains a placeholder; set its `Authorization` header to `Bearer <your QA_API_TOKEN>` after importing it.

The configured `.env` selects OpenAI with `gpt-6.1-terra`. Add `OPENAI_API_KEY` to activate AI calls; keys are never entered into the dashboard. Gemini and Ollama remain available by changing `LLM_PROVIDER`. Start the Ollama Windows app if you want local model or embedding support, then in PowerShell:

```powershell
ollama pull qwen3:4b
ollama pull nomic-embed-text
```

The first model is used for analysis. PDF retrieval uses local Ollama embeddings stored in ChromaDB; if embedding generation is unavailable, it falls back to local TF-IDF. Vector data is kept in the ignored `vector_store/` folder. If Ollama is unavailable, the API still runs and reports the fallback mode.

Start the API from the project root:

```powershell
uvicorn main:app --host 127.0.0.1 --port 8000 --no-proxy-headers --reload
```

Open <http://localhost:8000/> for the local UI, <http://localhost:8000/docs> for the API, and <http://localhost:8000/health> for status. The API binds to loopback and local QA requests work without a token; remote requests require the bearer token.

## 2. Add application knowledge

Upload a PDF in the dashboard or copy a text-based PDF into `knowledge/` and refresh it via the API. Uploads are limited to 20 MB and require a valid PDF. Scanned PDFs need OCR first. The API extracts page text, chunks it, embeds it locally with `nomic-embed-text`, stores vectors in ChromaDB, and returns matching excerpts to planning and inspection. `/health` reports the active `rag_mode` and indexed chunk count.

## 3. Inspect and perform a browser task

Enter the authorized target URL in the dashboard and describe the task in plain language. **Inspect a test page** runs this one task; it does not execute or change the generated plan or pytest suite. The URL is used for that run and is not stored in `.env`. The configured LLM turns the task, retrieved QA PDFs, and visible page controls into a bounded action list; Playwright executes those actions through accessible locators and reports a PASS/FAIL result per action. The browser is visible (`headless=false`) and captures a screenshot. It stays open after the task unless the task asks to close the browser; the dashboard also provides a **Close browser** button. There is no fixed five-second delay; add a wait to the task only when required. Saved `QA_USERNAME` and `QA_PASSWORD` values are never sent to the LLM and are used only when the task explicitly asks to use saved credentials (for example, “sign in using saved credentials”). Use a dedicated authorized test account, and never put credentials in the task text.

## 4. Generate an application regression suite

In **Build a test plan**, provide the application name, its authorized URL, and requirements. **Generate plan & save pytest suite** creates a reviewable plan plus `generated_suites/<application>/tests/test_<application>_regression.py` with one named pytest function per generated scenario, `pages/base_page.py` with reusable Playwright methods, an application-specific Page Object, case data, suite URL configuration, and `conftest.py`. Requirements and selectors are generated for the chosen application, so another application gets its own suite and Page Object. Review the generated selectors and assertions. **Run this regression suite** runs only that application's suite against the URL currently in the dashboard, opens visible Chromium (`headless=False`), and creates an HTML report under `reports/generated/`. The URL used during generation is saved in `suite_config.json` so the generated tests also run directly from PyCharm; `--target-url` overrides it for another environment. Credentials remain in `.env` and are used only by steps explicitly generated for a requested login. Generated pytest suites load this private `.env` with `override=True`, so old credential values configured in PyCharm do not silently replace the current project values.

## 5. Pytest + Playwright + POM

Run the included local browser example:

```powershell
pytest
```

`qa_agent/pages/task_page.py` resolves the generated action plan through Playwright Page Objects and accessible locators. The saved project test suite makes no external requests. The live QA flow always opens visible Chromium; a true `QA_HEADLESS` value is ignored.

The UI’s **Run project tests** button and `POST /tests/run` endpoint run only the checked-in `tests/` folder, save unique `reports/test-report-<run-id>.html` and `.xml` files, and request a read-only AI failure explanation when tests fail. Generated diagnosis never edits or retries tests automatically.

## 6. MCP

Start the stdio MCP server from the project root:

```powershell
python mcp_server.py
```

It exposes `search_qa_knowledge`, `inspect_authorized_page`, and `close_visible_browser`. MCP clients generally launch this command as a local stdio process; keep it private to your local development environment.

## 7. n8n (optional)

The application works independently of n8n. If you use the included workflow, run your installed n8n instance locally, or start the provided Docker Compose service on a machine with Docker configured:

```powershell
docker compose up -d
```

Open <http://localhost:5678> and complete n8n's local setup. Its service, account, credentials, and Docker volume are separate from this Python application.

After n8n starts, import `n8n/qa-agent-workflow.json` in the workflow menu. The included URLs target the local npm instance. If you switch to Docker, change `127.0.0.1` to `host.docker.internal` in both HTTP Request nodes and run FastAPI bound to `0.0.0.0` so the container can reach it. Start FastAPI first. Set both Authorization headers to `Bearer <your QA_API_TOKEN>`. The workflow is inactive by default and must be manually run.

## 8. OpenAI setup and the $5 trial

1. On a phone or computer, sign in at <https://platform.openai.com/>. Open Settings → Billing, add payment details, and purchase API credit. Enable Desktop site in a phone browser if the menus are hidden. This is separate from a ChatGPT subscription. Review the checkout amount and keep auto-recharge off initially.
2. Create a project key at <https://platform.openai.com/api-keys>. Do not paste it into chat, screenshots, or the dashboard. On the laptop, save it in the private project `.env` as `OPENAI_API_KEY=...`.
3. The trial defaults are:

```dotenv
LLM_PROVIDER=openai
OPENAI_MODEL=gpt-6.1-terra
OPENAI_BUDGET_USD=4.50
OPENAI_MAX_CALL_USD=0.10
QA_USD_TO_INR=94
```

4. Run `start_qa_agent.cmd`. The AI trial budget panel displays activation status, input/output tokens, estimated USD/INR cost, held reservations, and remaining application budget. Refresh usage after adding the key. The key is reread at call time; changing the selected provider requires restarting the server.

The app uses the Responses API with strict JSON schemas for plans/actions, low reasoning effort, output limits, no hosted tools, no automatic paid retries, and no response storage. Structured output still passes the existing action validation before Playwright executes it. There is no silent paid fallback to another provider.

The $4.50 application cap leaves headroom in a $5 balance. Before each request the app reserves a conservative token-cost bound from the serialized input size plus the output limit. Actual reported input/output and cached-input tokens replace that reservation on success. A timeout or missing usage keeps the reservation because provider work might still have been billable. Do not delete or reset `usage/openai.sqlite3` to bypass the cap; reconcile uncertain calls against provider billing first. Pending reservations after a process crash are also retained.

Tracking is local to calls made by this application since this feature was enabled. It does not read account credits, capture previous Gemini usage, include other applications, or guarantee a provider-level spending cutoff. INR is a configured estimate, not a live exchange rate, and excludes taxes/bank fees. Prices checked 12 November 2026: Terra input $1, output $5, cached input $0.05 per million tokens. Pricing is deliberately pinned to this model; selecting an unpriced model is rejected. Recheck official pricing before changing rates or the model. See <https://developers.openai.com/api/docs/models/gpt-6.1-terra>.

The local SQLite ledger stores only purpose, model, timestamps, token counts, status, response ID, and estimated charges; prompts, responses, and API keys are not stored. `GET /qa/ai/usage` uses the same local/remote authentication rules as other QA endpoints. Keep the `usage/` directory when transferring the existing trial so its budget history is preserved.

Replaying a saved pytest suite uses saved steps without AI action planning. Saved-script readiness waits use native browser conditions without AI; deterministic report comparison also does not call AI. Failed-test analysis, browser discovery rounds, and generating a new plan do use AI. API key presence is not proof of funded billing or model access; a small live check is needed after activation.

## 9. Optional Gemini API

Set `LLM_PROVIDER=gemini` and add your `GEMINI_API_KEY` to the private `.env`. The default order is `gemini-4-argon`, then `gemini-3.8-flash`, then `gemini-3.6-flash`; the app tries them one by one when a model is unavailable. Override the order with `GEMINI_MODEL` and `GEMINI_FALLBACK_MODELS`. API limits and charges depend on the provider/account; never commit `.env` or send real patient data, passwords, or confidential application data to an external model.

## Current scope

- `/qa/plan` drafts requirement-based cases and saves a per-application pytest/POM suite under `generated_suites/`.
- `/qa/suite/{slug}/run` executes that application's suite with visible Chromium and saves an HTML report.
- `/qa/run` performs the user-described bounded browser task and returns step results, screenshot, retrieved PDF passages, and analysis.
- Generated Python is template-owned; model output is validated data limited to supported page actions. Review generated cases and locators before running them; a failed assertion is evidence to inspect, not automatically proof of an application defect.
- Test only systems you are authorized to assess. Keep this local service private; add authentication and target restrictions before any shared deployment.

## Search fields, dropdowns, and report downloads

In **Inspect a test page**, describe the field, search text, and exact result, for example:
“Search for Test Patient in the patient dropdown, select the result with patient ID TEST-001, and verify the patient details heading.”
`search_select` clicks the trigger, fills the input (a separate `search_target` is supported for popup searches), waits up to the configured search timeout for the explicit `option_target`, and clicks it. Ambiguous result locators fail rather than silently selecting the first patient. Ordinary search forms use fill/click. Native dropdowns support option values or `by: "label"`.

Ask “Click Download orders and download the report.” The `download` action waits for the browser download and saves it under ignored `downloads/` with a unique ID. Results show the filename, size, save button, and controls to use the file in validation. These files are served only through the authenticated `/qa/downloads/{id}` endpoint. Links that only open a PDF preview or render a report page need the application's actual export/download control. If several download links are present, describe the specific link or row to use; the agent does not infer which report is newest.

## Compare downloaded reports with files or server queries

**Validate reports** accepts a browser download ID or file upload, and compares it with another report or a configured database query. Supported formats: UTF-8 CSV/TSV, JSON arrays of objects, and XLSX tables using the sheet and header row chosen in Application settings. PDF table comparison requires a layout-specific extraction step and is not supported here. Install optional dependencies:

```powershell
.\.venv\Scripts\python -m pip install -r requirements-reports.txt
```

Choose one or more key columns (for example `order_id` or `patient_id, encounter_id`), optional comparison columns, and optional numeric columns/tolerance. Default comparison checks every column, trims surrounding whitespace, preserves leading-zero text IDs, treats null differently from empty text, and ignores row order. Numeric equivalence is enabled only for the columns you choose. Alias database columns to match report headers and ensure both reports use the same date/status filters and timezone. Dates otherwise compare as text/ISO strings; locale-specific formatting needs normalization in the export or query. XLSX formulas require cached values from the exporting spreadsheet application.

Validation reports PASS/FAIL, row counts, missing records, duplicate keys, missing columns, and value differences. Two empty reports are INCONCLUSIVE. File size and row limits are configurable (defaults: 20 MB and 100,000 rows); oversized results are rejected rather than silently truncated. Displayed difference/key details are capped at the configured detail limit (default: 200 per category), with full missing-record and mismatch counts. Validation is deterministic and report rows are not sent to the LLM. Uploads and downloads stay in `downloads/` until you remove them.

For SQL Server or Databricks, copy `report_sources.example.json` to ignored `report_sources.json`, then edit the queries, tables, and parameter names for your schema. Queries are administrator-owned configuration; the dashboard supplies parameter values, never arbitrary SQL or connection strings. Configure a database account with **SELECT-only permissions**. The query prefix check is a guard against configuration mistakes, not a SQL security boundary. Use SQL Server `?` placeholders in the listed parameter order, or Databricks `:name` placeholders. Do not put credentials in queries, task text, or report source JSON.

Set these privately in `.env` and restart the API:

- SQL Server: `QA_SQLSERVER_CONNECTION_STRING` (use Microsoft ODBC Driver 18, encryption, your database, and a read-only login; Windows integrated authentication is also supported by the connection string). Install the Microsoft ODBC driver separately.
- Databricks: `DATABRICKS_SERVER_HOSTNAME`, `DATABRICKS_HTTP_PATH`, and `DATABRICKS_TOKEN` for an account with read-only access to the reporting tables.
- Optional: `QA_REPORT_SOURCES_FILE` to use another administrator-owned JSON file.

Click **Load server sources**, select the query, enter its parameter JSON, and compare. No live database connection has been verified until your actual source is configured and run. SQL Server login and query timeouts are configurable (defaults: 15 and 60 seconds). Databricks uses connector/warehouse timeout settings; configure those for your environment.

Connector references: [Databricks SQL Connector](https://docs.databricks.com/aws/en/dev-tools/python-sql-connector), [pyodbc connections](https://github.com/mkleehammer/pyodbc/wiki/Connection).


## Runtime settings

Use **Application settings → Load settings → Save settings** in the dashboard. Local access works without a token; remote access requires the bearer token. The validated settings are persisted in ignored `runtime_settings.json` and used by subsequent browser tasks, report comparisons, and both new and existing generated suites. Running tasks may retain settings they already loaded; save changes before starting a new task. The browser remains visible Chromium and is intentionally not configurable.

Settings include default target URL, action/navigation/search/download timeouts, task and suite timeouts, report size/row/detail limits, Excel sheet name/header row, SQL Server login/query timeouts, maximum planned actions, and maximum explicit wait. Blank Excel sheet selects the first sheet. Defaults provide an initial configuration; they are not fixed business rules. Limits have validated upper/lower bounds to reject invalid or unbounded configuration.

Every runtime field also supports a `QA_<FIELD_NAME>` environment default, for example `QA_MAX_REPORT_ROWS=250000` or `QA_SEARCH_TIMEOUT_MS=30000`. Saved dashboard values take precedence. Credentials remain exclusively in the private environment configuration. The target URL entered for a task overrides the default; generated suites use explicit `--target-url`, then runtime default, then their saved scenario URL.

Shared browser code contains no application-specific menu/logout selectors. Scenario data must identify actual controls and include a menu-opening step where needed; ambiguous interactive targets fail instead of silently choosing the first element. Existing saved scenario locators are preserved as application-specific test data. Model/provider settings remain configurable in `.env`, and administrator-owned report SQL remains in `report_sources.json` with bound parameter values from the dashboard.


## Adaptive live discovery and verified suite generation

**Inspect a test page → Discover and perform task** now uses one visible Chromium session to observe the current DOM, ask for one next action, validate its target against the current snapshot, execute it, and inspect the next state. It no longer relies on a single plan created before login or navigation. Select **Save a regression suite after verified discovery** to save the successfully executed actions as a reusable pytest/Page Object suite and a `verified_locators.json` evidence manifest. The ordinary Build a test plan path still drafts unverified requirements-based scenarios; use live discovery to obtain exercised locators.

Custom dropdown discovery identifies actual select/label structures in the DOM, opens the observed clickable label, inspects popup items, chooses an exact observed option, and verifies the selected label. It does not hardcode any RMM organization, field name, CSS class, or menu. Portal-based dropdowns without a discoverable relationship, iframes, or controls outside the supported DOM patterns may need explicit scenario locators. Standard accessible controls remain supported in saved suites. Discovered CSS selectors are unique in the current snapshot; a future application release may still require rediscovery.

Loading waits handle all observed visible busy indicators, including multiple overlays, using DOM conditions instead of fixed sleeps. There is a configurable readiness timeout, maximum discovery rounds, and recovery budget in Application settings. A failed attempt records a masked screenshot and diagnostic details before the next observation. Unchanged repeated clicks/downloads are stopped; an action that may already have submitted a request is not blindly replayed. Successful discovery is reported only after an executed assertion/download and the planner's completion response; the planner can still misunderstand the task, so review the evidence and generated suite.

Results separately show browser sessions, discovery snapshots, action attempts, failed discovery attempts, and pytest runs. A discovery run has zero pytest runs; saving a suite does not execute it. **Run this regression suite** records each actual pytest invocation separately in `reports/generated/<slug>-runs.jsonl`. That counter covers executions recorded after this feature was installed; it does not infer historical runs. Failed discovery attempts remain in the manifest even when later recovery completes the workflow. Overall test cases show successful executed actions and the final outcome; recovered discovery failures are not silently relabeled as passed assertions.

Discovery evidence is saved under `reports/discovery-<session>/`. Authentication query strings/redirect fragments, JWTs, and saved credentials are redacted before evidence is sent to the planner or returned in results. Screenshots mask inputs and textareas. Generated suites embed masked failure screenshots in pytest-html reports. Browser sessions still stay open after completion unless the task requests closure. Model availability and inference latency affect discovery; provider failures stop with evidence instead of fabricating selectors or results.


### Dashboard reliability checks

Result-producing actions run one at a time. Starting a request clears the previous output; errors restore the controls. PDF uploads and report comparisons use the same request lifecycle as test runs. Pytest runs write unique HTML and JUnit XML reports, and the dashboard displays per-test outcomes from that run's XML evidence. AI requests use bounded timeouts; OpenAI has local budget reservations, while Gemini retains its configured fallback order; provider quota and availability can still prevent plan generation.

Run the local regression checks with `.\.venv\Scripts\python.exe -m pytest tests --html=reports/debug-regression.html --self-contained-html`. The OrangeHRM regression suite exercises the public demo with its displayed demo credentials and selects an existing employee at runtime. It does not create or modify employee records.


## Documentation and retained files

- `APPLICATION_QA_REPORT.md`: current architecture and behavior.
- `DEBUG_VERIFICATION.md`: verified checks and remaining limits.
- `TRANSFER_TO_COMPANY_LAPTOP.md`: fresh setup and transfer instructions.
- `generated_suites/*/README.md`: instructions for each saved application suite.

Keep the application sources (`main.py`, `qa_agent/`, `web/`), regression tests, dependency files, startup/setup scripts, configuration examples, and saved suites. Optional n8n and MCP integrations are included because they are supported application features. `.env`, `runtime_settings.json`, `.venv/`, `usage/`, downloads, knowledge documents, and the vector store are local working data. Do not delete them as generic build output.

Caches and superseded development reports can be regenerated. Current regression evidence is `reports/expert-qa-verification.html`; current RMM/replay evidence is linked in the completion reports. The latest dashboard-generated HTML/XML report is also retained. Historical RMM evidence remains with its saved workflows. Transfer archives are not updated automatically; rebuild with scripts/prepare_transfer.py after source changes and use the newest package.


## Failure diagnosis, DOM inspection, locator repair, and reruns

| Capability | Implementation and limits |
| --- | --- |
| Failure/root-cause analysis | Deterministic categories cite actual failure messages and suggest next checks. Optional AI explanations remain hypotheses; a failed assertion is not proof of an application defect. |
| DOM inspection | Discovery captures visible controls, semantic attributes, associated labels, disabled state, dropdown options, loading indicators, and bounded page text. Results link to saved discovery evidence. |
| Locator repair | Enabled by default for discovery and configurable through `locator_healing_enabled`. A stale locator can be replaced only by one exact semantic match in a fresh snapshot with the same tag/input type. Proposed/applied/failed repairs and original failed attempts remain recorded. This does not rewrite arbitrary saved pytest source or perform fuzzy first-match recovery. |
| Automatic pytest rerun | Opt in using the checkbox under Build a test plan, or send `auto_rerun: true` to `/qa/suite/{slug}/run`. The runner reruns only eligible transient failed test node IDs, at most once. Ordinary assertions, ambiguous/missing locators, configuration errors, and whole-suite timeouts are not automatically rerun. Enable only for suites safe to repeat. |

The opt-in applies to saved application suites, not Run project tests. Earlier reports and failures are retained. A test passing only on retry is `FLAKY` and the overall summary is `PASS_WITH_RETRY`; passing tests are not replayed. A skipped rerun does not resolve the original failure. Each pytest attempt uses the configured suite timeout.

Locator repair does not retry a dispatched click/download. It may repair a missing target before dispatch or repeat an idempotent fill/select/check action within the discovery recovery budget. Ambiguous candidates and password-to-text-field replacements are refused. After a successful repair, the observed action still has to execute and the workflow still needs its outcome assertion.

The new evidence cards show DOM inspection, applied locator repairs, classified failures, and whether an automatic rerun occurred. Optional AI planning/analysis still counts against the existing OpenAI trial budget; deterministic diagnosis and local retry selection do not themselves call AI.


## Saved pytest failure → evidence → OpenAI proposal → isolated repair → retry → report

The complete controlled pipeline is now available for reviewed, repeat-safe saved tests. Use **Load saved suites** to select an existing suite without regenerating it, then explicitly enable **AI locator healing for reviewed saved tests**. Root assertions and original source files are never edited by the repair engine. Supported literal locators are repaired only after semantic uniqueness validation; ambiguous, assertion, post-dispatch, and unsupported-source failures remain unresolved.

Results include masked screenshots, DOM evidence, original and retry reports, locator-only review data, proposal token usage, and a combined final QA report. A successful repaired test is **HEALED**, with **PASS_AFTER_HEALING** overall. Permanent edits require manual review. The reviewed OrangeHRM tests and local `healing_demo` are enrolled; new generated plans default to unreviewed.

Read [EXPERT_QA_WORKFLOW.md](EXPERT_QA_WORKFLOW.md) for enrollment, supported adapters, refusal rules, API fields, cost controls, and operator steps. Private temporary copies are in `.qa_runs/`, which is not served by the web app or committed to Git. The existing `usage/` budget ledger is preserved.

## Page-aware waiting

Saved regression scripts now preserve waiting behavior on every run. New generated test files call `app.wait_until_ready()` before each step, and `suite_config.json` records a versioned `wait_policy` with readiness, navigation, action, search, and download limits. The generated Page Object loads this policy. Saved scripts wait for document readiness and visible loading indicators to clear, allow the next control to appear/become actionable, wait for a requested dependent dropdown option, and retain the existing selected-value/download assertions. These are conditions, not copies of the number of seconds observed on the first run.

Existing suites that use the shared `TaskPage` inherit native replay waits without regenerating their tests. The instrumented saved-pytest runner also waits natively before supported locator operations. Custom third-party code that bypasses both integrations still owns its own waits; reviewed custom suites are not silently rewritten. Discovery retains its bounded AI wait decisions. Saved-script readiness does not call AI, and task/suite deadlines and cancellation still limit waiting. A permanently missing option or stuck page fails rather than selecting another value or waiting forever.

During discovery, loading indicators, document readiness, and visible content drive waiting. Fast pages proceed without an AI wait call. After a short condition probe, the configured AI can request a bounded additional wait or stop from a fresh redacted page summary. The page condition ends a wait as soon as readiness is observed. A navigation timeout can continue from the already opened page during discovery; it does not automatically navigate again.

Dashboard settings control `adaptive_waits_enabled` (default true), `readiness_probe_ms` (2000), `max_ai_wait_decisions` (3), `max_wait_ms` (10000), and `readiness_timeout_ms` (60000). Task/suite deadlines and existing API spending limits still apply. Action-specific timeouts remain configurable. AI wait calls use the existing token ledger; reports expose `adaptive_waiting` decisions. A wait decision cannot change assertions, repair locators, or declare a test passed.
