# Company laptop: step-by-step transfer and installation

Updated 12 November 2026. Follow these steps in order. This project was verified with Python 3.11, 64-bit. Current Playwright supports Windows 11 / Windows Server 2019 and newer. Destination network access, package availability, and company permissions must be checked there.

## 1. Install the prerequisites

| Item | Required? |
|---|---|
| Supported Windows 11 64-bit laptop | Desktop target |
| Company-approved Python 3.11.x, 64-bit, with the Python launcher | Yes |
| Company VPN / RMM QA access | When your company network requires it |
| Edge or Chrome | To open the dashboard |
| Python packages and Playwright Chromium | The setup script installs them |
| PyCharm or VS Code | Optional editor |
| Ollama desktop/models, Gemini, Docker, n8n, Node.js, Git | Not required for the current OpenAI/RMM workflow |
| Microsoft ODBC Driver 18 / SQL access | Only for SQL Server report comparisons |

Ask IT for its approved Python 3.11 build. Official downloads: https://www.python.org/downloads/windows/. Python 3.11.9 was the last 3.11 release with traditional binary installers; use an appropriately maintained company-approved build rather than choosing an old patch just for its installer. Playwright reference: https://playwright.dev/python/docs/intro.

The laptop needs access to your approved Python package repository, Playwright browser downloads, api.openai.com, and the RMM QA site/VPN. Use IT-provided proxy and CA configuration if needed; keep certificate verification enabled.

## 2. Take the prepared ZIP

Copy the newest QA-Agent-Windows-...zip and its .zip.sha256 file from the project's transfer/ folder using your company-approved transfer method. Do not copy the old .venv.

To rebuild after future source changes, run from the project root:

```powershell
.\.venv\Scripts\python.exe -B scripts\prepare_transfer.py
```

The ZIP contains source, dashboard, tests, saved suite source/configuration, documents, pinned dependencies, setup/start scripts, and a consistent backup of usage/openai.sqlite3 when present. TRANSFER_MANIFEST.json lists included files and hashes. The usage ledger contains accounting history, not keys/prompts; keep it so this trial's app spending history is preserved.

The package excludes actual .env/runtime/database configuration, PDFs, downloaded reports, raw DOM evidence, screenshots, HTML run reports, vector stores, virtual environments, temporary retries, IDE/Git state, and old archives. Full verification HTML/images are referenced in documents but need separate private transfer if you want those originals.

## 3. Extract into a writable folder

1. Create a folder such as C:\QAAgent, or a writable folder under your Windows profile.
2. Extract the ZIP there. Open the directory containing setup_company_laptop.cmd and main.py; that is the project root.
3. Keep the entire folder structure, including Page Objects, suite_config.json, saved wait policies, and qa_agent/ helpers.
4. Optional checksum: run `Get-FileHash -Algorithm SHA256 "<your-zip-path>"` in PowerShell and compare it with the supplied .sha256 file.

## 4. Check Python

Open Command Prompt in the extracted project directory:

```bat
py -3.11 --version
py -3.11 -c "import struct; print(struct.calcsize('P') * 8)"
```

Expect Python 3.11.x and 64. If py is not recognized, ask IT to install/enable the Python launcher.

## 5. Run one-time setup

Double-click setup_company_laptop.cmd and wait for **Setup and local tests passed**. It creates a new .venv, installs requirements-transfer.txt, installs Playwright Chromium, creates a private .env if absent, runs pip check, and runs local regression tests. Browser windows may open during the tests.

These tests use local/synthetic fixtures and mocked AI. Setup does not automatically log into live RMM or spend OpenAI tokens. Do not close the window before completion. If a package is blocked/unavailable on your company's mirror, resolve that failed installation step with IT; do not silently substitute the entire pinned environment.

## 6. Enter private settings

Open the newly created .env with a text editor and set:

```dotenv
LLM_PROVIDER=openai
OPENAI_API_KEY=<your permitted OpenAI API key>
OPENAI_MODEL=gpt-6.1-terra
OPENAI_BUDGET_USD=4.50
OPENAI_MAX_CALL_USD=0.10
QA_USERNAME=<your authorized RMM test username>
QA_PASSWORD=<your authorized RMM test password>
```

Keep the generated QA_API_TOKEN. Local dashboard access does not require typing it; remote requests require authentication. Leave the server on 127.0.0.1 using the start script. Key presence alone does not prove funded billing/model access. Do not reset/delete usage/ to reset this trial's spending history.

Alternatively, privately transfer the existing .env before setup; the initializer leaves existing files unchanged. Never include the real .env in the source ZIP. Review any machine-specific paths. Do not put actual secrets in chat or documents.

## 7. Restore only optional data you need

- runtime_settings.json: optional dashboard settings; review URLs, timeouts, and paths.
- report_sources.json and database credentials: only for server-side comparisons.
- knowledge/*.pdf: optional; rebuild the PDF index on the destination. Do not copy vector_store/ blindly. Ollama is optional; the app has a local PDF-search fallback.
- Selected reports/downloads: only when required and permitted; they can contain company data.
- usage/: already backed up into the ZIP when present. If you need a fresher ledger, stop the old app and use a consistent SQLite backup; do not copy only a live database file while ignoring WAL state. Use one authoritative ledger when continuing this trial. Two independently active laptop copies do not automatically share one account-wide cap.

## 8. Start the dashboard

Double-click start_qa_agent.cmd and leave its window open. Wait for server startup, then open:

http://127.0.0.1:8000/

Check the dashboard loads, OpenAI is selected, and usage totals reflect the transferred ledger. PyCharm and a ChatGPT subscription are not required to run this local app; OpenAI API calls use the configured API account.

## 9. Run the existing RMM test first

1. Connect to company VPN if required and check the RMM QA URL opens.
2. Click Load saved suites.
3. Select rmm_audit360: the reviewed one-case end-to-end report test.
4. Leave automatic rerun/healing off for a clean baseline, or enable AI locator healing for reviewed saved tests when you intentionally want controlled repair.
5. Click Run selected suite.
6. Review the final QA report and Save file action for the downloaded Excel report.

The saved POM waits for organization context, page loading, dependent options, and required controls. Saved-script loading waits use native conditions without AI. New planning/discovery, failure analysis, and enabled locator healing can use paid tokens. Network timing, credentials, permissions, and available reports can differ on the destination; existing passing results do not prove destination compatibility.

## 10. Create new tests after the baseline works

Use website-first discovery. Keep the whole report workflow as one case and choose Final outcome → Nonempty report download; no expected visible text is needed. New scripts save wait policy and readiness calls. To repeat a reviewed test, run its saved suite instead of regenerating it.

Read README.md for general operation, EXPERT_QA_WORKFLOW.md for repair limits, and reports/REPLAY_WAIT_FIX_REPORT.md for the latest repeat-run evidence. Source-package summaries reference original local artifacts; raw HTML/images/downloads are excluded unless you transfer selected originals separately.
