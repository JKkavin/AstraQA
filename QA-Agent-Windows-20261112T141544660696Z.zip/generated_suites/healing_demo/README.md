# Local saved-test healing demonstration

This reviewed, repeat-safe suite uses only local HTML and synthetic text. It makes no application network requests and uses no real credentials. One test has an intentionally stale Username placeholder. The original remains broken so that the healing pipeline can be demonstrated without changing its assertion or permanently editing source.

Run through the application saved-suite endpoint with `auto_heal: true` (or the dashboard AI locator healing control). A successful demonstration reports one ordinary PASS and one HEALED case, retains the initial failure, writes a locator-only isolated copy, and links the final report. AI proposal usage counts against the normal OpenAI trial budget. Without AI healing enabled, the intentional stale-locator test is expected to fail.

## Moving this suite to another laptop

Updated 12 November 2026. Follow [the company laptop guide](../../TRANSFER_TO_COMPANY_LAPTOP.md). Transfer this whole suite together with qa_agent/ shared helpers, dependencies, and its suite_config.json. Rebuild .venv and Playwright Chromium on the destination. Configure credentials privately. Source packages omit raw DOM evidence, HTML reports, screenshots, and downloaded files; transfer selected evidence separately if needed. Preserve the usage ledger. Review the suite's healing enrollment rather than assuming every generated test is eligible.
