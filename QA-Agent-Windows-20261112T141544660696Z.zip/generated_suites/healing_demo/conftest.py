import pytest
from playwright.sync_api import sync_playwright

def pytest_addoption(parser):
    parser.addoption('--target-url',default='http://127.0.0.1:8000/')

@pytest.fixture
def page():
    with sync_playwright() as p:
        browser=p.chromium.launch(headless=False)
        page=browser.new_page()
        yield page
        browser.close()
