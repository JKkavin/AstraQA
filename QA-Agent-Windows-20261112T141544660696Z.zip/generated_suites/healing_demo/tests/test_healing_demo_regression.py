"""Intentional stale locator demo. No network or real credentials are used."""
from playwright.sync_api import expect


def test_unchanged_read_only_check(page):
    page.set_content('<h1>Local QA fixture</h1>')
    expect(page.get_by_role('heading',name='Local QA fixture')).to_be_visible()


def test_username_field_locator(page):
    page.set_content('<label for="username">Username</label><input id="username" placeholder="Enter your username">')
    page.get_by_placeholder('Username',exact=True).fill('demo-user',timeout=500)
    expect(page.locator('#username')).to_have_value('demo-user')
