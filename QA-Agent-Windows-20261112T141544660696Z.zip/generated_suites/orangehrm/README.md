# OrangeHRM public-demo regression suite

Reviewed and verified on 11 November 2026: five tests passed in 42.01 seconds.

Coverage: successful Admin login, invalid-login error, dashboard widgets, employee search, and logout. The suite uses the public `Admin` / `admin123` credentials displayed on the demo login page, independently of private saved credentials. Each test starts in an isolated browser context. Employee search selects a record present at runtime, verifies the search response, and checks matching UI rows; it does not create or modify employee data.

Run from the project root:

```powershell
.\.venv\Scripts\python.exe -m pytest generated_suites/orangehrm --target-url https://opensource-demo.orangehrmlive.com/ --html=reports/orangehrm-final-debug.html --self-contained-html -v
```

Chromium launches visibly. Successful screenshots are written under `reports/orangehrm-evidence/`; failures are embedded in the HTML report. Dashboard execution writes a unique HTML/XML report and displays the current test outcomes.

The reviewed executable tests in `tests/test_orangehrm_regression.py` contain the final assertions and dynamic search logic. `cases.json` records the original reviewed plan and its initial example search data; it is not the runtime data source for these tests. Generating another OrangeHRM plan replaces the suite files, so preserve reviewed changes before regenerating. The public demo and its data may change and require locator review.


The five existing public-demo test functions are enrolled for repeat-safe saved-test AI healing. In the dashboard, load the saved suite instead of regenerating it, then enable AI locator healing if desired. Only supported missing literal locators can be repaired; the original suite and assertions remain unchanged, and passing after repair is explicitly labeled HEALED. A fresh ordinary live run with the evidence plugin passed all five tests. See EXPERT_QA_WORKFLOW.md in the project root.

## Moving this suite to another laptop

Updated 12 November 2026. Follow [the company laptop guide](../../TRANSFER_TO_COMPANY_LAPTOP.md). Transfer this whole suite together with qa_agent/ shared helpers, dependencies, and its suite_config.json. Rebuild .venv and Playwright Chromium on the destination. Configure credentials privately. Source packages omit raw DOM evidence, HTML reports, screenshots, and downloaded files; transfer selected evidence separately if needed. Preserve the usage ledger. Review the suite's healing enrollment rather than assuming every generated test is eligible.
