import json
import base64
import pytest_html
from pathlib import Path
from urllib.parse import urlparse

import pytest
from dotenv import load_dotenv
from playwright.sync_api import sync_playwright
from qa_agent.settings import get_settings


PROJECT_ROOT = Path(__file__).resolve().parents[2]
load_dotenv(PROJECT_ROOT / ".env", override=True)


def pytest_addoption(parser):
    parser.addoption("--target-url", action="store", default="", help="Override the generated suite's default URL")


@pytest.fixture(scope="session")
def target_url(pytestconfig):
    configured = Path(__file__).with_name("suite_config.json")
    default_url = json.loads(configured.read_text(encoding="utf-8")).get("target_url", "") if configured.exists() else ""
    value = pytestconfig.getoption("--target-url") or get_settings().target_url or default_url
    parsed = urlparse(value)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname or parsed.username or parsed.password:
        pytest.fail("Set a valid URL in this suite's suite_config.json or pass --target-url http(s)://...", pytrace=False)
    return value


@pytest.fixture(scope="session")
def browser():
    with sync_playwright() as playwright:
        instance = playwright.chromium.launch(headless=False)
        yield instance
        instance.close()


@pytest.fixture
def page(browser):
    context = browser.new_context(accept_downloads=True)
    page = context.new_page()
    yield page
    context.close()


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    report = outcome.get_result()
    if report.when == "call" and report.failed and item.funcargs.get("page") is not None:
        page = item.funcargs["page"]
        try:
            screenshot = page.screenshot(full_page=True, mask=[page.locator("input,textarea")])
            extras = getattr(report, "extras", [])
            extras.append(pytest_html.extras.png(base64.b64encode(screenshot).decode(), name="Failure screenshot"))
            report.extras = extras
        except Exception:
            pass
