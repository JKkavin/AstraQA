"""Read-only regression checks for the public OrangeHRM demo."""
import re
from datetime import datetime, timezone
from pathlib import Path
from playwright.sync_api import expect

ROOT = Path(__file__).resolve().parents[3]


def evidence(page, name):
    folder = ROOT / "reports" / "orangehrm-evidence"
    folder.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S-%f")
    page.screenshot(path=str(folder / f"{stamp}-{name}.png"), full_page=True)


def login(page, target_url):
    page.goto(target_url, wait_until="domcontentloaded")
    # These are the public demonstration credentials displayed on this site.
    page.get_by_placeholder("Username", exact=True).fill("Admin")
    page.get_by_placeholder("Password", exact=True).fill("admin123")
    page.get_by_role("button", name="Login", exact=True).click()
    expect(page.get_by_role("heading", name="Dashboard", exact=True)).to_be_visible(timeout=30000)


def test_admin_successful_login(page, target_url):
    login(page, target_url)
    expect(page).to_have_url(re.compile(r"/dashboard/index$"))
    evidence(page, "01-admin-login")


def test_invalid_login_shows_error(page, target_url):
    page.goto(target_url, wait_until="domcontentloaded")
    page.get_by_placeholder("Username", exact=True).fill("invalid_qa_user")
    page.get_by_placeholder("Password", exact=True).fill("invalid_qa_password")
    page.get_by_role("button", name="Login", exact=True).click()
    expect(page.get_by_text("Invalid credentials", exact=True)).to_be_visible(timeout=15000)
    expect(page).to_have_url(re.compile(r"/auth/login$"))
    evidence(page, "02-invalid-login")


def test_admin_can_view_dashboard(page, target_url):
    login(page, target_url)
    for widget in ("Time at Work", "Quick Launch", "My Actions"):
        expect(page.get_by_text(widget, exact=True)).to_be_visible(timeout=15000)
    evidence(page, "03-dashboard")


def test_admin_can_search_employees(page, target_url):
    login(page, target_url)
    page.get_by_role("link", name="PIM", exact=True).click()
    expect(page.get_by_role("heading", name="Employee Information", exact=True)).to_be_visible(timeout=20000)
    # Use a record present in this run; the shared demo's employee data changes.
    rows = page.get_by_role("table").get_by_role("row")
    expect(rows.nth(1)).to_be_visible(timeout=20000)
    seed = rows.nth(1).get_by_role("cell")
    record_id = seed.nth(1).inner_text().strip()
    first_name = seed.nth(2).inner_text().strip()
    assert record_id, "The initial employee list must contain a searchable employee ID"
    employee_id = page.locator(".oxd-input-group").filter(has=page.get_by_text("Employee Id", exact=True)).locator("input")
    employee_id.fill(record_id)
    with page.expect_response(lambda response: response.request.method == "GET" and "/pim/employees" in response.url, timeout=20000) as response:
        page.get_by_role("button", name="Search", exact=True).click()
    assert response.value.ok, "Employee search must return a successful response"
    count = len(response.value.json()["data"])
    assert count > 0, "Searching an existing employee ID must return a match"
    expect(rows).to_have_count(count + 1, timeout=15000)
    result_rows = rows.all()[1:]
    for row in result_rows:
        expect(row.get_by_role("cell").nth(1)).to_have_text(record_id)
    expect(page.get_by_role("cell", name=first_name, exact=True).first).to_be_visible()
    evidence(page, "04-employee-search")


def test_admin_can_logout(page, target_url):
    login(page, target_url)
    page.locator(".oxd-userdropdown-tab").click()
    page.get_by_role("menuitem", name="Logout", exact=True).click()
    expect(page.get_by_role("heading", name="Login", exact=True)).to_be_visible(timeout=20000)
    expect(page).to_have_url(re.compile(r"/auth/login$"))
    expect(page.get_by_placeholder("Username", exact=True)).to_be_visible()
    evidence(page, "05-logout")
