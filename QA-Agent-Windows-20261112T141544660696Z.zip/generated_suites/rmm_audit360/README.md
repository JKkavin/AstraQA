# RMM Audit 360 Measure Report

Exactly one pytest case logs in using local saved credentials, opens Audit 360 > Measure Reports, selects Organization Org1-D45, Program HEDIS MY 2027, Reporting Period 2027 - HEDIS MY 2027 - ADMIN, Submission 2123141 - Medicare, Measure Type Admin, clicks Go, and saves a nonempty report.

Controls were verified on the live QA site. The real link is Download Report with aria-label Click here to download report. The POM waits for organization context, observed dependent options, selected values, and loading conditions. No credentials are embedded or sent to AI.

In the dashboard, Load saved suites, choose rmm_audit360, optionally enable AI locator healing for reviewed saved tests, and Run selected suite. Repeat runs reuse the POM without AI action planning. Native waits avoid the unnecessary loading-decision calls observed during the first live verification.

Direct execution from the project root:

```powershell
.\.venv\Scripts\python.exe -m pytest generated_suites/rmm_audit360 --html=reports/rmm-direct.html --self-contained-html
```

The URL defaults to the authorized QA URL in suite_config.json. Screenshots on failure are embedded in pytest-html. Dashboard runs additionally capture DOM evidence, isolated healing reviews, and download metadata for Save file. Report files remain under downloads/.

Reviewed healing is enrolled for stable literal controls in this single repeat-safe report workflow. Dynamic dropdown source, ambiguous candidates, assertion failures, and incomplete DOM snapshots are refused. No real locator failure occurred in the passing live run, so no healing proposal was needed. Originals are not automatically rewritten.

Latest live validation: 1 passed in 51.32 seconds, 34,675-byte valid XLSX, zero AI calls on the optimized run. See reports/RMM_COMPLETION_REPORT.md from the project root for costs, regression results, and links.

## Moving this suite to another laptop

Updated 12 November 2026. Follow [the company laptop guide](../../TRANSFER_TO_COMPANY_LAPTOP.md). Transfer this whole suite together with qa_agent/ shared helpers, dependencies, and its suite_config.json. Rebuild .venv and Playwright Chromium on the destination. Configure credentials privately. Source packages omit raw DOM evidence, HTML reports, screenshots, and downloaded files; transfer selected evidence separately if needed. Preserve the usage ledger. Review the suite's healing enrollment rather than assuming every generated test is eligible.
