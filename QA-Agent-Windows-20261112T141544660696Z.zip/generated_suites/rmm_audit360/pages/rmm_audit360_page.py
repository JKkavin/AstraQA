from pathlib import Path
from uuid import uuid4
import re
from playwright.sync_api import Page, expect
from qa_agent.browser import _settings
from qa_agent.readiness import READY_JS
from qa_agent.settings import get_settings
from generated_suites.rmm_audit360.pages.base_page import BasePage


class RmmAudit360Page(BasePage):
    """RMM controls verified against the live QA site; credentials resolve locally."""

    def __init__(self, page: Page, target_url: str):
        super().__init__(page)
        self.target_url = target_url
        runtime = get_settings()
        self.ready = min(runtime.task_timeout_seconds * 1000, max(90000, runtime.readiness_timeout_ms))
        self.download_timeout = runtime.download_timeout_ms

    def open_page(self) -> None:
        response = self.page.goto(self.target_url, wait_until="domcontentloaded", timeout=get_settings().navigation_timeout_ms)
        if response is not None:
            assert response.status < 400, f"Application returned HTTP {response.status}"

    def login(self):
        credentials = _settings()
        if not credentials['username'] or not credentials['password']:
            raise ValueError('Configure saved QA_USERNAME and QA_PASSWORD before running RMM')
        self.page.locator('#username').fill(credentials['username'], timeout=self.ready)
        self.page.locator('#password').fill(credentials['password'], timeout=self.ready)
        self.page.locator('#kc-login').click(timeout=self.ready)
        # The menu appears before the organization context finishes loading.
        expect(self.page.get_by_text('Org1-D45', exact=True)).to_be_visible(timeout=self.ready)
        self.wait_ready()

    def wait_ready(self):
        """Known loading phases use a native condition wait without an AI call."""
        self.page.wait_for_function(READY_JS, timeout=self.ready, polling=100)

    def open_measure_reports(self):
        self.page.get_by_role('button', name='Audit 360', exact=True).click(timeout=self.ready)
        target = self.page.locator('a[aria-label="Navigate to Measure Reports"]')
        expect(target).to_have_attribute('href', '#/audit360', timeout=self.ready)
        target.click(timeout=self.ready)
        expect(self.page).to_have_url(re.compile(r'/audit360(?:/measure)?$'), timeout=self.ready)
        self.wait_ready()

    def select_filters(self):
        # These named dropdown roots and option texts were observed on the live site.
        for selector, value in [
            ('p-dropdown[name="organization"] > div:nth-of-type(1)', 'Org1-D45'),
            ('p-dropdown[name="qtyProgram"] > div:nth-of-type(1)', 'HEDIS MY 2027'),
            ('p-dropdown[name="reportingPeriod"] > div:nth-of-type(1)', '2027 - HEDIS MY 2027 - ADMIN'),
            ('p-dropdown[name="submissionId"] > div:nth-of-type(1)', '2123141 - Medicare'),
            ('p-dropdown[name="measureType"] > div:nth-of-type(1)', 'Admin'),
        ]:
            root = self.page.locator(selector)
            # Options load asynchronously, including inside the hidden native select.
            expect(root.locator('select option').filter(has_text=re.compile(r'^\s*'+re.escape(value)+r'\s*$'))).to_have_count(1, timeout=self.ready)
            trigger = root.locator('label')
            trigger.click(timeout=self.ready)
            option = root.locator('li,[role="option"]').filter(has_text=re.compile(r'^\s*'+re.escape(value)+r'\s*$'))
            expect(option).to_have_count(1, timeout=self.ready)
            option.click(timeout=self.ready)
            expect(trigger).to_have_text(value, timeout=self.ready)
            self.wait_ready()

    def download_report(self):
        self.wait_ready()
        self.page.locator('button[aria-label="Click here to proceed"]').click(timeout=self.ready)
        self.wait_ready()
        # The actual accessible label is more precise than guessing exact text Download.
        link = self.page.locator('a[aria-label="Click here to download report"]')
        expect(link).to_be_visible(timeout=self.ready)
        self.wait_ready()
        with self.page.expect_download(timeout=self.download_timeout) as pending:
            link.click(timeout=self.ready)
        download = pending.value
        assert download.failure() is None, 'Browser reported a failed report download'
        suffix = Path(download.suggested_filename).suffix.lower()
        assert re.fullmatch(r'\.[a-z0-9]{1,10}', suffix), 'Unexpected report file extension'
        identifier = uuid4().hex + suffix
        # Isolated healing retries still save to the real application's protected downloads folder.
        from qa_agent.browser import ROOT
        destination = ROOT / 'downloads' / identifier
        destination.parent.mkdir(exist_ok=True)
        download.save_as(destination)
        assert destination.is_file() and destination.stat().st_size > 0, 'Downloaded report is empty'
        metadata = {'id': identifier, 'filename': download.suggested_filename, 'bytes': destination.stat().st_size}
        self.page._qa_downloads = getattr(self.page, '_qa_downloads', []) + [metadata]
        return metadata
