import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[3]
project_path = str(PROJECT_ROOT)
if project_path in sys.path:
    sys.path.remove(project_path)
sys.path.insert(0, project_path)

from generated_suites.rmm_audit360.pages.rmm_audit360_page import RmmAudit360Page


def test_download_measure_report(page, target_url):
    """One end-to-end case: authenticate, select all filters, and save the report."""
    app = RmmAudit360Page(page, target_url)
    app.open_page()
    app.login()
    app.open_measure_reports()
    app.select_filters()
    downloaded = app.download_report()
    assert downloaded['bytes'] > 0
