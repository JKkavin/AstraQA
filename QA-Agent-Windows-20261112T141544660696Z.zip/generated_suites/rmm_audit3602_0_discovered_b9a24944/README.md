# RMM-Audit3602.0 discovered b9a24944 regression suite

Generated Playwright + pytest suite with separate test functions, a reusable BasePage, and an application-specific Page Object. Review selectors and assertions before running. The script calls wait_until_ready before every step. suite_config.json saves its condition-wait policy; targets and dependent options are awaited on every replay, without AI loading decisions. Task/suite deadlines still apply.

Run from the project root:

```powershell
.\.venv\Scripts\python.exe -m pytest generated_suites/rmm_audit3602_0_discovered_b9a24944 --target-url "https://your-authorized-app.example" -v
```

Chromium always launches visibly (`headless=False`). The URL used during generation is saved in `suite_config.json` as the default; pass `--target-url` to override it. The private project `.env` is loaded with precedence over inherited PyCharm environment values. Saved QA_USERNAME and QA_PASSWORD values are used only when test steps explicitly require login.

## Moving this suite to another laptop

Updated 12 November 2026. Follow [the company laptop guide](../../TRANSFER_TO_COMPANY_LAPTOP.md). Transfer this whole suite together with qa_agent/ shared helpers, dependencies, and its suite_config.json. Rebuild .venv and Playwright Chromium on the destination. Configure credentials privately. Source packages omit raw DOM evidence, HTML reports, screenshots, and downloaded files; transfer selected evidence separately if needed. Preserve the usage ledger. Review the suite's healing enrollment rather than assuming every generated test is eligible.
