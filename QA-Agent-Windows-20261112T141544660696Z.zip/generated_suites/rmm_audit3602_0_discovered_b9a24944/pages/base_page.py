from __future__ import annotations

import json
from pathlib import Path
from playwright.sync_api import Page
from qa_agent.pages.task_page import TaskPage
from qa_agent.browser import _settings


class BasePage:
    """Execute scenario-provided targets without application-specific selector fallbacks."""

    def __init__(self, page: Page):
        self.page = page
        config = Path(__file__).resolve().parents[1] / 'suite_config.json'
        policy = json.loads(config.read_text(encoding='utf-8')).get('wait_policy', {})
        self.task_executor = TaskPage(page, replay=True, wait_policy=policy)

    def wait_until_ready(self) -> None:
        self.task_executor.wait_until_ready()

    def _locator(self, target: dict):
        return self.task_executor._locator(target)

    def fill(self, target: dict, value: str) -> None:
        self.perform({"action": "fill", "target": target, "value": value})

    def click(self, target: dict) -> None:
        self.perform({"action": "click", "target": target})

    def select(self, target: dict, value: str) -> None:
        self.perform({"action": "select", "target": target, "value": value})

    def check(self, target: dict) -> None:
        self.perform({"action": "check", "target": target})

    def uncheck(self, target: dict) -> None:
        self.perform({"action": "uncheck", "target": target})

    def verify_text(self, expected: str) -> None:
        self.perform({"action": "verify_text", "expected": expected})

    def wait(self, milliseconds: int) -> None:
        self.perform({"action": "wait", "milliseconds": milliseconds})

    def perform(self, step: dict) -> None:
        self.task_executor.execute(step, _settings())
