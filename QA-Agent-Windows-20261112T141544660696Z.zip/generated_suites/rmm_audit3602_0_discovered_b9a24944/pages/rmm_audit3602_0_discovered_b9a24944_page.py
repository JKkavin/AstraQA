from playwright.sync_api import Page, TimeoutError as PlaywrightTimeoutError
from qa_agent.settings import get_settings
from generated_suites.rmm_audit3602_0_discovered_b9a24944.pages.base_page import BasePage


class RmmAudit36020DiscoveredB9A24944Page(BasePage):
    """Application-specific page object for named locators and workflows."""

    def __init__(self, page: Page, target_url: str):
        super().__init__(page)
        self.target_url = target_url

    def open_page(self) -> None:
        try:
            response = self.page.goto(self.target_url, wait_until="domcontentloaded", timeout=self.task_executor._timeout('navigation_timeout_ms'))
        except PlaywrightTimeoutError:
            if self.page.url in {'about:blank', ''}:
                raise
            response = None
        if response is not None:
            assert response.status < 400, f"Application returned HTTP {response.status}"
        self.wait_until_ready()
