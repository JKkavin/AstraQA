import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[3]
project_path = str(PROJECT_ROOT)
if project_path in sys.path:
    sys.path.remove(project_path)
sys.path.insert(0, project_path)

from generated_suites.rmm_audit3602_0_discovered_b9a24944.pages.rmm_audit3602_0_discovered_b9a24944_page import RmmAudit36020DiscoveredB9A24944Page


def test_rmm_audit3601_0(page, target_url):
    app = RmmAudit36020DiscoveredB9A24944Page(page, target_url)
    app.open_page()
    app.wait_until_ready()  # Wait for loading conditions on every replay.
    app.wait(3000)
    app.wait_until_ready()  # Wait for loading conditions on every replay.
    app.fill({'selector': '#username'}, '{{QA_USERNAME}}')
    app.wait_until_ready()  # Wait for loading conditions on every replay.
    app.fill({'selector': '#password'}, '{{QA_PASSWORD}}')
    app.wait_until_ready()  # Wait for loading conditions on every replay.
    app.click({'selector': '#kc-login'})
    app.wait_until_ready()  # Wait for loading conditions on every replay.
    app.wait(3000)
    app.wait_until_ready()  # Wait for loading conditions on every replay.
    app.click({'selector': '#audit360-menu > button:nth-of-type(1)'})
    app.wait_until_ready()  # Wait for loading conditions on every replay.
    app.click({'selector': 'a[aria-label="Navigate to Measure Reports"]'})
    app.wait_until_ready()  # Wait for loading conditions on every replay.
    app.click({'selector': 'button[aria-label="Click here to proceed"]'})
    app.wait_until_ready()  # Wait for loading conditions on every replay.
    app.perform({'action': 'download', 'target': {'selector': 'a[aria-label="Click here to download report"]'}})
