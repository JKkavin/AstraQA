from playwright.sync_api import Page
from qa_agent.settings import get_settings
from generated_suites.rmm_audit360_discovered_e2094be3.pages.base_page import BasePage


class RmmAudit360DiscoveredE2094Be3Page(BasePage):
    """Application-specific page object for named locators and workflows."""

    def __init__(self, page: Page, target_url: str):
        super().__init__(page)
        self.target_url = target_url

    def open_page(self) -> None:
        response = self.page.goto(self.target_url, wait_until="domcontentloaded", timeout=get_settings().navigation_timeout_ms)
        if response is not None:
            assert response.status < 400, f"Application returned HTTP {response.status}"
