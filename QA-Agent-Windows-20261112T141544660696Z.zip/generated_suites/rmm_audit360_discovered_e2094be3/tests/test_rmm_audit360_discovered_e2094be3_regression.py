import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[3]
project_path = str(PROJECT_ROOT)
if project_path in sys.path:
    sys.path.remove(project_path)
sys.path.insert(0, project_path)

from generated_suites.rmm_audit360_discovered_e2094be3.pages.rmm_audit360_discovered_e2094be3_page import RmmAudit360DiscoveredE2094Be3Page


def test_rmm_audit3601_0(page, target_url):
    app = RmmAudit360DiscoveredE2094Be3Page(page, target_url)
    app.open_page()
    app.wait(3000)
    app.fill({'selector': '#username'}, '{{QA_USERNAME}}')
    app.fill({'selector': '#password'}, '{{QA_PASSWORD}}')
    app.click({'selector': '#kc-login'})
    app.wait(3000)
    app.click({'selector': '#audit360-menu > button:nth-of-type(1)'})
    app.click({'selector': 'a[aria-label="Navigate to Measure Reports"]'})
    app.click({'selector': 'button[aria-label="Click here to proceed"]'})
    app.perform({'action': 'download', 'target': {'selector': 'a[aria-label="Click here to download report"]'}})
