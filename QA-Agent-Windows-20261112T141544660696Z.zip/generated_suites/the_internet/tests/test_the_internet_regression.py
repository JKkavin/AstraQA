import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[3]
project_path = str(PROJECT_ROOT)
if project_path in sys.path:
    sys.path.remove(project_path)
sys.path.insert(0, project_path)

from generated_suites.the_internet.pages.the_internet_page import TheInternetPage


def test_home_page_displays_welcome_message(page, target_url):
    app = TheInternetPage(page, target_url)
    app.open_page()
    app.verify_text('Welcome to the-internet')

def test_navigate_to_login_and_submit_invalid_credentials(page, target_url):
    app = TheInternetPage(page, target_url)
    app.open_page()
    app.click({'role': 'link', 'name': 'Form Authentication'})
    app.verify_text('Login Page')
    app.fill({'label': 'Username'}, 'invalid_user')
    app.fill({'label': 'Password'}, 'invalid_password')
    app.click({'role': 'button', 'name': 'Login'})
    app.verify_text('Your username is invalid!')
