from __future__ import annotations

import asyncio
import ast
import json
import logging
from io import BytesIO
import os
import secrets
import re
from pathlib import Path
from uuid import uuid4

from dotenv import load_dotenv
from fastapi import Depends, FastAPI, File, Header, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, model_validator
from typing import Literal

from qa_agent.settings import RuntimeSettings, get_settings, save_settings
from qa_agent import reconciliation
from qa_agent.browser import _settings, close_browser_session, inspect_page, inspect_case, validate_target_url
from qa_agent.execution import run_generated_suite, run_saved_test_suite
from qa_agent.knowledge import knowledge_base
from qa_agent.llm import analyze, generate_regression_cases
from qa_agent.suites import GENERATED_DIR, save_regression_suite
from qa_agent.diagnostics import execution_diagnosis, root_cause_report


ROOT = Path(__file__).resolve().parent
logger = logging.getLogger(__name__)
load_dotenv(ROOT / ".env", override=True)
app = FastAPI(title="AI QA Agent", version="0.1.0")
GENERATED_DIR.mkdir(exist_ok=True)
app.mount("/reports", StaticFiles(directory=ROOT / "reports"), name="reports")
app.mount("/generated", StaticFiles(directory=GENERATED_DIR), name="generated")


class QARequest(BaseModel):
    target_url: str
    question: str = Field(default="Inspect this page and suggest useful smoke tests.", max_length=4000)
    include_ai: bool = True
    use_saved_credentials: bool = False
    save_verified_suite: bool = False
    application: str = Field(default="Discovered application", max_length=200)


class PlanRequest(BaseModel):
    application: str = Field(default="Application", max_length=200)
    requirements: str = Field(min_length=10, max_length=12000)
    target_url: str
    single_case: bool = False


class DiscoveryCaseRequest(BaseModel):
    name: str = Field(min_length=1, max_length=180, pattern=r'\S')
    steps: str = Field(min_length=10, max_length=3000, pattern=r'\S')
    expected_outcome: Literal['visible_text', 'nonempty_download'] = 'visible_text'
    expected_text: str = Field(default='', max_length=300)
    use_saved_credentials: bool = False

    @model_validator(mode='after')
    def validate_outcome(self):
        if self.expected_outcome == 'visible_text' and not self.expected_text.strip():
            raise ValueError('Visible-text outcomes require expected_text')
        return self


class DiscoverySuiteRequest(BaseModel):
    application: str = Field(default='My application', min_length=1, max_length=200, pattern=r'\S')
    target_url: str
    cases: list[DiscoveryCaseRequest] = Field(min_length=1, max_length=10)
    heal_locators: bool = True


class GeneratedSuiteRunRequest(BaseModel):
    target_url: str
    auto_rerun: bool = False
    auto_heal: bool = False


def local_access_without_token(request: Request) -> bool:
    enabled = os.getenv("QA_ALLOW_LOCAL_NO_TOKEN", "true").lower() in {"true", "1", "yes"}
    if (not enabled or not request.client or request.client.host not in {"127.0.0.1", "::1"}
            or request.url.hostname not in {"127.0.0.1", "::1", "localhost"}):
        return False
    # Only the local dashboard (or a local API client) may use token-free access.
    origin = request.headers.get("origin")
    if origin and origin != f"{request.url.scheme}://{request.url.netloc}":
        return False
    return request.headers.get("sec-fetch-site", "none") in {"none", "same-origin"}


def require_local_token(request: Request, authorization: str | None = Header(default=None)) -> None:
    if local_access_without_token(request):
        return
    expected = os.getenv("QA_API_TOKEN", "")
    if not expected:
        raise HTTPException(status_code=503, detail="QA_API_TOKEN is not configured in .env")
    supplied = authorization.removeprefix("Bearer ") if authorization else ""
    if not secrets.compare_digest(supplied, expected):
        raise HTTPException(status_code=401, detail="Provide the local QA API bearer token")


@app.get("/")
def dashboard(request: Request):
    html = (ROOT / "web" / "index.html").read_text(encoding="utf-8")
    if local_access_without_token(request):
        html = html.replace('<body>', '<body data-local-access="true">', 1)
    return HTMLResponse(html, headers={"Cache-Control": "no-store"})


@app.get("/health")
def health():
    provider = os.getenv("LLM_PROVIDER", "ollama").lower()
    configured = bool(os.getenv("GEMINI_API_KEY")) if provider == "gemini" else True
    if provider == "openai":
        from qa_agent.openai_provider import config
        configured = bool(config()["api_key"])
    return {
        "status": "ok",
        "pdf_chunks": len(knowledge_base.chunks),
        "rag_mode": knowledge_base.mode,
        "llm_provider": os.getenv("LLM_PROVIDER", "ollama"),
        "llm_configured": configured,
    }


@app.get("/qa/ai/usage", dependencies=[Depends(require_local_token)])
def ai_usage_status():
    from qa_agent.openai_provider import public_status
    try:
        return public_status()
    except (ValueError, ArithmeticError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.get('/qa/suites', dependencies=[Depends(require_local_token)])
def saved_suites():
    suites=[]
    for folder in sorted(GENERATED_DIR.iterdir()):
        if not folder.is_dir() or not re.fullmatch(r'[a-z0-9][a-z0-9_]{0,47}',folder.name):continue
        if not folder.resolve().is_relative_to(GENERATED_DIR.resolve()):continue
        source=folder/'tests'/f'test_{folder.name}_regression.py'
        if not source.is_file() or not source.resolve().is_relative_to(folder.resolve()) or source.stat().st_size>1_000_000:continue
        try:
            config_path=folder/'suite_config.json'
            if not config_path.resolve().is_relative_to(folder.resolve()):continue
            config=json.loads(config_path.read_text(encoding='utf-8'))
            if not isinstance(config,dict):continue
            url=config.get('target_url','')
            if url:validate_target_url(url)
            count=sum(isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)) and node.name.startswith('test_') for node in ast.walk(ast.parse(source.read_text(encoding='utf-8-sig'))))
            policy=config.get('healing_policy',{})
            reviewed=(isinstance(policy,dict) and policy.get('safe_to_repeat') is True
                      and policy.get('allow_ai_healing') is True and isinstance(policy.get('eligible_tests'),list)
                      and bool(policy['eligible_tests']) and all(isinstance(name,str) for name in policy['eligible_tests']))
            suites.append({'slug':folder.name,'target_url':url,'test_functions':count,'healing_reviewed':reviewed})
        except (ValueError,OSError,SyntaxError,TypeError):
            continue
    return {'suites':suites}


@app.post("/knowledge/refresh", dependencies=[Depends(require_local_token)])
def refresh_knowledge():
    try:
        return {"status": "ok", "pdf_chunks": knowledge_base.refresh(), "rag_mode": knowledge_base.mode}
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Could not index PDFs: {str(exc)[:250]}") from exc


@app.post("/knowledge/upload", dependencies=[Depends(require_local_token)])
async def upload_knowledge(file: UploadFile = File(...)):
    if not file.filename or Path(file.filename).suffix.lower() != ".pdf":
        raise HTTPException(status_code=400, detail="Upload a PDF file")
    contents = await file.read(20 * 1024 * 1024 + 1)
    if len(contents) > 20 * 1024 * 1024:
        raise HTTPException(status_code=413, detail="PDF must be 20 MB or smaller")
    if not contents.startswith(b"%PDF-"):
        raise HTTPException(status_code=400, detail="File does not have a valid PDF signature")
    try:
        from pypdf import PdfReader
        reader = PdfReader(BytesIO(contents))
        if not reader.pages:
            raise ValueError("PDF has no pages")
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Could not read PDF: {str(exc)[:200]}") from exc
    safe_name = Path(file.filename).name.replace("\\", "_").replace("/", "_")
    destination = ROOT / "knowledge" / f"{uuid4().hex[:8]}_{safe_name}"
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(contents)
    try:
        chunks = await asyncio.to_thread(knowledge_base.refresh)
    except Exception as exc:
        destination.unlink(missing_ok=True)
        raise HTTPException(status_code=400, detail=f"Could not index PDF: {str(exc)[:250]}") from exc
    return {"status": "indexed", "filename": safe_name, "pdf_chunks": chunks, "rag_mode": knowledge_base.mode}


@app.post("/qa/plan", dependencies=[Depends(require_local_token)])
def create_test_plan(request: PlanRequest):
    try:
        validate_target_url(request.target_url)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    excerpts = knowledge_base.search(request.requirements, top_k=3)
    try:
        cases = (generate_regression_cases(request.application, request.requirements, excerpts, single_case=True)
                 if request.single_case else generate_regression_cases(request.application, request.requirements, excerpts))
        generated_suite = save_regression_suite(request.application, cases, request.target_url)
    except ValueError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    test_plan = generated_suite.pop("test_plan")
    return {
        "status": "completed",
        "application": request.application,
        "retrieved_knowledge": excerpts,
        "test_plan": test_plan,
        "generated_suite": generated_suite,
        "note": "Review generated cases, locators, and expected results before running the suite.",
    }


@app.post('/qa/discover-suite', dependencies=[Depends(require_local_token)])
async def discover_application_suite(request: DiscoverySuiteRequest):
    try:
        validate_target_url(request.target_url)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    from qa_agent.website_first import discover_suite
    excerpts = knowledge_base.search('\n'.join(case.steps for case in request.cases), top_k=3)
    return await discover_suite(request.application, request.target_url, request.cases,
                                inspect_case, excerpts, ROOT, heal_locators=request.heal_locators)


@app.post("/qa/run", dependencies=[Depends(require_local_token)])
async def run_qa(request: QARequest):
    excerpts = knowledge_base.search(request.question, top_k=int(os.getenv("QA_TOP_K", "3")))
    try:
        validate_target_url(request.target_url)
        task = request.question
        if request.use_saved_credentials:
            task += "\nSign in using saved credentials from the private environment file."
        observations = await inspect_page(request.target_url, task, excerpts)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        logger.exception("Page inspection failed (%s)", type(exc).__name__)
        message = str(exc).strip()
        detail = (
            f"Page inspection failed ({type(exc).__name__}): {message[:300]}"
            if message
            else f"Page inspection failed ({type(exc).__name__}; no additional detail)"
        )
        raise HTTPException(status_code=502, detail=detail) from exc
    generated_suite = None
    if request.save_verified_suite and observations['test_summary']['status'] == 'PASS':
        cases=[{'id':'VERIFIED-01','name':'Verified discovered workflow','priority':'High','steps':observations['task_plan']}]
        generated_suite=save_regression_suite(request.application,cases,request.target_url)
        slug=generated_suite['slug']
        (GENERATED_DIR/slug/'verified_locators.json').write_text(
            __import__('json').dumps(observations.get('discovery',{}),indent=2),encoding='utf-8')
    result = (
        await asyncio.to_thread(analyze, request.question, observations, excerpts)
        if request.include_ai else "Skipped by request."
    )
    diagnosis = observations.get('discovery', {}).get('root_cause_analysis')
    if not diagnosis or (observations['test_summary']['status']=='FAIL' and not diagnosis.get('findings')):
        diagnosis = root_cause_report(observations['test_cases'])
    else:
        page_failures = [case for case in observations['test_cases'] if case.get('id')=='PAGE-001' and case.get('status')=='FAIL']
        if page_failures:
            diagnosis = {**diagnosis, 'status': 'evidence_available', 'recovered': False,
                         'findings': diagnosis['findings'] + root_cause_report(page_failures)['findings']}
    return {
        "status": "completed",
        "browser_observations": observations,
        "test_cases": observations["test_cases"],
        "test_summary": observations["test_summary"],
        "retrieved_knowledge": excerpts,
        "ai_analysis": result,
        "generated_suite": generated_suite,
        "attempt_counts": observations.get("discovery",{}).get("counts",{}),
        "dom_inspection": observations.get('discovery',{}).get('dom_inspection'),
        "locator_healing": observations.get('discovery',{}).get('locator_healing',[]),
        "adaptive_waiting":observations.get('discovery',{}).get('adaptive_waiting',[]),
        "root_cause_analysis": diagnosis,
    }


@app.post("/qa/browser/{session_id}/close", dependencies=[Depends(require_local_token)])
def close_qa_browser(session_id: str):
    if not close_browser_session(session_id):
        raise HTTPException(status_code=404, detail="That browser session is no longer active")
    return {"status": "closed"}


@app.post("/qa/suite/{slug}/run", dependencies=[Depends(require_local_token)])
async def run_application_suite(slug: str, request: GeneratedSuiteRunRequest):
    try:
        validate_target_url(request.target_url)
        if request.auto_heal:
            result = await asyncio.to_thread(run_generated_suite, slug, request.target_url,
                                             auto_rerun=request.auto_rerun, auto_heal=True)
        elif request.auto_rerun:
            result = await asyncio.to_thread(run_generated_suite, slug, request.target_url, auto_rerun=True)
        else:
            result = await asyncio.to_thread(run_generated_suite, slug, request.target_url)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    if result["status"] == "failed":
        excerpts = knowledge_base.search("pytest failure test assertion", top_k=3)
        result["failure_analysis"] = await asyncio.to_thread(
            analyze,
            "Analyze this generated regression-suite output. Identify evidence, likely cause, and next debugging steps. "
            "Do not edit or rerun tests.\n\n" + result["output"],
            None,
            excerpts,
        )
    result["suite_slug"] = slug
    result["target_url"] = request.target_url
    return result


@app.post("/tests/run", dependencies=[Depends(require_local_token)])
async def run_tests():
    result = await asyncio.to_thread(run_saved_test_suite)
    result['root_cause_analysis'] = execution_diagnosis(result)
    if result["status"] == "failed":
        excerpts = knowledge_base.search("pytest failure test assertion", top_k=3)
        result["failure_analysis"] = await asyncio.to_thread(
            analyze,
            "Analyze this pytest output. Identify evidence, likely cause, and next debugging steps. "
            "Do not change code or claim the application itself has a bug.\n\n" + result["output"],
            None,
            excerpts,
        )
    return result


class ReportComparisonRequest(BaseModel):
    downloaded_file_id: str
    reference_file_id: str | None = None
    source_id: str | None = None
    parameters: dict = Field(default_factory=dict)
    keys: list[str] = Field(min_length=1)
    columns: list[str] | None = None
    numeric_columns: list[str] = Field(default_factory=list)
    tolerance: str = "0"


@app.get("/qa/reports/sources", dependencies=[Depends(require_local_token)])
def report_sources():
    try:
        return {"sources": [{"id": name, "provider": config["provider"],
                             "parameters": config.get("parameters", [])}
                            for name, config in reconciliation.sources().items()]}
    except Exception as exc:
        raise HTTPException(400, "Could not read server report source configuration") from exc


@app.post("/qa/reports/upload", dependencies=[Depends(require_local_token)])
async def upload_report(file: UploadFile = File(...)):
    suffix = Path(file.filename or "").suffix.lower()
    if suffix not in {".csv", ".tsv", ".xlsx", ".json"}:
        raise HTTPException(400, "Upload CSV, TSV, XLSX, or JSON")
    contents = await file.read(reconciliation.max_bytes() + 1)
    if len(contents) > reconciliation.max_bytes():
        raise HTTPException(413, f"Report must be {get_settings().max_report_mb} MB or smaller")
    reconciliation.DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
    file_id = uuid4().hex + suffix
    path = reconciliation.DOWNLOAD_DIR / file_id
    path.write_bytes(contents)
    try:
        columns, rows = await asyncio.to_thread(reconciliation.read_report, path)
    except Exception as exc:
        path.unlink(missing_ok=True)
        raise HTTPException(400, "Cannot read report: " + str(exc)[:200]) from exc
    return {"id": file_id, "filename": file.filename, "columns": columns, "rows": len(rows)}


@app.get("/qa/downloads/{file_id}", dependencies=[Depends(require_local_token)])
def retrieve_download(file_id: str):
    try:
        return FileResponse(reconciliation.file_path(file_id))
    except ValueError as exc:
        raise HTTPException(404, str(exc)) from exc


@app.post("/qa/reports/compare", dependencies=[Depends(require_local_token)])
async def compare_reports(request: ReportComparisonRequest):
    if bool(request.reference_file_id) == bool(request.source_id):
        raise HTTPException(400, "Choose either a reference file or a server report source")
    def run():
        left = reconciliation.read_report(reconciliation.file_path(request.downloaded_file_id))
        if request.reference_file_id:
            right = reconciliation.read_report(reconciliation.file_path(request.reference_file_id))
        else:
            right = reconciliation.query_report(request.source_id, request.parameters)
        return reconciliation.compare_tables(left, right, request.keys, request.columns,
                                              request.numeric_columns, request.tolerance)
    try:
        return await asyncio.to_thread(run)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    except Exception as exc:
        raise HTTPException(400, "Could not read reports; check file format and server configuration") from exc


@app.get("/qa/settings", dependencies=[Depends(require_local_token)])
def runtime_settings():
    return {"settings": get_settings().model_dump(), "schema": RuntimeSettings.model_json_schema(),
            "browser": "chromium", "headless": False}


@app.put("/qa/settings", dependencies=[Depends(require_local_token)])
def update_runtime_settings(settings: RuntimeSettings):
    return {"settings": save_settings(settings).model_dump(), "browser": "chromium", "headless": False}


@app.get("/qa/credentials/status", dependencies=[Depends(require_local_token)])
def credential_status():
    values = _settings()
    return {"username_configured": bool(values["username"]),
            "password_configured": bool(values["password"]),
            "ready": bool(values["username"] and values["password"])}
