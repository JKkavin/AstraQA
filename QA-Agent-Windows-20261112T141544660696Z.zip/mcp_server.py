"""MCP tools for the local QA backend. Run with the project's Python interpreter."""

from mcp.server.fastmcp import FastMCP

from qa_agent.browser import close_browser_session, inspect_page
from qa_agent.knowledge import knowledge_base

mcp = FastMCP("AI QA Agent")


@mcp.tool()
def search_qa_knowledge(question: str, top_k: int = 3) -> list[dict]:
    """Search locally indexed QA PDF documents for relevant passages."""
    return knowledge_base.search(question, top_k)


@mcp.tool()
async def inspect_authorized_page(
    url: str,
    task: str = "Inspect visible controls and report whether the page loads successfully.",
) -> dict:
    """Perform the requested QA task on a page you are authorized to test."""
    return await inspect_page(url, task)


@mcp.tool()
def close_visible_browser(session_id: str) -> dict:
    """Close a visible browser left open by inspect_authorized_page."""
    if not close_browser_session(session_id):
        return {"status": "not_found", "detail": "That browser session is no longer active"}
    return {"status": "closed"}


if __name__ == "__main__":
    mcp.run()
