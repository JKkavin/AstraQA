"""AI assisted QA automation starter."""
