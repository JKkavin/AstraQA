"""Local, cross-process reservations for a small OpenAI trial budget.

No prompts, responses, or API keys are stored. Uncertain/time-out requests keep
their reservation: a client timeout does not establish that a request was free.
"""
from __future__ import annotations

from datetime import datetime, timezone
from contextlib import contextmanager
from decimal import Decimal, InvalidOperation, ROUND_CEILING
from pathlib import Path
import sqlite3
from uuid import uuid4

LEDGER_PATH = Path(__file__).resolve().parents[1] / "usage" / "openai.sqlite3"
NANO = 1_000_000_000


def dollars(amount: int) -> float:
    return float(Decimal(amount) / NANO)


def nano_dollars(amount: str | Decimal) -> int:
    try:
        value = Decimal(amount)
    except InvalidOperation:
        raise ValueError("AI budget and request limits must be numeric amounts") from None
    if not value.is_finite() or value <= 0:
        raise ValueError("AI budget and request limits must be positive finite amounts")
    return int((value * NANO).to_integral_value(rounding=ROUND_CEILING))


@contextmanager
def _connect():
    LEDGER_PATH.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(LEDGER_PATH, timeout=10)
    connection.row_factory = sqlite3.Row
    connection.execute("""CREATE TABLE IF NOT EXISTS calls (
        id TEXT PRIMARY KEY, created_at TEXT NOT NULL, purpose TEXT NOT NULL,
        model TEXT NOT NULL, status TEXT NOT NULL, reserved INTEGER NOT NULL,
        charged INTEGER NOT NULL DEFAULT 0, input_tokens INTEGER NOT NULL DEFAULT 0,
        output_tokens INTEGER NOT NULL DEFAULT 0, cached_tokens INTEGER NOT NULL DEFAULT 0,
        response_id TEXT, error_type TEXT)""")
    connection.commit()
    try:
        with connection:
            yield connection
    finally:
        connection.close()


def reserve(purpose: str, model: str, amount: int, budget: int, request_limit: int) -> str:
    if amount > request_limit:
        raise ValueError("This AI request exceeds the per-call spending limit. Shorten the task or context.")
    identifier = uuid4().hex
    with _connect() as connection:
        connection.execute("BEGIN IMMEDIATE")
        used = connection.execute("SELECT COALESCE(SUM(charged + reserved), 0) FROM calls").fetchone()[0]
        if used + amount > budget:
            raise ValueError("OpenAI trial budget reached, or funds are reserved by earlier calls. Check AI usage and billing before increasing it.")
        connection.execute("INSERT INTO calls(id, created_at, purpose, model, status, reserved) VALUES(?,?,?,?,?,?)",
                           (identifier, datetime.now(timezone.utc).isoformat(), purpose, model, "pending", amount))
    return identifier


def complete(identifier: str, input_tokens: int, output_tokens: int, cached_tokens: int,
             response_id: str | None) -> None:
    # Terra standard prices: $1 / $5 per million tokens; cached input $0.05.
    cost = (input_tokens - cached_tokens) * 1000 + cached_tokens * 50 + output_tokens * 5000
    with _connect() as connection:
        connection.execute("""UPDATE calls SET status='completed', reserved=0, charged=?,
            input_tokens=?, output_tokens=?, cached_tokens=?, response_id=? WHERE id=?""",
            (cost, input_tokens, output_tokens, cached_tokens, response_id, identifier))


def fail(identifier: str, error_type: str, definitely_rejected: bool = False) -> None:
    with _connect() as connection:
        connection.execute("UPDATE calls SET status=?, error_type=?, reserved=CASE WHEN ? THEN 0 ELSE reserved END WHERE id=?",
                           ("rejected" if definitely_rejected else "uncertain", error_type,
                            definitely_rejected, identifier))


def summary(budget: int, usd_to_inr: Decimal) -> dict:
    with _connect() as connection:
        row = connection.execute("""SELECT COUNT(*) AS calls, COALESCE(SUM(charged),0) AS charged,
            COALESCE(SUM(reserved),0) AS reserved, COALESCE(SUM(input_tokens),0) AS input_tokens,
            COALESCE(SUM(output_tokens),0) AS output_tokens, COALESCE(SUM(cached_tokens),0) AS cached_tokens,
            COALESCE(SUM(status='uncertain'),0) AS uncertain_calls FROM calls""").fetchone()
        recent = [dict(item) for item in connection.execute("""SELECT created_at, purpose, model, status,
            input_tokens, output_tokens, cached_tokens, charged, reserved FROM calls ORDER BY rowid DESC LIMIT 10""")]
    for item in recent:
        item["estimated_cost_usd"] = dollars(item.pop("charged"))
        item["reserved_usd"] = dollars(item.pop("reserved"))
    return {"calls": row["calls"], "input_tokens": row["input_tokens"], "output_tokens": row["output_tokens"],
            "cached_tokens": row["cached_tokens"], "estimated_cost_usd": dollars(row["charged"]),
            "estimated_cost_inr": float(Decimal(row["charged"]) / NANO * usd_to_inr),
            "reserved_usd": dollars(row["reserved"]), "budget_usd": dollars(budget),
            "remaining_usd": dollars(max(0, budget - row["charged"] - row["reserved"])),
            "uncertain_calls": row["uncertain_calls"], "usd_to_inr": float(usd_to_inr), "recent": recent}
