from __future__ import annotations

import asyncio
import os
import queue
import re
import threading
import time
from pathlib import Path
from urllib.parse import urlparse
from uuid import uuid4

from dotenv import dotenv_values, load_dotenv
from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeoutError

from qa_agent.pages.task_page import TaskPage
from qa_agent.settings import get_settings
from qa_agent.llm import plan_browser_task
from qa_agent.workflow import discover_workflow
from qa_agent.discovery import safe_url, redact


ROOT = Path(__file__).resolve().parents[1]
REPORT_DIR = ROOT / "reports"
load_dotenv(ROOT / ".env", override=True)
_ACTIVE_BROWSER_SESSIONS: dict[str, threading.Event] = {}
_ACTIVE_BROWSER_SESSIONS_LOCK = threading.Lock()


def close_browser_session(session_id: str) -> bool:
    """Request closure of a visible browser left open by a completed task."""
    with _ACTIVE_BROWSER_SESSIONS_LOCK:
        close_event = _ACTIVE_BROWSER_SESSIONS.pop(session_id, None)
    if close_event is None:
        return False
    close_event.set()
    return True


def _settings() -> dict[str, str]:
    file_values = dotenv_values(ROOT / ".env", interpolate=False)

    def get(name: str, default: str = "") -> str:
        file_value = file_values.get(name)
        if file_value is not None:
            return str(file_value)
        return os.getenv(name) or default

    return {
        "username": get("QA_USERNAME").strip(),
        "password": get("QA_PASSWORD"),
        # Always launch visibly, even if QA_HEADLESS is accidentally set to true.
        "headless": "false",
    }


def wants_saved_login(task: str) -> bool:
    """Recognize normal login requests without requiring a magic phrase."""
    if re.search(r"\b(do not|don't|without|skip|avoid|never)\s+(?:\w+\s+){0,2}(log\s*in|login|sign\s*in|authenticate|(?:use\s+)?(?:saved\s+)?credentials)\b", task, re.I):
        return False
    return bool(re.search(r"\b(log\s*in|login|sign\s*in|authenticate|(?:saved|env|environment)\s+(?:file\s+)?credentials|(?:fill|enter|submit)\s+(?:the\s+)?(?:username|credentials))\b", task, re.I))


def is_headless(value: str) -> bool:
    """Parse QA_HEADLESS using dotenv-friendly boolean values."""
    return value.strip().lower() in {"true", "1", "yes", "on"}


def validate_target_url(url: str, settings: dict[str, str] | None = None) -> str:
    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise ValueError("target_url must be a valid http:// or https:// URL")
    if parsed.username or parsed.password:
        raise ValueError("target_url must not contain embedded credentials")
    return url


def _inspect_page_worker_impl(
    url: str,
    task: str,
    knowledge: list[dict] | None,
    session_id: str,
    result_queue: queue.Queue,
    close_event: threading.Event,
    close_when_done: bool,
    heal_locators: bool | None = None,
    terminal_outcome: dict | None = None,
) -> None:
    runtime = get_settings()
    task_deadline=time.monotonic()+runtime.task_timeout_seconds
    settings = _settings()
    validate_target_url(url, settings)
    username = settings["username"]
    password = settings["password"]
    login_requested = wants_saved_login(task)
    credentials_available = bool(username and password)
    REPORT_DIR.mkdir(exist_ok=True)
    browser = None
    sent_result = False
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=False)
            page = browser.new_page(accept_downloads=True)
            navigation_timed_out=False
            try:
                response = page.goto(url, wait_until="domcontentloaded", timeout=min(runtime.navigation_timeout_ms,max(1,int((task_deadline-time.monotonic())*1000))))
            except PlaywrightTimeoutError:
                if page.url in {'about:blank',''}:raise
                response=None
                navigation_timed_out=True
            credentials={"username": username if login_requested else "", "password": password if login_requested else ""}
            evidence_dir=REPORT_DIR/f"discovery-{session_id}"
            if login_requested and not credentials_available:
                outcome={"actions":[],"downloads":[],"discovery":{"counts":{"browser_sessions":1,"discovery_snapshots":0,"discovery_action_attempts":0,"failed_discovery_attempts":0,"pytest_runs":0}},
                         "test_cases":[{"id":"TASK-LOGIN","name":"Use saved login credentials","status":"FAIL","details":"Configure both QA_USERNAME and QA_PASSWORD in the private .env"}]}
            else:
                outcome=discover_workflow(page,task,credentials,knowledge,plan_browser_task,evidence_dir,close_event,deadline=task_deadline,healing_enabled=heal_locators,terminal_outcome=terminal_outcome)
            actions=outcome["actions"]
            test_cases=outcome["test_cases"]
            if response is not None:
                test_cases.insert(0,{"id":"PAGE-001","name":"Open requested page","status":"PASS" if response.status<400 else "FAIL","details":f"HTTP {response.status}"})
            counts = {
                status: sum(case["status"] == status for case in test_cases)
                for status in ("PASS", "FAIL", "SKIPPED")
            }
            overall = "FAIL" if counts["FAIL"] else ("PARTIAL" if counts["SKIPPED"] else "PASS")
            screenshot_path = REPORT_DIR / f"page-{session_id}.png"
            page.screenshot(path=str(screenshot_path), full_page=True, mask=[page.locator("input,textarea")])
            result = {
                "title": page.title(),
                "url": safe_url(page.url),
                "http_status": response.status if response else None,
                "initial_navigation_timed_out":navigation_timed_out,
                "headless": False,
                "task": task,
                "task_plan": actions,
                "downloads": outcome["downloads"],
                "discovery": outcome["discovery"],
                "discovery_manifest": outcome.get("manifest_url"),
                "test_cases": test_cases,
                "test_summary": {
                    "status": overall,
                    "passed": counts["PASS"],
                    "failed": counts["FAIL"],
                    "skipped": counts["SKIPPED"],
                    "total": len(test_cases),
                },
                "screenshot": f"/reports/{screenshot_path.name}",
            }
            if not close_when_done:
                result["browser_session_id"] = session_id
                browser.on("disconnected", lambda *_: close_event.set())
                with _ACTIVE_BROWSER_SESSIONS_LOCK:
                    _ACTIVE_BROWSER_SESSIONS[session_id] = close_event
            result_queue.put(redact(result, credentials))
            sent_result = True
            if not close_when_done:
                while not close_event.wait(0.5) and browser.is_connected():
                    pass
    except Exception as exc:
        if not sent_result:
            result_queue.put(exc)
    finally:
        if browser is not None:
            try:
                browser.close()
            except Exception:
                pass
        with _ACTIVE_BROWSER_SESSIONS_LOCK:
            _ACTIVE_BROWSER_SESSIONS.pop(session_id, None)


def _inspect_page_worker(
    url: str,
    task: str,
    knowledge: list[dict] | None,
    session_id: str,
    result_queue: queue.Queue,
    close_event: threading.Event,
    close_when_done: bool,
    heal_locators: bool | None = None,
    terminal_outcome: dict | None = None,
) -> None:
    try:
        _inspect_page_worker_impl(url, task, knowledge, session_id, result_queue, close_event, close_when_done, heal_locators, terminal_outcome)
    except Exception as exc:
        result_queue.put(exc)


def _inspect_page_sync(url: str, task: str, knowledge: list[dict] | None = None, *, close_when_done=None, heal_locators=None, terminal_outcome=None) -> dict:
    """Run the browser on its owner thread and leave it open unless requested to close."""
    validate_target_url(url, _settings())
    close_when_done = close_when_done if close_when_done is not None else bool(re.search(
        r"(?:\bclose\s+(?:the\s+)?(?:browser|window)\b|\bthen\s+close\s*$|\bclose\s*$)",
        task,
        re.I,
    ))
    session_id = uuid4().hex
    result_queue: queue.Queue = queue.Queue(maxsize=1)
    close_event = threading.Event()
    worker = threading.Thread(
        target=_inspect_page_worker,
        args=(url, task, knowledge, session_id, result_queue, close_event, close_when_done, heal_locators, terminal_outcome),
        daemon=True,
        name=f"qa-browser-{session_id[:8]}",
    )
    worker.start()
    try:
        result = result_queue.get(timeout=get_settings().task_timeout_seconds)
    except queue.Empty as exc:
        close_event.set()
        raise TimeoutError("The requested browser task exceeded the configured task timeout") from exc
    if isinstance(result, BaseException):
        raise result
    return result


async def inspect_page(url: str, task: str, knowledge: list[dict] | None = None) -> dict:
    """Execute the requested QA task in visible Playwright outside the ASGI event loop."""
    return await asyncio.to_thread(_inspect_page_sync, url, task, knowledge)


async def inspect_case(url: str, task: str, knowledge=None, *, heal_locators=True, terminal_outcome=None):
    """Browser lifecycle is owned by the runner, not an AI-generated page action."""
    return await asyncio.to_thread(_inspect_page_sync, url, task, knowledge,
                                   close_when_done=True, heal_locators=heal_locators, terminal_outcome=terminal_outcome)
