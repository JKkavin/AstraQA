"""Evidence-based failure classification, separate from optional AI hypotheses."""
from __future__ import annotations

import re


def diagnose_failure(message: str, error_type: str = "") -> dict:
    text = (error_type + " " + message).lower()
    rules = [
        ("assertion", r"\bassertionerror\b|\bassert\s", False,
         "An assertion did not match the observed result.", "Compare expected and actual evidence. This alone does not establish an application defect."),
        ("ambiguous_locator", r"strict mode violation|no longer unique|multiple elements", False,
         "The target matched multiple elements.", "Inspect the current DOM and use a uniquely scoped locator."),
        ("unobserved_locator", r"selector observed|not observed|invented|unknown selector", False,
         "The requested locator was not supported by the observed DOM.", "Inspect again; do not guess a replacement."),
        ("network", r"net::err_|connection (?:reset|refused)|err_connection|err_name_not_resolved", True,
         "The browser reported a network error.", "Check connectivity and application availability before one bounded rerun."),
        ("navigation_timeout", r"page\.goto: timeout|timeout.*(?:navigating to|navigation)|navigation.*timeout", True,
         "Navigation did not complete within its timeout.", "Check server readiness and network latency; a bounded rerun may distinguish an intermittent failure."),
        ("browser_unavailable", r"browser.*(?:has been closed|disconnected)|target page, context or browser has been closed|browserclosederror", True,
         "The browser or page closed unexpectedly.", "Check browser stability; rerun only the affected tests once if enabled."),
        ("locator_timeout", r"locator\..*timeout|waiting for locator|element.*(?:not visible|not found)|could not fill|observed target", False,
         "The requested element was unavailable or not actionable.", "Inspect the DOM and loading state; repair only an unambiguous observed semantic match."),
        ("assertion", r"assertionerror|assert |expected|wrong employee", False,
         "An assertion did not match the observed result.", "Compare expected and actual evidence. This alone does not establish an application defect."),
        ("configuration", r"not configured|not activated|api key|quota|budget|fixture failed|modulenotfound|importerror", False,
         "Execution reported a configuration or service-access problem.", "Correct configuration, dependencies, credentials, or provider limits before retrying."),
    ]
    for category, pattern, retry, observation, next_step in rules:
        if re.search(pattern, text, re.S):
            break
    else:
        category, retry = "unclassified", False
        observation = "Execution failed; the available evidence is insufficient to identify the cause."
        next_step = "Review the failure message, screenshot, and DOM evidence before changing the test."
    return {"category": category, "observation": observation, "next_step": next_step,
            "evidence": message[:1200], "automatic_rerun_eligible": retry,
            "cause_confirmed": False}


def root_cause_report(cases: list[dict]) -> dict:
    findings = []
    for case in cases:
        if case.get("status") == "FAIL":
            findings.append({"test": case.get("name", case.get("id", "Failed step")),
                             **diagnose_failure(case.get("details", ""))})
    return {"status": "evidence_available" if findings else "no_failures",
            "findings": findings, "note": "Categories describe observed symptoms, not a proven application root cause. AI explanations are hypotheses."}


def execution_diagnosis(result: dict) -> dict:
    cases = result.get('test_cases', [])
    if result.get('status') in {'failed', 'timed_out'} and not any(case.get('status') == 'FAIL' for case in cases):
        cases = [{'name': 'Pytest execution', 'status': 'FAIL', 'details': result.get('output', 'Execution failed without structured test evidence.')}]
    return root_cause_report(cases)
