"""DOM-backed discovery and redaction. No application-specific selectors or credentials."""
from __future__ import annotations
import re
from urllib.parse import urlsplit, urlunsplit
from playwright.sync_api import expect


def redact(value, credentials=None):
    if isinstance(value,dict):return {k:redact(v,credentials) for k,v in value.items()}
    if isinstance(value,list):return [redact(v,credentials) for v in value]
    if not isinstance(value,str):return value
    value=re.sub(r'eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+','[REDACTED_TOKEN]',value)
    value=re.sub(r'(?i)((?:access_token|id_token|refresh_token|authorization|password|session_state|code)=)[^&\s"<>]+',r'\1[REDACTED]',value)
    for key,secret in (credentials or {}).items():
        if secret:
            value=re.sub(r'(?<![A-Za-z0-9_])'+re.escape(secret)+r'(?![A-Za-z0-9_])','[REDACTED]',value) if key=='username' else value.replace(secret,'[REDACTED]')
    return value


def safe_url(url):
    parsed=urlsplit(url)
    fragment='' if any(k in parsed.fragment.lower() for k in ('token','code=','state=')) else parsed.fragment
    return urlunsplit((parsed.scheme,parsed.netloc.split('@')[-1],parsed.path,'',fragment))


def snapshot(page,credentials=None):
    data=page.evaluate(r'''() => {
      const visible=e=>!!e.getClientRects().length&&getComputedStyle(e).visibility!=='hidden'&&getComputedStyle(e).display!=='none';
      const quote=s=>JSON.stringify(s);
      function contextLabel(e){
        if(!['input','textarea','select'].includes(e.localName))return '';
        let root=e.parentElement;
        for(let depth=0;root&&depth<3;depth++,root=root.parentElement){
          if(root.querySelectorAll('input,textarea,select').length!==1)break;
          const labels=Array.from(root.querySelectorAll('label')).filter(visible);
          if(labels.length===1)return labels[0].innerText.trim().slice(0,180);
        }
        return '';
      }
      function selector(e){
        if(e.id){const s='#'+CSS.escape(e.id);if(document.querySelectorAll(s).length===1)return s;}
        for(const attr of ['name','aria-label','placeholder','title','data-testid']){
          if(e.getAttribute(attr)){const s=e.localName+'['+attr+'='+quote(e.getAttribute(attr))+']';if(document.querySelectorAll(s).length===1)return s;}
        }
        if(e.parentElement){const parent=e.parentElement;const peers=Array.from(parent.children).filter(x=>x.localName===e.localName);return selector(parent)+' > '+e.localName+':nth-of-type('+(peers.indexOf(e)+1)+')';}
        return e.localName;
      }
      const dropdowns=[];
      for(const select of document.querySelectorAll('select')){
        let root=select.parentElement;
        for(let depth=0;root&&depth<4;depth++,root=root.parentElement){
          const label=Array.from(root.querySelectorAll('label')).find(visible);
          if(label&&root.querySelectorAll('select').length===1){
            dropdowns.push({selector:selector(root),trigger:selector(label),kind:'custom_dropdown',
              name:select.name,label:label.innerText.trim(),options:Array.from(select.options).map(o=>o.text.trim())});break;
          }
        }
      }
      const allControls=Array.from(document.querySelectorAll('input,button,a,select,textarea,label,[role],li[title]')).filter(visible);
      const controls=allControls.slice(0,180).map(e=>({
        selector:selector(e),tag:e.localName,role:e.getAttribute('role'),type:e.getAttribute('type'),
        label:e.getAttribute('aria-label'),placeholder:e.getAttribute('placeholder'),name:e.getAttribute('name'),
        test_id:e.getAttribute('data-testid'),associated_label:Array.from(e.labels||[]).map(l=>l.innerText.trim()).join(' '),
        context_label:contextLabel(e),
        disabled:!!e.disabled||e.getAttribute('aria-disabled')==='true',
        text:(e.localName==='input'&&['submit','button','reset'].includes(e.type)?e.value:(e.innerText||'')).trim().slice(0,180),
        readonly:e.readOnly||false,hiddenAccessible:e.getAttribute('aria-hidden')==='true',
        options:e.localName==='select'?Array.from(e.options).map(o=>({text:o.text.trim(),value:o.value})):undefined
      }));
      const busy=Array.from(document.querySelectorAll('[aria-busy="true"],[role="progressbar"],[class]')).filter(e=>visible(e)&&(
        e.getAttribute('aria-busy')==='true'||e.getAttribute('role')==='progressbar'||/(?:^|[-_\s])(?:spinner|loader|loading)(?:$|[-_\s])/i.test(String(e.className||'')))).slice(0,20).map(selector);
      const assertion_targets=Array.from(document.querySelectorAll('body,h1,h2,h3,h4,h5,h6,p,[role="alert"]')).filter(visible).slice(0,40).map(e=>({selector:selector(e),text:(e.innerText||'').trim().slice(0,180)}));
      return {controls,dropdowns,busy,assertion_targets,ready_state:document.readyState,controls_truncated:allControls.length>180,total_control_count:allControls.length,visible_text:(document.body?.innerText||'').slice(0,6000)};
    }''')
    data.update(title=page.title(),url=safe_url(page.url))
    return redact(data,credentials)


def wait_for_observed_busy(page,state,timeout):
    if state.get('busy'):
        page.wait_for_function("""selectors=>selectors.every(s=>Array.from(document.querySelectorAll(s)).every(e=>
            !e.getClientRects().length||getComputedStyle(e).display==='none'||getComputedStyle(e).visibility==='hidden'))""",
            arg=state['busy'],timeout=timeout)


def validate_targets(action,state,page):
    known={c['selector'] for c in state['controls']}
    known.update(d['selector'] for d in state['dropdowns'])
    if action.get('action')=='verify_text':known.update(c['selector'] for c in state.get('assertion_targets',[]))
    for key in ('target','search_target','option_target'):
        target=action.get(key)
        if not target:continue
        if 'selector' not in target or target['selector'] not in known:
            raise ValueError('Discovery requires a selector observed in the current page snapshot')
        count=page.locator(target['selector']).count()
        if count==0:
            raise ValueError('Observed target no longer exists; inspect the updated page before acting')
        if count!=1:
            raise ValueError('Observed target is no longer unique; inspect the updated page before acting')
