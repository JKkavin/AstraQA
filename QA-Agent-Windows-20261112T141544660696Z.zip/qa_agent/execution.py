from __future__ import annotations

import re
import json
import os
import xml.etree.ElementTree as ET
import threading
from datetime import datetime, timezone
import subprocess
import sys
import time
from pathlib import Path
from uuid import uuid4


from qa_agent.settings import get_settings
from qa_agent.diagnostics import diagnose_failure, execution_diagnosis

CODE_ROOT = Path(__file__).resolve().parents[1]
ROOT = CODE_ROOT
_RUN_LOCK = threading.Lock()


def _record_generated_run(slug, result):
    history = ROOT / "reports" / "generated" / f"{slug}-runs.jsonl"
    history.parent.mkdir(parents=True, exist_ok=True)
    with _RUN_LOCK:
        with history.open('a', encoding='utf-8') as handle:
            handle.write(json.dumps({'time':datetime.now(timezone.utc).isoformat(), 'status':result['status'], 'exit_code':result['exit_code']})+'\n')
        count = len(history.read_text(encoding='utf-8').splitlines())
    result['attempt_counts'] = {'pytest_runs':count}
    return result


def _finalize(slug, result):
    report=result.get('html_report')
    if report and (ROOT/report.lstrip('/')).is_file():
        from qa_agent.final_report import write_final_report
        result['final_report']=write_final_report(ROOT,slug,result)
    return result



def _test_results(report: Path, exit_code: int) -> dict:
    """Read only the current run's JUnit evidence, never infer passes from log text."""
    if not report.is_file():
        return {}
    try:
        root = ET.parse(report).getroot()
    except (ET.ParseError, OSError):
        return {}
    cases = []
    for index, test in enumerate(root.iter("testcase"), 1):
        problem = test.find("failure")
        if problem is None:
            problem = test.find("error")
        skipped = test.find("skipped")
        status = "FAIL" if problem is not None else "SKIPPED" if skipped is not None else "PASS"
        detail = problem if problem is not None else skipped
        cases.append({"id": f"TEST-{index:03d}", "name": test.get("name", "Unnamed test"),
                      "status": status, "details": detail.get("message", "")[:2000] if detail is not None else ""})
        module = test.get("classname", "")
        if re.fullmatch(r"[A-Za-z_]\w*(?:\.[A-Za-z_]\w*)*", module):
            source = ROOT.joinpath(*module.split('.')).with_suffix('.py')
            if source.is_file():
                cases[-1]['node_id'] = source.relative_to(ROOT).as_posix() + '::' + cases[-1]['name']
    passed = sum(case["status"] == "PASS" for case in cases)
    failed = sum(case["status"] == "FAIL" for case in cases)
    skipped = sum(case["status"] == "SKIPPED" for case in cases)
    status = "FAIL" if exit_code != 0 or failed else "PASS" if passed else "SKIPPED"
    return {"test_cases": cases, "test_summary": {"status": status, "passed": passed,
            "failed": failed, "skipped": skipped, "total": len(cases)}}


def run_saved_test_suite() -> dict:
    """Run only this project's checked-in tests and save a self-contained HTML report."""
    run_id = uuid4().hex
    report = ROOT / "reports" / f"test-report-{run_id}.html"
    report.parent.mkdir(exist_ok=True)
    junit = report.with_suffix(".xml")
    command = [
        sys.executable, "-m", "pytest", "tests", "-q",
        f"--html={report}", "--self-contained-html", f"--junitxml={junit}",
    ]
    try:
        result = subprocess.run(
            command,
            cwd=ROOT,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            env={**os.environ, "PYTHONIOENCODING": "utf-8"},
            timeout=get_settings().suite_timeout_seconds,
            check=False,
        )
        output = (result.stdout + "\n" + result.stderr).strip()
        return {
            "status": "passed" if result.returncode == 0 else "failed",
            "exit_code": result.returncode,
            **_test_results(junit, result.returncode),
            "output": output[-12000:],
            "html_report": f"/reports/{report.name}" if report.exists() else None,
        }
    except subprocess.TimeoutExpired as exc:
        return {"status": "timed_out", "exit_code": None, "output": str(exc)[:1000], "html_report": None}


def _failure_evidence(folder: Path) -> list[dict]:
    records=[]
    for path in sorted(folder.glob('*.json')):
        if path.stat().st_size>2_000_000:continue
        try:record=json.loads(path.read_text(encoding='utf-8'))
        except (ValueError,OSError):continue
        if record.get('kind') in {'readiness','downloads'}:continue
        image=record.get('screenshot')
        records.append({'node_id':record.get('node_id',''), 'phase':record.get('phase',''),
                        'dom_file':f'/reports/generated/{folder.name}/{path.name}',
                        'screenshot':f'/reports/generated/{folder.name}/{Path(image).name}' if image else None,
                        'missing_before_dispatch':bool(record.get('failed_locator',{}).get('missing_before_dispatch'))})
    return records


def _wait_evidence(folder):
    records=[]
    for path in folder.glob('*-waits.json'):
        try:
            record=json.loads(path.read_text(encoding='utf-8'))
            records.append({'node_id':record['node_id'],'events':record['events'],
                            'evidence_file':f'/reports/generated/{folder.name}/{path.name}'})
        except (ValueError,KeyError,OSError):pass
    return records


def _download_evidence(folder):
    records=[]
    for path in folder.glob('*-downloads.json'):
        try:
            for item in json.loads(path.read_text(encoding='utf-8')).get('downloads',[]):
                identifier=item.get('id','')
                if not re.fullmatch(r'[a-f0-9]{32}\.[a-zA-Z0-9]{1,10}',identifier):continue
                file=CODE_ROOT/'downloads'/identifier
                if file.is_file() and file.stat().st_size>0:
                    records.append({'id':identifier,'filename':str(item.get('filename',identifier)),
                                    'bytes':file.stat().st_size})
        except (ValueError,KeyError,OSError,TypeError):pass
    return records


def _run_generated_suite_once(slug: str, target_url: str, nodes: list[str] | None = None, *, capture_healing: bool = False, workspace: Path | None = None, healing_plan: Path | None = None) -> dict:
    """Run one generated application-specific regression suite with visible Chromium."""
    if not re.fullmatch(r"[a-z0-9][a-z0-9_]{0,47}", slug):
        raise ValueError("Invalid generated suite name")
    suite = ROOT / "generated_suites" / slug
    test_file = suite / "tests" / f"test_{slug}_regression.py"
    if not test_file.is_file():
        raise FileNotFoundError("Generate this application's suite before running it")
    run_id = uuid4().hex
    report = ROOT / "reports" / "generated" / f"{slug}-{run_id}-regression.html"
    report.parent.mkdir(parents=True, exist_ok=True)
    junit = report.with_suffix(".xml")
    active_root=workspace or ROOT
    capture=report.parent/(report.stem+'-evidence')
    capture.mkdir(parents=True,exist_ok=True)
    environment={**os.environ, 'PYTHONIOENCODING':'utf-8',
                 'PYTHONPATH':str(CODE_ROOT)+os.pathsep+os.environ.get('PYTHONPATH',''),
                 'QA_CAPTURE_DIR':str(capture), 'QA_SUITE_ROOT':str(active_root/'generated_suites'/slug),
                 'QA_HEALING_CAPTURE':'1' if capture_healing or healing_plan else '0',
                 'QA_SUITE_DEADLINE_EPOCH':str(time.time()+get_settings().suite_timeout_seconds),
                 'QA_HEALING_PLAN':str(healing_plan) if healing_plan else ''}
    command = [
        sys.executable,
        "-m",
        "pytest",
        "-p", "qa_agent.pytest_evidence",
        *(nodes or [str(suite)]),
        "-q",
        "-v",
        "--target-url",
        target_url,
        f"--html={report}",
        "--self-contained-html",
        f"--junitxml={junit}",
    ]
    try:
        result = subprocess.run(
            command,
            cwd=active_root,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            env=environment,
            timeout=get_settings().suite_timeout_seconds,
            check=False,
        )
        output = (result.stdout + "\n" + result.stderr).strip()
        return _record_generated_run(slug, {
            "status": "passed" if result.returncode == 0 else "failed",
            "exit_code": result.returncode,
            "failure_evidence":_failure_evidence(capture),
            "adaptive_waiting":_wait_evidence(capture),
            "downloads":_download_evidence(capture),
            **_test_results(junit, result.returncode),
            "output": output[-12000:],
            "html_report": f"/reports/generated/{report.name}" if report.exists() else None,
        })
    except subprocess.TimeoutExpired as exc:
        return _record_generated_run(slug, {"status": "timed_out", "exit_code": None, "output": str(exc)[:1000], "html_report": None})


def run_generated_suite(slug: str, target_url: str, auto_rerun: bool = False, auto_heal: bool = False) -> dict:
    """Optionally rerun only transient failed cases once; preserve first-run evidence."""
    if not re.fullmatch(r"[a-z0-9][a-z0-9_]{0,47}",slug):raise ValueError('Invalid generated suite name')
    suite=ROOT/'generated_suites'/slug
    policy={}
    if auto_heal:
        config=suite/'suite_config.json'
        if config.is_file():policy=json.loads(config.read_text(encoding='utf-8')).get('healing_policy',{})
        if not isinstance(policy,dict):raise ValueError('Suite healing_policy must be an object')
    capture_healing=auto_heal and policy.get('safe_to_repeat') is True and policy.get('allow_ai_healing') is True
    manifest=None
    if capture_healing:
        from qa_agent.saved_healing import source_manifest
        if not suite.resolve().is_relative_to((ROOT/'generated_suites').resolve()):raise ValueError('Reviewed suite must remain inside generated_suites')
        manifest=source_manifest(suite)
    first = (_run_generated_suite_once(slug,target_url,capture_healing=True) if capture_healing
             else _run_generated_suite_once(slug,target_url))
    first['healing']={'requested':auto_heal,'proposals':[],'review_required':True,'original_suite_unchanged':True}
    if manifest is not None:first['healing']['source_manifest']=manifest
    proposals=[]; workspace=None; healing_plan=None; review_file=None
    if auto_heal and first['status']=='failed':
        from qa_agent import saved_healing
        failures={case.get('node_id') for case in first.get('test_cases',[]) if case.get('status')=='FAIL'}
        considered=0
        for evidence in first.get('failure_evidence',[]):
            if evidence['node_id'] not in failures or not evidence['node_id'].startswith(f'generated_suites/{slug}/'):continue
            if considered>=get_settings().suite_healing_max_cases:break
            considered+=1
            try:
                path=(ROOT/evidence['dom_file'].lstrip('/')).resolve()
                if not path.is_relative_to((ROOT/'reports').resolve()):raise ValueError('Invalid evidence path')
                record=json.loads(path.read_text(encoding='utf-8'))
                proposal=saved_healing.propose(record,policy,suite,saved_healing.request_ai)
                proposals.append(proposal)
                first['healing']['proposals'].append(proposal)
            except (ValueError,OSError,SyntaxError) as exc:
                first['healing']['proposals'].append({'node_id':evidence['node_id'],'status':'refused','reason':str(exc)[:600],
                                                     'ai_called':getattr(exc,'ai_called',False),'ai_usage':getattr(exc,'ai_usage',None)})
        if not first.get('failure_evidence'):
            first['healing']['reason']='No captured call-phase locator failure evidence'
        if proposals:
            try:
                workspace,healing_plan=saved_healing.prepare_snapshot(ROOT,slug,proposals,expected_manifest=manifest)
                first['healing']['temporary_suite']=str(workspace.relative_to(ROOT)/'generated_suites'/slug)
            except (ValueError,OSError,SyntaxError) as exc:
                for proposal in proposals:proposal.update(status='refused',reason=str(exc)[:600])
                if manifest is not None:
                    first['healing']['original_suite_unchanged']=saved_healing.source_manifest(suite)==manifest
                proposals=[]
        review_file=ROOT/'reports'/'generated'/f'{slug}-{uuid4().hex}-healing-review.json'
        review_file.parent.mkdir(parents=True,exist_ok=True)
        review_file.write_text(json.dumps(first['healing'],indent=2),encoding='utf-8')
        first['healing']['review_file']='/reports/generated/'+review_file.name
    first['root_cause_analysis'] = execution_diagnosis(first)
    first['automatic_rerun'] = {'requested': auto_rerun or auto_heal, 'executed': False, 'reason': 'Not enabled for this run' if not (auto_rerun or auto_heal) else 'No eligible transient failed test with a verified pytest node ID'}
    eligible = []
    prefix = f'generated_suites/{slug}/'
    for case in first.get('test_cases', []):
        node = case.get('node_id', '')
        if (auto_rerun and case['status'] == 'FAIL' and node.startswith(prefix)
                and diagnose_failure(case.get('details', ''))['automatic_rerun_eligible']):
            path = (ROOT / node.split('::', 1)[0]).resolve()
            if path.is_relative_to((ROOT / 'generated_suites' / slug).resolve()) and path.is_file():
                eligible.append(node)
    # A suite timeout may leave child work uncertain; never automatically replay it.
    healed_nodes={proposal['node_id'] for proposal in proposals}
    eligible=list(dict.fromkeys(eligible+list(healed_nodes)))
    if first['status'] != 'failed' or not eligible:
        return _finalize(slug,first)
    retry = (_run_generated_suite_once(slug,target_url,eligible,workspace=workspace,healing_plan=healing_plan)
             if workspace else _run_generated_suite_once(slug,target_url,eligible))
    updated = {case.get('node_id'): case for case in retry.get('test_cases', [])}
    cases = []
    for original in first.get('test_cases', []):
        replacement = updated.get(original.get('node_id')) if original.get('node_id') in eligible else None
        case = dict(original)
        if replacement:
            case.update(replacement)
            case['id'] = original['id']
            case['first_attempt'] = {'status': original['status'], 'details': original.get('details', '')}
            if replacement['status'] == 'PASS':
                case['status'] = 'HEALED' if original.get('node_id') in healed_nodes else 'FLAKY'
                case['details'] = ('Passed after one isolated locator-only repair; review required before saving.' if case['status']=='HEALED' else 'Passed only after one automatic rerun. Original failure is preserved.')
            elif replacement['status'] == 'SKIPPED':
                case['status'] = 'FAIL'
                case['details'] = original.get('details', '') + '\nRerun was skipped; original failure remains unresolved.'
        cases.append(case)
    failed = sum(case['status'] == 'FAIL' for case in cases)
    passed = sum(case['status'] in {'PASS', 'FLAKY', 'HEALED'} for case in cases)
    skipped = sum(case['status'] == 'SKIPPED' for case in cases)
    flaky = sum(case['status'] == 'FLAKY' for case in cases)
    healed=sum(case['status']=='HEALED' for case in cases)
    success = not failed and retry['status'] == 'passed'
    result = {**first, 'status': 'passed' if success else 'failed', 'exit_code': 0 if success else 1,
              'test_cases': cases, 'test_summary': {'status': ('PASS_AFTER_HEALING' if healed else 'PASS_WITH_RETRY') if success else 'FAIL',
              'passed': passed, 'failed': failed, 'skipped': skipped, 'flaky': flaky, 'total': len(cases)},
              'attempt_counts': retry.get('attempt_counts', first.get('attempt_counts', {})),
              'automatic_rerun': {'requested': True, 'executed': True, 'retried_tests': eligible,
                                  'retry_status': retry['status'], 'reason': 'One isolated locator repair retry' if healed_nodes else 'One bounded rerun of transient failed tests'},
              'run_reports': [{'label': 'Initial run', 'html_report': first.get('html_report')},
                              {'label': 'Automatic rerun (failed cases only)', 'html_report': retry.get('html_report')}],
              'output': ('Initial run:\n' + first.get('output', '') + '\nAutomatic rerun:\n' + retry.get('output', ''))[-12000:]}
    if healed:result['test_summary']['healed']=healed
    outcome={case.get('node_id'):case['status'] for case in cases}
    for proposal in proposals:proposal['status']='passed_after_healing' if outcome.get(proposal['node_id'])=='HEALED' else 'retry_failed'
    if review_file:review_file.write_text(json.dumps(result['healing'],indent=2),encoding='utf-8')
    result['failure_evidence']=first.get('failure_evidence',[])+retry.get('failure_evidence',[])
    result['adaptive_waiting']=first.get('adaptive_waiting',[])+retry.get('adaptive_waiting',[])
    result['downloads']=first.get('downloads',[])+retry.get('downloads',[])
    return _finalize(slug,result)
