"""Combined human-readable report retaining original failures and repair evidence."""
from __future__ import annotations

import base64
from html import escape
import json
from pathlib import Path
from uuid import uuid4


def write_final_report(root: Path, slug: str, result: dict) -> str:
    folder=root/'reports'/'generated'
    folder.mkdir(parents=True,exist_ok=True)
    path=folder/f'{slug}-{uuid4().hex}-final.html'
    text=lambda value: escape(str(value))
    summary=result.get('test_summary',{})
    healing=result.get('healing',{})
    proposals=healing.get('proposals',[])
    measured=sum((item.get('ai_usage') or {}).get('estimated_cost_usd',0) for item in proposals)
    unknown=sum(bool(item.get('ai_called')) and not item.get('ai_usage') for item in proposals)
    body=[f'<h1>{text(slug)} · Final QA report</h1>',f'<h2>{text(summary.get("status",result["status"]))}</h2>',
          '<p>Original failures remain part of this result. Passing after repair is not a clean first-run pass.</p>',
          f'<p>Passed: {text(summary.get("passed","unknown"))} · Failed: {text(summary.get("failed","unknown"))} · '
          f'Skipped: {text(summary.get("skipped","unknown"))} · Healed: {text(summary.get("healed",0))} · Flaky: {text(summary.get("flaky",0))}</p>',
          f'<p>Reported locator-proposal cost: ${measured:.6f}. Proposal attempts without reported usage: {unknown} (blocked or uncertain). '
          'This is not account balance or total AI-analysis cost.</p>',
          '<h2>Test results</h2><table><tr><th>Test</th><th>Final status</th><th>Original failure</th><th>Latest evidence</th></tr>']
    for case in result.get('test_cases',[]):
        body.append(f'<tr><td>{text(case["name"])}</td><td>{text(case["status"])}</td>'
                    f'<td><pre>{text(case.get("first_attempt",{}).get("details",""))}</pre></td>'
                    f'<td><pre>{text(case.get("details",""))}</pre></td></tr>')
    body.append('</table><h2>Execution reports</h2>')
    if result.get('downloads'):
        body.append('<h2>Saved report downloads</h2><p>Files remain in the protected downloads folder. Use Save file in the dashboard to retrieve them.</p>')
        for file in result['downloads']:
            body.append('<p>'+text(file.get('filename',''))+' · '+text(file.get('bytes',0))+' bytes · ID '+text(file.get('id',''))+'</p>')
    if result.get('workflow_mode') == 'website_first':
        body.append('<h2>Website discovery · pytest replay pending</h2><p>'+text(result.get('note', ''))+'</p>')
        for case in result.get('discovery_cases', []):
            expected = 'Nonempty report download' if case.get('expected_outcome')=='nonempty_download' else case['expected_text']
            body.append('<h3>'+text(case['name'])+'</h3><p>Expected final outcome: '+text(expected)+'</p>')
            for key, label in (('discovery_manifest', 'Discovery evidence'), ('screenshot', 'Final screenshot')):
                url = (case.get('evidence') or {}).get(key, '')
                if url.startswith('/reports/'):
                    body.append('<p><a href="'+escape(url, quote=True)+'">'+label+'</a></p>')
    for report in result.get('run_reports',[{'label':'Initial pytest report','html_report':result.get('html_report')}]):
        if report.get('html_report'):
            body.append(f'<p><a href="{escape(report["html_report"],quote=True)}">{text(report["label"])}</a></p>')
    source_note=('Source changed during the run; automatic repair was refused.' if healing.get('original_suite_unchanged') is False
                 else 'The repair engine did not edit the original suite. Any permanent edit requires human review.')
    body.append('<h2>Locator repair review</h2><p>'+text(source_note)+'</p>')
    if not proposals:body.append('<p>No locator repair was applied.</p>')
    for proposal in proposals:
        body.append(f'<h3>{text(proposal["node_id"])} · {text(proposal["status"])}</h3><pre>{text(json.dumps(proposal,indent=2))}</pre>')
    body.append('<h2>Failure evidence</h2>')
    for evidence in result.get('failure_evidence',[]):
        body.append(f'<h3>{text(evidence["node_id"])}</h3>')
        for key in ('dom_file','screenshot'):
            url=evidence.get(key)
            if not url:continue
            local=(root/url.lstrip('/')).resolve()
            if not local.is_relative_to((root/'reports').resolve()) or not local.is_file():continue
            if key=='screenshot' and local.stat().st_size<3_000_000:
                body.append('<img alt="Masked failure screenshot" src="data:image/png;base64,'+base64.b64encode(local.read_bytes()).decode()+'">')
            elif key=='dom_file':
                body.append('<details><summary>DOM and locator evidence</summary><pre>'+text(local.read_text(encoding='utf-8'))+'</pre></details>')
    diagnosis=result.get('root_cause_analysis',{})
    if result.get('adaptive_waiting'):
        body.append('<h2>Page-aware waiting decisions</h2><pre>'+text(json.dumps(result['adaptive_waiting'],indent=2))+'</pre>')
    body.append('<h2>Failure diagnosis</h2><p>Observed symptoms are not a confirmed application root cause.</p><pre>'+text(json.dumps(diagnosis,indent=2))+'</pre>')
    document='<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Final QA report</title><style>body{font:15px/1.6 Segoe UI,Arial,sans-serif;max-width:1180px;margin:35px auto;padding:0 22px;color:#27324a;background:#f7f8fc}h1,h2{color:#5148b6}table{width:100%;border-collapse:collapse;background:white}td,th{border:1px solid #dfe3ed;padding:12px;text-align:left;vertical-align:top}pre{white-space:pre-wrap;overflow-wrap:anywhere;font-size:12px}img{max-width:100%;border:1px solid #dfe3ed;margin:10px 0}a{color:#5148b6}details{padding:12px;background:white;margin-bottom:12px}</style>'+''.join(body)+'</html>'
    path.write_text(document,encoding='utf-8')
    path.with_suffix('.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    return '/reports/generated/'+path.name
