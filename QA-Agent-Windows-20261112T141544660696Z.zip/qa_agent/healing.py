"""Conservative locator repair using exact semantics in two observed snapshots."""
from __future__ import annotations

from copy import deepcopy


def repairable_control(action: dict, state: dict) -> dict | None:
    selector = action.get("target", {}).get("selector")
    return next((control for control in state.get("controls", []) if control["selector"] == selector), None)


def propose_repair(action: dict, before: dict, after: dict) -> tuple[dict, dict] | None:
    old = repairable_control(action, before)
    if not old:
        return None
    # Prefer stable identity. No fuzzy text, DOM position, or broad first-match fallback.
    identity = next((key for key in ("test_id", "label", "associated_label", "name", "placeholder", "text") if old.get(key)), None)
    if not identity:
        return None
    candidates = [control for control in after.get("controls", [])
                  if control.get("tag") == old.get("tag") and control.get("type") == old.get("type")
                  and control.get(identity) == old[identity] and not control.get("disabled")
                  and not control.get("hiddenAccessible")]
    if len(candidates) != 1 or candidates[0]["selector"] == old["selector"]:
        return None
    result = deepcopy(action)
    result["target"] = {"selector": candidates[0]["selector"]}
    evidence = {"original_selector": old["selector"], "replacement_selector": candidates[0]["selector"],
                "matched_by": identity, "matched_value": old[identity], "status": "proposed"}
    return result, evidence
