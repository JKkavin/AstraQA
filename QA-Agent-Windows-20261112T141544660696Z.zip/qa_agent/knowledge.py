from __future__ import annotations

import hashlib
import os
import re
from pathlib import Path

import chromadb
from chromadb.config import Settings
from dotenv import dotenv_values
from ollama import Client
from pypdf import PdfReader
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


ROOT = Path(__file__).resolve().parents[1]
KNOWLEDGE_DIR = ROOT / "knowledge"
VECTOR_DIR = ROOT / "vector_store"


class KnowledgeBase:
    """Local PDF RAG: Ollama embeddings in ChromaDB, with TF-IDF fallback."""

    def __init__(self, directory: Path = KNOWLEDGE_DIR, chunk_size: int = 900):
        self.directory = directory
        self.chunk_size = chunk_size
        self.chunks: list[dict] = []
        self.vectorizer: TfidfVectorizer | None = None
        self.matrix = None
        self.mode = "empty"
        self.client = chromadb.PersistentClient(
            path=str(VECTOR_DIR),
            settings=Settings(anonymized_telemetry=False),
        )
        self.collection = self.client.get_or_create_collection(
            name="qa_documents",
            metadata={"hnsw:space": "cosine"},
        )
        self.refresh()

    @staticmethod
    def _env(name: str, default: str) -> str:
        file_values = dotenv_values(ROOT / ".env")
        return os.getenv(name) or str(file_values.get(name) or default)

    def _embed(self, texts: list[str]) -> list[list[float]]:
        ollama = Client(host=self._env("OLLAMA_HOST", "http://127.0.0.1:11434"), timeout=30)
        response = ollama.embed(
            model=self._env("QA_EMBED_MODEL", "nomic-embed-text"),
            input=texts,
        )
        return response.embeddings

    def refresh(self) -> int:
        self.chunks = []
        self.directory.mkdir(parents=True, exist_ok=True)
        for pdf_path in sorted(self.directory.glob("*.pdf")):
            reader = PdfReader(str(pdf_path))
            for page_number, page in enumerate(reader.pages, start=1):
                text = re.sub(r"\s+", " ", page.extract_text() or "").strip()
                for start in range(0, len(text), self.chunk_size):
                    part = text[start : start + self.chunk_size]
                    if part:
                        self.chunks.append({
                            "source": pdf_path.name,
                            "page": page_number,
                            "text": part,
                        })

        existing_ids = self.collection.get(include=["metadatas"])["ids"]
        if existing_ids:
            self.collection.delete(ids=existing_ids)
        self.vectorizer = None
        self.matrix = None
        self.mode = "empty"
        if not self.chunks:
            return 0

        self.vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2))
        self.matrix = self.vectorizer.fit_transform([item["text"] for item in self.chunks])
        ids = [
            hashlib.sha256(f"{item['source']}:{item['page']}:{index}".encode()).hexdigest()
            for index, item in enumerate(self.chunks)
        ]
        try:
            embeddings = self._embed([item["text"] for item in self.chunks])
            self.collection.add(
                ids=ids,
                documents=[item["text"] for item in self.chunks],
                metadatas=[{"source": item["source"], "page": item["page"]} for item in self.chunks],
                embeddings=embeddings,
            )
            self.mode = f"ollama:{self._env('QA_EMBED_MODEL', 'nomic-embed-text')}+chromadb"
        except Exception:
            self.mode = "tfidf-fallback"
        return len(self.chunks)

    def search(self, question: str, top_k: int = 3) -> list[dict]:
        if not question.strip() or not self.chunks:
            return []
        if self.mode.startswith("ollama:"):
            try:
                query_embedding = self._embed([question])[0]
                results = self.collection.query(
                    query_embeddings=[query_embedding],
                    n_results=min(max(1, top_k), self.collection.count()),
                    include=["documents", "metadatas", "distances"],
                )
                return [
                    {
                        "source": metadata["source"],
                        "page": metadata["page"],
                        "text": document,
                        "score": round(1.0 - float(distance), 4),
                    }
                    for document, metadata, distance in zip(
                        results["documents"][0],
                        results["metadatas"][0],
                        results["distances"][0],
                    )
                ]
            except Exception:
                pass
        if self.vectorizer is None or self.matrix is None:
            return []
        query = self.vectorizer.transform([question])
        scores = cosine_similarity(query, self.matrix)[0]
        best = scores.argsort()[::-1][: max(1, top_k)]
        return [
            {**self.chunks[int(i)], "score": round(float(scores[i]), 4)}
            for i in best if scores[i] > 0
        ]


knowledge_base = KnowledgeBase()
