from __future__ import annotations

from pathlib import Path
import re
import os
import time
from uuid import uuid4

from playwright.sync_api import Page, expect
from qa_agent.settings import get_settings


class TaskPage:
    """Resolve model-planned actions through accessible page locators."""

    def __init__(self, page: Page, download_dir: Path | None = None, *, replay=True, wait_policy=None):
        self.page = page
        self.download_dir = download_dir or Path(__file__).resolve().parents[2] / "downloads"
        self.downloads = []
        self.deadline=time.monotonic()+get_settings().task_timeout_seconds if replay else None
        self.cancel=None
        self.readiness_events=[]
        self.replay=replay
        self.wait_policy=wait_policy or {}

    def _timeout(self, name, *, readiness=False, extra_ms=0):
        runtime=get_settings()
        value=self.wait_policy.get(name,getattr(runtime,name))
        value=max(1,min(int(value),600000))
        if readiness:
            value=max(value,min(int(self.wait_policy.get('readiness_timeout_ms',runtime.readiness_timeout_ms)),600000))
        value=min(600000,value+max(0,int(extra_ms)))
        limits=[]
        if self.deadline is not None:limits.append(self.deadline-time.monotonic())
        if os.getenv('QA_SUITE_DEADLINE_EPOCH'):limits.append(float(os.environ['QA_SUITE_DEADLINE_EPOCH'])-time.time())
        if limits:
            remaining=int(min(limits)*1000)
            if remaining<=0:raise TimeoutError('Saved test task/suite deadline exceeded')
            value=min(value,remaining)
        if self.cancel is not None and self.cancel.is_set():raise TimeoutError('Test was cancelled')
        return value

    def wait_until_ready(self):
        from qa_agent.readiness import wait_for_replay_ready
        wait_for_replay_ready(self.page,timeout_ms=self._timeout('readiness_timeout_ms'),
                              deadline=self.deadline,cancel=self.cancel)

    def _locator(self, target: dict):
        if "selector" in target:
            return self.page.locator(str(target["selector"]))
        if "role" in target and "name" in target:
            return self.page.get_by_role(str(target["role"]), name=str(target["name"]), exact=True)
        if "label" in target:
            return self.page.get_by_label(str(target["label"]), exact=True)
        if "placeholder" in target:
            return self.page.get_by_placeholder(str(target["placeholder"]), exact=True)
        if "text" in target:
            return self.page.get_by_text(str(target["text"]), exact=True)
        raise ValueError("Action target must identify a role/name, label, placeholder, or text")

    def execute(self, action: dict, credentials: dict[str, str]) -> str:
        settings = get_settings()
        kind = action["action"]
        from qa_agent.readiness import ensure_ready
        if self.replay:self.wait_until_ready()
        else:ensure_ready(self.page,credentials,deadline=self.deadline,cancel=self.cancel,events=self.readiness_events)
        action_timeout=lambda:self._timeout('action_timeout_ms',readiness=self.replay)
        search_timeout=lambda:self._timeout('search_timeout_ms',readiness=self.replay)
        if kind == "wait":
            duration=min(max(0,int(action['milliseconds'])),settings.max_wait_ms,self._timeout('max_wait_ms'))
            self.page.wait_for_timeout(duration)
            return f"Waited {duration} ms"

        if kind == "verify_text":
            expected = str(action.get("expected", action.get("target", {}).get("text", "")))
            if not expected.strip():
                raise ValueError("Expected text must be non-empty")
            expect(self.page.get_by_text(expected, exact=False).first).to_be_visible(timeout=action_timeout())
            return f"Verified visible text: {expected[:160]}"
        locator = self._locator(action["target"])
        if kind == "download":
            self.download_dir.mkdir(parents=True, exist_ok=True)
            with self.page.expect_download(timeout=self._timeout('download_timeout_ms',extra_ms=action_timeout())) as pending:
                locator.click(timeout=action_timeout())
            download = pending.value
            suffix = Path(download.suggested_filename).suffix.lower()
            if len(suffix) > 10 or not suffix[1:].isalnum():
                suffix = ".bin"
            file_id = uuid4().hex + suffix
            destination = self.download_dir / file_id
            download.save_as(str(destination))
            if not destination.exists() or not destination.stat().st_size:
                raise ValueError("The downloaded file is empty")
            self.downloads.append({"id": file_id, "filename": download.suggested_filename,
                                   "bytes": destination.stat().st_size})
            self.page._qa_downloads = getattr(self.page, '_qa_downloads', []) + [self.downloads[-1]]
            return f"Downloaded {download.suggested_filename} ({destination.stat().st_size} bytes); ID: {file_id}"
        if kind == "search_select":
            locator.click(timeout=action_timeout())
            search = self._locator(action["search_target"]) if action.get("search_target") else locator
            search.fill(str(action.get("value", "")), timeout=action_timeout())
            option = action.get("option_target")
            if not option:
                raise ValueError("Search selection requires an explicit option_target to avoid choosing the wrong record")
            result = self._locator(option)
            expect(result).to_be_visible(timeout=search_timeout())
            result.click(timeout=action_timeout())
            return "Entered search text and selected the requested result"
        if kind == "click":
            locator.click(timeout=action_timeout())
            return "Clicked the requested control"
        if kind == "fill":
            value = str(action.get("value", ""))
            if "{{QA_USERNAME}}" in value and not credentials.get("username"):
                raise ValueError("The task needs QA_USERNAME, but it is not configured")
            if "{{QA_PASSWORD}}" in value and not credentials.get("password"):
                raise ValueError("The task needs QA_PASSWORD, but it is not configured")
            value = value.replace("{{QA_USERNAME}}", credentials.get("username", ""))
            value = value.replace("{{QA_PASSWORD}}", credentials.get("password", ""))
            if "{{QA_" in value:
                raise ValueError("The task requests saved credentials, but both credentials are not configured")
            try:
                locator.fill(value, timeout=action_timeout())
            except Exception:
                if '{{QA_' in str(action.get('value','')):
                    raise ValueError('Could not fill the observed saved-credential field') from None
                raise
            return "Filled the requested field"
        if kind == "select":
            if locator.evaluate("e=>e.localName",timeout=action_timeout()) != "select":
                from qa_agent.discovery import snapshot
                if self.replay:
                    if not isinstance(action['target'].get('selector'),str):
                        raise ValueError('Custom dropdown replay requires its saved observed root selector')
                    # The saved root is fixed; only its asynchronously loaded option is awaited.
                    self.page.wait_for_function("""({selector,value})=>{
                        const root=document.querySelector(selector);
                        const selects=root?.querySelectorAll('select');
                        return selects?.length===1&&Array.from(selects[0].options).some(o=>o.text.trim()===value&&!o.disabled);
                    }""",arg={'selector':action['target'].get('selector'),'value':str(action.get('value',''))},timeout=search_timeout())
                state=snapshot(self.page)
                dropdown=next((d for d in state['dropdowns'] if d['selector']==action['target'].get('selector')),None)
                value=str(action.get('value',''))
                if not dropdown or value not in dropdown['options']:
                    raise ValueError('Requested option was not observed in this dropdown')
                self.page.locator(dropdown['trigger']).click(timeout=action_timeout())
                # Inspect the newly opened popup before selecting; never invent option locators.
                candidates=locator.locator('li, [role="option"]')
                options=candidates.filter(has_text=re.compile(r'^\s*'+re.escape(value)+r'\s*$'))
                expect(options).to_have_count(1,timeout=search_timeout())
                expect(options).to_be_visible(timeout=search_timeout())
                options.click(timeout=action_timeout())
                expect(self.page.locator(dropdown['trigger'])).to_have_text(value,timeout=action_timeout())
                return 'Selected and verified the observed dropdown option'
            value = str(action.get("value", ""))
            if action.get("by") == "label":
                locator.select_option(label=value, timeout=action_timeout())
            else:
                locator.select_option(value=value, timeout=action_timeout())
            return "Selected the requested option"
        if kind == "check":
            locator.check(timeout=action_timeout())
            return "Checked the requested control"
        if kind == "uncheck":
            locator.uncheck(timeout=action_timeout())
            return "Unchecked the requested control"
        raise ValueError(f"Unsupported action: {kind}")
