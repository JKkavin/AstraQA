"""Subprocess-only pytest evidence and pre-dispatch locator instrumentation."""
from __future__ import annotations

import base64
from functools import wraps
import hashlib
import inspect
import json
import os
from pathlib import Path

import pytest

_current = None
_failure = None
_patches = []
_waits=[]


def record_waits(events):
    if _current and events:_waits.extend(events)


class MissingLocatorBeforeDispatch(RuntimeError):
    pass


def _locations():
    root = Path(os.environ['QA_SUITE_ROOT']).resolve()
    locations = []
    frame = inspect.currentframe().f_back
    try:
        while frame:
            path = Path(frame.f_code.co_filename).resolve()
            if path.is_relative_to(root) and path.is_file():
                locations.append({'file': path.relative_to(root).as_posix(), 'line': frame.f_lineno,
                                  'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
            frame = frame.f_back
    finally:
        del frame
    return locations[:8]


def _bind_factory(original, kind):
    @wraps(original)
    def factory(self, *args, **kwargs):
        locator = original(self, *args, **kwargs)
        value = args[0] if args else next((kwargs[key] for key in ('role', 'selector', 'text', 'test_id') if key in kwargs), None)
        name = kwargs.get('name')
        if isinstance(value, str) and (name is None or isinstance(name, str)):
            locator._qa_origin = {'kind': kind, 'value': value, 'name': name, 'locations': _locations()}
            locator._qa_page = self
        return locator
    return factory


def _guard_operation(original, operation):
    @wraps(original)
    def guarded(self, *args, **kwargs):
        global _failure
        origin = getattr(self, '_qa_origin', None)
        page = getattr(self, '_qa_page', None)
        if not _current or not origin or not origin['locations']:
            return original(self, *args, **kwargs)
        from qa_agent.browser import _settings
        from qa_agent.discovery import snapshot
        from qa_agent.settings import get_settings
        credentials = _settings()
        from qa_agent.readiness import wait_for_replay_ready
        wait_for_replay_ready(page,timeout_ms=get_settings().readiness_timeout_ms)
        if os.getenv('QA_HEALING_CAPTURE') != '1':return original(self,*args,**kwargs)
        value = args[0] if args else kwargs.get('value', '')
        sensitive = bool(credentials.get('password') and credentials['password'] in str(value))
        event = {'node_id': _current.nodeid, 'operation': operation, 'origin': origin,
                 'password_value': sensitive, 'missing_before_dispatch': False}
        try:
            # A proposed repair must pass again on the fresh retry page, before dispatch.
            plan_path = os.getenv('QA_HEALING_PLAN')
            if plan_path and origin['kind'] == 'locator':
                from qa_agent.saved_healing import validate_candidate
                plan = json.loads(Path(plan_path).read_text(encoding='utf-8'))
                matching = [entry for entry in plan if entry['node_id'] == _current.nodeid
                            and entry['selector'] == origin['value']]
                if matching:
                    if len(matching) != 1:
                        raise ValueError('Ambiguous repair plan for this test')
                    validate_candidate(matching[0]['intent'], snapshot(page, credentials), origin['value'])
            timeout = kwargs.get('timeout')
            timeout = get_settings().action_timeout_ms if timeout is None else timeout
            try:
                self.wait_for(state='visible', timeout=timeout)
            except Exception:
                if self.count() == 0:
                    event['missing_before_dispatch'] = True
                    raise MissingLocatorBeforeDispatch('Observed target is missing before dispatch; inspect saved DOM evidence') from None
                raise
            return original(self, *args, **kwargs)
        except Exception as exc:
            event['_exception'] = exc
            _failure = event
            raise
    return guarded


def pytest_configure(config):
    if not os.getenv('QA_CAPTURE_DIR'):
        return
    from playwright.sync_api import Page, Locator
    factories = ('locator', 'get_by_placeholder', 'get_by_label', 'get_by_role', 'get_by_text', 'get_by_test_id')
    for name in factories:
        original = getattr(Page, name)
        _patches.append((Page, name, original))
        setattr(Page, name, _bind_factory(original, name.removeprefix('get_by_')))
    for name in ('fill', 'click', 'select_option', 'check', 'uncheck'):
        original = getattr(Locator, name)
        _patches.append((Locator, name, original))
        setattr(Locator, name, _guard_operation(original, name))


def pytest_unconfigure(config):
    while _patches:
        cls, name, original = _patches.pop()
        setattr(cls, name, original)


def pytest_runtest_setup(item):
    global _current, _failure, _waits
    _current, _failure, _waits = item, None, []


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    report = outcome.get_result()
    destination = os.getenv('QA_CAPTURE_DIR')
    if not destination:
        return
    from qa_agent.browser import _settings
    from qa_agent.discovery import redact, snapshot
    folder = Path(destination)
    folder.mkdir(parents=True, exist_ok=True)
    name = hashlib.sha256(item.nodeid.encode()).hexdigest()[:20]
    credentials = _settings()
    if _waits and (report.when=='call' or report.failed):
        (folder/(name+'-waits.json')).write_text(json.dumps({'kind':'readiness','node_id':item.nodeid,'events':redact(_waits,credentials)},indent=2),encoding='utf-8')
    page = item.funcargs.get('page')
    if report.when=='call' and page is not None and getattr(page,'_qa_downloads',None):
        (folder/(name+'-downloads.json')).write_text(json.dumps({'kind':'downloads','node_id':item.nodeid,
            'downloads':redact(page._qa_downloads,credentials)},indent=2),encoding='utf-8')
    if not report.failed:return
    event = dict(_failure) if _failure and call.excinfo and _failure['_exception'] is call.excinfo.value else {}
    event.pop('_exception', None)
    record = {'node_id': item.nodeid, 'phase': report.when,
              'error': redact(str(call.excinfo.value) if call.excinfo else 'Pytest failed', credentials)[:4000],
              'failed_locator': event, 'dom': None, 'screenshot': None,'adaptive_waiting':_waits}
    page = item.funcargs.get('page')
    if page is not None:
        try:
            record['dom'] = snapshot(page, credentials)
        except Exception:
            record['inspection_error'] = 'Page DOM unavailable after failure'
        try:
            image = page.screenshot(full_page=True, mask=[page.locator('input,textarea,[contenteditable]')], timeout=10000)
            (folder / (name + '.png')).write_bytes(image)
            record['screenshot'] = name + '.png'
            import pytest_html
            report.extras = getattr(report, 'extras', []) + [pytest_html.extras.png(base64.b64encode(image).decode(), name='Failure evidence')]
        except Exception:
            record['screenshot_error'] = 'Screenshot unavailable after failure'
    (folder / (name + '.json')).write_text(json.dumps(redact(record, credentials), indent=2), encoding='utf-8')
