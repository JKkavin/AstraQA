"""Page-aware, condition-based waiting with bounded AI decisions after a quick probe."""
from __future__ import annotations

import os
import sys
import time
from playwright.sync_api import TimeoutError as PlaywrightTimeoutError

from qa_agent.discovery import snapshot
from qa_agent.settings import get_settings

READY_JS = r"""() => {
  const visible=e=>!!e.getClientRects().length&&getComputedStyle(e).visibility!=='hidden'&&getComputedStyle(e).display!=='none';
  const busy=Array.from(document.querySelectorAll('[aria-busy="true"],[role="progressbar"],[class]')).some(e=>visible(e)&&(
    e.getAttribute('aria-busy')==='true'||e.getAttribute('role')==='progressbar'||/(?:^|[-_\s])(?:spinner|loader|loading)(?:$|[-_\s])/i.test(String(e.className||''))));
  const content=(document.body?.innerText||'').trim()||Array.from(document.querySelectorAll('input,button,a,select,textarea,[role]')).some(visible);
  return document.readyState!=='loading'&&!busy&&!!content;
}"""


def needs_wait(state: dict) -> bool:
    return bool(state.get('busy') or state.get('ready_state')=='loading'
                or (not state.get('controls') and not state.get('visible_text','').strip()))


def effective_deadline(deadline: float | None = None) -> float:
    runtime=get_settings()
    limit=time.monotonic()+runtime.readiness_timeout_ms/1000
    if deadline is not None:limit=min(limit,deadline)
    if os.getenv('QA_SUITE_DEADLINE_EPOCH'):
        limit=min(limit,time.monotonic()+max(0,float(os.environ['QA_SUITE_DEADLINE_EPOCH'])-time.time()))
    return limit


def wait_for_replay_ready(page, *, timeout_ms=None, deadline=None, cancel=None):
    """Repeatable, token-free page conditions for saved scripts, within hard limits."""
    limit=effective_deadline(deadline)
    if timeout_ms is not None:limit=min(limit,time.monotonic()+timeout_ms/1000)
    while True:
        if cancel is not None and cancel.is_set():raise TimeoutError('Saved test was cancelled')
        remaining=int((limit-time.monotonic())*1000)
        if remaining<=0:raise TimeoutError('Saved test page-readiness deadline exceeded')
        try:
            page.wait_for_function(READY_JS,timeout=min(remaining,500),polling=100)
            return
        except PlaywrightTimeoutError:
            if time.monotonic()>=limit:raise TimeoutError('Saved test page did not finish loading within its readiness limit') from None


def ensure_ready(page, credentials=None, *, deadline=None, cancel=None, events=None, decider=None) -> dict:
    runtime=get_settings()
    events=events if events is not None else []
    initial=len(events)
    state=snapshot(page,credentials)
    if not needs_wait(state):return state
    until=effective_deadline(deadline)
    decisions=0
    previous=None
    def remaining():return max(0,int((until-time.monotonic())*1000))
    def cancelled():return cancel is not None and cancel.is_set()
    def wait(milliseconds):
        window=min(milliseconds,remaining())
        if window<=0 or cancelled():return False
        try:
            page.wait_for_function(READY_JS,timeout=window,polling=100)
            return True
        except PlaywrightTimeoutError:
            return False
    try:
        probe=min(runtime.readiness_probe_ms,remaining())
        if probe>0 and wait(probe):
            events.append({'decision':'ready','source':'page_condition','wait_cap_ms':probe})
            return snapshot(page,credentials)
        while remaining()>0 and not cancelled():
            state=snapshot(page,credentials)
            if not needs_wait(state):return state
            if not runtime.adaptive_waits_enabled:
                if wait(remaining()):return snapshot(page,credentials)
                break
            if decisions>=runtime.max_ai_wait_decisions:break
            if decider is None:
                from qa_agent.llm import decide_page_wait
                decider=decide_page_wait
            signature=(state.get('url'),state.get('ready_state'),len(state.get('controls',[])),
                       tuple(state.get('busy',[])),state.get('visible_text','')[:1200])
            context={'url':state.get('url'),'title':state.get('title'),'ready_state':state.get('ready_state'),
                     'busy_indicators':state.get('busy',[]),'control_count':len(state.get('controls',[])),
                     'disabled_controls':sum(bool(c.get('disabled')) for c in state.get('controls',[])),
                     'visible_text':state.get('visible_text','')[:1200],
                     'progress_changed':None if previous is None else signature!=previous,
                     'decisions_used':decisions,'remaining_ms':remaining(),
                     'max_wait_ms':min(runtime.max_wait_ms,remaining())}
            previous=signature
            decision=decider(context)
            decisions+=1
            event={'source':'ai','decision':decision.get('decision','invalid') if isinstance(decision,dict) else 'invalid',
                   'reason':str(decision.get('reason',''))[:500] if isinstance(decision,dict) else 'Invalid decision',
                   'progress_changed':context['progress_changed']}
            events.append(event)
            if remaining()<=0 or cancelled():
                event['outcome']='deadline_or_cancellation'
                break
            state=snapshot(page,credentials)
            if not needs_wait(state):
                event.update(wait_cap_ms=0,outcome='page_became_ready_during_decision')
                events.append({'source':'page_condition','decision':'ready','note':'Page became ready during AI decision'})
                return state
            if not isinstance(decision,dict) or decision.get('decision')!='wait':
                reason=str(decision.get('reason','AI did not request additional waiting')) if isinstance(decision,dict) else 'Invalid wait decision'
                event.update(decision='stop',remaining_ms=remaining())
                raise TimeoutError('Page readiness stopped: '+reason[:300])
            milliseconds=decision.get('milliseconds')
            if isinstance(milliseconds,bool) or not isinstance(milliseconds,int) or milliseconds<=0:
                event['outcome']='invalid_wait_duration'
                raise TimeoutError('AI wait decision must request a positive bounded duration')
            duration=min(milliseconds,runtime.max_wait_ms,remaining())
            event.update(requested_ms=milliseconds,wait_cap_ms=duration)
            if wait(duration):
                events.append({'source':'page_condition','decision':'ready'})
                return snapshot(page,credentials)
        raise TimeoutError('Page did not become ready within the bounded wait/deadline or AI decision limit')
    finally:
        plugin=sys.modules.get('qa_agent.pytest_evidence')
        if plugin and hasattr(plugin,'record_waits'):plugin.record_waits(events[initial:])
