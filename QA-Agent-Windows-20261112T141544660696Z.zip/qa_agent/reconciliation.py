"""Local, deterministic reconciliation; report contents never go to the LLM."""
from __future__ import annotations

import csv
import json
import os
import re
from collections import Counter
from contextlib import closing
from decimal import Decimal, InvalidOperation
from pathlib import Path
from qa_agent.settings import get_settings

ROOT = Path(__file__).resolve().parents[1]
DOWNLOAD_DIR = ROOT / "downloads"
def max_bytes():
    return get_settings().max_report_mb * 1024 * 1024


def file_path(file_id: str) -> Path:
    if not re.fullmatch(r"[a-f0-9]{32}\.[a-z0-9]{1,9}", file_id):
        raise ValueError("Invalid downloaded file ID")
    path = DOWNLOAD_DIR / file_id
    if not path.is_file():
        raise ValueError("Downloaded file was not found")
    return path


def table(columns, rows) -> tuple[list[str], list[dict]]:
    columns = [str(c).strip() for c in columns]
    if not columns or any(not c for c in columns) or len(set(columns)) != len(columns):
        raise ValueError("Reports must have non-empty, unique column names")
    max_rows = get_settings().max_report_rows
    result = []
    for row in rows:
        if len(result) >= max_rows:
            raise ValueError(f"Report exceeds {max_rows} rows; narrow the report filters")
        if len(row) != len(columns):
            raise ValueError("Report row width does not match its header")
        result.append(dict(zip(columns, row)))
    return columns, result


def read_report(path: Path):
    if path.stat().st_size > max_bytes():
        raise ValueError(f"Report must be {get_settings().max_report_mb} MB or smaller")
    suffix = path.suffix.lower()
    if suffix in {".csv", ".tsv"}:
        with path.open(encoding="utf-8-sig", newline="") as handle:
            reader = csv.reader(handle, delimiter="\t" if suffix == ".tsv" else ",")
            return table(next(reader, []), reader)
    if suffix == ".xlsx":
        try:
            from openpyxl import load_workbook
        except ImportError as exc:
            raise ValueError("Install requirements-reports.txt for Excel report support") from exc
        with closing(load_workbook(path, read_only=True, data_only=True)) as book:
            settings = get_settings()
            if settings.excel_sheet and settings.excel_sheet not in book.sheetnames:
                raise ValueError(f"Excel sheet was not found: {settings.excel_sheet}")
            sheet = book[settings.excel_sheet] if settings.excel_sheet else book.worksheets[0]
            rows = iter(sheet.iter_rows(min_row=settings.excel_header_row, values_only=True))
            return table(next(rows, []), rows)
    if suffix == ".json":
        data = json.loads(path.read_text(encoding="utf-8-sig"))
        if not isinstance(data, list) or not data or not all(isinstance(row, dict) for row in data):
            raise ValueError("JSON report must be a non-empty array of objects")
        columns = list(data[0])
        if any(set(row) != set(columns) for row in data):
            raise ValueError("JSON rows must have identical columns")
        return table(columns, ([row[c] for c in columns] for row in data))
    raise ValueError("Compare CSV, TSV, XLSX, or JSON reports; PDF tables need an explicit extraction layout")


def canonical(value):
    # Text identifiers retain leading zeros; numeric tolerance is opt-in per column.
    if value is None:
        return None
    if hasattr(value, "isoformat"):
        return value.isoformat()
    return str(value).strip()


def compare_tables(left, right, keys: list[str], columns: list[str] | None = None,
                   numeric_columns: list[str] | None = None, tolerance: str = "0") -> dict:
    detail_limit = get_settings().report_detail_limit
    lc, lr = left
    rc, rr = right
    if not keys or len(keys) != len(set(keys)):
        raise ValueError("Choose unique key columns, such as patient_id or order_id")
    numeric_columns = numeric_columns or []
    try:
        tol = Decimal(tolerance)
        if not tol.is_finite() or tol < 0:
            raise ValueError()
    except (InvalidOperation, ValueError):
        raise ValueError("Numeric tolerance must be a finite non-negative number")
    for key in keys:
        if key not in lc or key not in rc:
            raise ValueError(f"Key column is missing: {key}")
    compared = columns if columns else sorted(set(lc) | set(rc))
    if not compared or len(set(compared)) != len(compared):
        raise ValueError("Comparison columns must be unique")
    if any(c not in compared for c in numeric_columns):
        raise ValueError("Numeric columns must be included in the comparison columns")
    missing_columns = {"download": sorted(set(compared) - set(lc)),
                       "reference": sorted(set(compared) - set(rc))}
    def index(rows):
        result = {}
        duplicates = Counter()
        for row in rows:
            key = tuple(canonical(row[k]) for k in keys)
            if any(v is None or v == "" for v in key):
                raise ValueError("Report contains an empty key; choose complete key columns")
            duplicates[key] += 1
            result[key] = row
        return result, [{"key": list(k), "count": n} for k, n in duplicates.items() if n > 1]
    li, ld = index(lr)
    ri, rd = index(rr)
    missing_reference = sorted(li.keys() - ri.keys())
    missing_download = sorted(ri.keys() - li.keys())
    differences = []
    mismatch_count = 0
    matched = 0
    for key in sorted(li.keys() & ri.keys()):
        row_match = True
        for column in compared:
            if column not in lc or column not in rc:
                row_match = False
                continue
            a, b = canonical(li[key][column]), canonical(ri[key][column])
            equal = a == b
            if column in numeric_columns and a is not None and b is not None:
                try:
                    av, bv = Decimal(a), Decimal(b)
                    equal = av.is_finite() and bv.is_finite() and abs(av - bv) <= tol
                except InvalidOperation:
                    equal = False
            if not equal:
                row_match = False
                mismatch_count += 1
                if len(differences) < detail_limit:
                    differences.append({"key": list(key), "column": column, "download": a, "reference": b})
        matched += int(row_match)
    passed = not (missing_reference or missing_download or ld or rd or mismatch_count or any(missing_columns.values()))
    if not lr and not rr:
        status = "INCONCLUSIVE"
    else:
        status = "PASS" if passed else "FAIL"
    return {"status": status, "download_rows": len(lr), "reference_rows": len(rr),
            "matched_rows": matched, "mismatched_cells": mismatch_count,
            "missing_columns": missing_columns,
            "missing_from_download_count": len(missing_download), "missing_from_reference_count": len(missing_reference),
            "missing_from_download": [list(k) for k in missing_download[:detail_limit]],
            "missing_from_reference": [list(k) for k in missing_reference[:detail_limit]],
            "duplicate_download_keys": ld[:detail_limit], "duplicate_reference_keys": rd[:detail_limit],
            "differences": differences, "detail_limit": detail_limit, "keys": keys, "columns": compared}


def sources() -> dict:
    path = Path(os.getenv("QA_REPORT_SOURCES_FILE", str(ROOT / "report_sources.json")))
    if not path.exists():
        return {}
    data = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(data, dict):
        raise ValueError("Report sources configuration must be an object")
    return data


def query_report(source_id: str, parameters: dict):
    config = sources().get(source_id)
    if not config:
        raise ValueError("Choose a configured server report source")
    names = config.get("parameters", [])
    if set(parameters) != set(names):
        raise ValueError("Query parameters must match: " + ", ".join(names))
    if any(not isinstance(v, (str, int, float, bool, type(None))) for v in parameters.values()):
        raise ValueError("Query parameters must be scalar values")
    query = config["query"]
    # Queries are trusted, administrator-owned configuration, never model/user SQL.
    # Database permissions must enforce read-only access, including any functions called by SELECT.
    if not re.match(r"^\s*(SELECT|WITH)\b", query, re.I) or ";" in query:
        raise ValueError("Configure a single read-only SELECT/CTE query without semicolons")
    def env(name):
        value = os.getenv(name, "")
        if not value:
            raise ValueError(f"Configure {name} in the server's private .env")
        return value
    try:
        if config["provider"] == "sqlserver":
            import pyodbc
            connection = pyodbc.connect(env(config.get("connection_env", "QA_SQLSERVER_CONNECTION_STRING")),
                                        timeout=get_settings().sql_login_timeout_seconds, readonly=True)
            connection.timeout = get_settings().sql_query_timeout_seconds
            args = [parameters[name] for name in names]
        elif config["provider"] == "databricks":
            from databricks import sql
            connection = sql.connect(server_hostname=env("DATABRICKS_SERVER_HOSTNAME"),
                                     http_path=env("DATABRICKS_HTTP_PATH"), access_token=env("DATABRICKS_TOKEN"))
            args = parameters
        else:
            raise ValueError("Supported server providers are sqlserver and databricks")
    except ImportError as exc:
        raise ValueError("Install requirements-reports.txt and the SQL Server ODBC driver when applicable") from exc
    except ValueError:
        raise
    except Exception as exc:
        raise ValueError("Server connection failed; check the configured connection and database access") from exc
    try:
        with closing(connection):
            with closing(connection.cursor()) as cursor:
                cursor.execute(query, args)
                columns = [item[0] for item in cursor.description or []]
                return table(columns, cursor.fetchmany(get_settings().max_report_rows + 1))
    except ValueError:
        raise
    except Exception as exc:
        raise ValueError("Server report query failed; check configured query, parameters, and read permissions") from exc
