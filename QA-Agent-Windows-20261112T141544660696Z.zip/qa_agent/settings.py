"""Validated runtime settings shared by the dashboard, browser, and generated suites."""
from __future__ import annotations

import json
import os
import threading
from pathlib import Path
from urllib.parse import urlparse

from pydantic import BaseModel, ConfigDict, Field, field_validator

ROOT = Path(__file__).resolve().parents[1]
SETTINGS_PATH = ROOT / 'runtime_settings.json'
_LOCK = threading.RLock()


class RuntimeSettings(BaseModel):
    model_config = ConfigDict(extra='forbid')
    target_url: str = ''
    action_timeout_ms: int = Field(default=10000, ge=100, le=600000)
    navigation_timeout_ms: int = Field(default=30000, ge=100, le=600000)
    search_timeout_ms: int = Field(default=15000, ge=100, le=600000)
    download_timeout_ms: int = Field(default=60000, ge=100, le=600000)
    task_timeout_seconds: int = Field(default=300, ge=1, le=86400)
    suite_timeout_seconds: int = Field(default=300, ge=1, le=86400)
    max_report_mb: int = Field(default=20, ge=1, le=500)
    max_report_rows: int = Field(default=100000, ge=1, le=2000000)
    report_detail_limit: int = Field(default=200, ge=1, le=10000)
    excel_sheet: str = ''
    excel_header_row: int = Field(default=1, ge=1, le=100000)
    sql_login_timeout_seconds: int = Field(default=15, ge=1, le=600)
    sql_query_timeout_seconds: int = Field(default=60, ge=1, le=86400)
    max_browser_actions: int = Field(default=15, ge=1, le=200)
    discovery_max_rounds: int = Field(default=40, ge=1, le=200)
    discovery_recovery_attempts: int = Field(default=1, ge=0, le=3)
    locator_healing_enabled: bool = True
    suite_healing_max_cases: int = Field(default=2, ge=1, le=5)
    readiness_timeout_ms: int = Field(default=60000, ge=100, le=600000)
    adaptive_waits_enabled: bool = True
    readiness_probe_ms: int = Field(default=2000, ge=100, le=10000)
    max_ai_wait_decisions: int = Field(default=3, ge=0, le=10)
    max_wait_ms: int = Field(default=10000, ge=0, le=600000)

    @field_validator('target_url')
    @classmethod
    def valid_url(cls, value):
        value = value.strip()
        if value:
            parsed = urlparse(value)
            if parsed.scheme not in {'http','https'} or not parsed.hostname or parsed.username or parsed.password:
                raise ValueError('Use an http(s) URL without embedded credentials')
        return value


def get_settings() -> RuntimeSettings:
    with _LOCK:
        # Environment defaults apply to fields not overridden by saved dashboard settings.
        values = {name: os.environ['QA_' + name.upper()] for name in RuntimeSettings.model_fields
                  if 'QA_' + name.upper() in os.environ}
        if SETTINGS_PATH.exists():
            values.update(json.loads(SETTINGS_PATH.read_text(encoding='utf-8')))
        return RuntimeSettings.model_validate(values)


def save_settings(settings: RuntimeSettings) -> RuntimeSettings:
    with _LOCK:
        temporary = SETTINGS_PATH.with_suffix('.tmp')
        temporary.write_text(settings.model_dump_json(indent=2), encoding='utf-8')
        temporary.replace(SETTINGS_PATH)
    return settings
