from __future__ import annotations

import json
import re
from pathlib import Path
from qa_agent.settings import get_settings


ROOT = Path(__file__).resolve().parents[1]
GENERATED_DIR = ROOT / "generated_suites"


def _slugify(value: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "_", value.strip().lower()).strip("_")[:48]
    if not slug:
        raise ValueError("Enter an application name before generating a suite")
    if slug.upper() in {"CON", "PRN", "AUX", "NUL", *(f"COM{i}" for i in range(1, 10)), *(f"LPT{i}" for i in range(1, 10))}:
        slug = f"{slug}_qa"
    return slug


def _page_object_source() -> str:
    return '''from __future__ import annotations

import json
from pathlib import Path
from playwright.sync_api import Page
from qa_agent.pages.task_page import TaskPage
from qa_agent.browser import _settings


class BasePage:
    """Execute scenario-provided targets without application-specific selector fallbacks."""

    def __init__(self, page: Page):
        self.page = page
        config = Path(__file__).resolve().parents[1] / 'suite_config.json'
        policy = json.loads(config.read_text(encoding='utf-8')).get('wait_policy', {})
        self.task_executor = TaskPage(page, replay=True, wait_policy=policy)

    def wait_until_ready(self) -> None:
        self.task_executor.wait_until_ready()

    def _locator(self, target: dict):
        return self.task_executor._locator(target)

    def fill(self, target: dict, value: str) -> None:
        self.perform({"action": "fill", "target": target, "value": value})

    def click(self, target: dict) -> None:
        self.perform({"action": "click", "target": target})

    def select(self, target: dict, value: str) -> None:
        self.perform({"action": "select", "target": target, "value": value})

    def check(self, target: dict) -> None:
        self.perform({"action": "check", "target": target})

    def uncheck(self, target: dict) -> None:
        self.perform({"action": "uncheck", "target": target})

    def verify_text(self, expected: str) -> None:
        self.perform({"action": "verify_text", "expected": expected})

    def wait(self, milliseconds: int) -> None:
        self.perform({"action": "wait", "milliseconds": milliseconds})

    def perform(self, step: dict) -> None:
        self.task_executor.execute(step, _settings())
'''


def _conftest_source() -> str:
    return '''import json
import base64
import pytest_html
from pathlib import Path
from urllib.parse import urlparse

import pytest
from dotenv import load_dotenv
from playwright.sync_api import sync_playwright
from qa_agent.settings import get_settings


PROJECT_ROOT = Path(__file__).resolve().parents[2]
load_dotenv(PROJECT_ROOT / ".env", override=True)


def pytest_addoption(parser):
    parser.addoption("--target-url", action="store", default="", help="Override the generated suite's default URL")


@pytest.fixture(scope="session")
def target_url(pytestconfig):
    configured = Path(__file__).with_name("suite_config.json")
    default_url = json.loads(configured.read_text(encoding="utf-8")).get("target_url", "") if configured.exists() else ""
    value = pytestconfig.getoption("--target-url") or get_settings().target_url or default_url
    parsed = urlparse(value)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname or parsed.username or parsed.password:
        pytest.fail("Set a valid URL in this suite's suite_config.json or pass --target-url http(s)://...", pytrace=False)
    return value


@pytest.fixture(scope="session")
def browser():
    with sync_playwright() as playwright:
        instance = playwright.chromium.launch(headless=False)
        yield instance
        instance.close()


@pytest.fixture
def page(browser):
    context = browser.new_context(accept_downloads=True)
    page = context.new_page()
    yield page
    context.close()


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    report = outcome.get_result()
    if report.when == "call" and report.failed and item.funcargs.get("page") is not None:
        page = item.funcargs["page"]
        try:
            screenshot = page.screenshot(full_page=True, mask=[page.locator("input,textarea")])
            extras = getattr(report, "extras", [])
            extras.append(pytest_html.extras.png(base64.b64encode(screenshot).decode(), name="Failure screenshot"))
            report.extras = extras
        except Exception:
            pass
''' 


def _application_page_source(slug: str) -> str:
    class_name = "".join(part.title() for part in slug.split("_")) + "Page"
    return f'''from playwright.sync_api import Page, TimeoutError as PlaywrightTimeoutError
from qa_agent.settings import get_settings
from generated_suites.{slug}.pages.base_page import BasePage


class {class_name}(BasePage):
    """Application-specific page object for named locators and workflows."""

    def __init__(self, page: Page, target_url: str):
        super().__init__(page)
        self.target_url = target_url

    def open_page(self) -> None:
        try:
            response = self.page.goto(self.target_url, wait_until="domcontentloaded", timeout=self.task_executor._timeout('navigation_timeout_ms'))
        except PlaywrightTimeoutError:
            if self.page.url in {{'about:blank', ''}}:
                raise
            response = None
        if response is not None:
            assert response.status < 400, f"Application returned HTTP {{response.status}}"
        self.wait_until_ready()
''' 


def _test_source(slug: str, cases: list[dict]) -> str:
    class_name = "".join(part.title() for part in slug.split("_")) + "Page"
    lines = [f"from generated_suites.{slug}.pages.{slug}_page import {class_name}", ""]
    used_names = set()
    for index, case in enumerate(cases, start=1):
        name = re.sub(r"[^a-z0-9]+", "_", case["name"].lower()).strip("_")[:70]
        name = name or f"case_{index:02d}"
        if name in used_names:
            name = f"{name}_{index}"
        used_names.add(name)
        lines.extend(["", f"def test_{name}(page, target_url):",
                      f"    app = {class_name}(page, target_url)", "    app.open_page()"])
        for step in case["steps"]:
            action = step["action"]
            lines.append('    app.wait_until_ready()  # Wait for loading conditions on every replay.')
            if action == "wait":
                lines.append(f"    app.wait({step['milliseconds']})")
            elif action == "verify_text":
                lines.append(f"    app.verify_text({step['expected']!r})")
            elif action in {"search_select", "download"} or (action == "select" and step.get("by") == "label"):
                lines.append(f"    app.perform({step!r})")
            elif action in {"fill", "select"}:
                lines.append(f"    app.{action}({step['target']!r}, {step.get('value', '')!r})")
            else:
                lines.append(f"    app.{action}({step['target']!r})")
    body = "\n".join(lines).lstrip()
    return f'''import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[3]
project_path = str(PROJECT_ROOT)
if project_path in sys.path:
    sys.path.remove(project_path)
sys.path.insert(0, project_path)

{body}
'''


def _format_plan(cases: list[dict]) -> str:
    lines = []
    for case in cases:
        lines.append(f"{case['id']} [{case['priority']}] {case['name']}")
        for number, step in enumerate(case["steps"], start=1):
            action = step["action"].replace("_", " ").title()
            target = step.get("target", {})
            target_name = target.get("name") or target.get("label") or target.get("placeholder") or target.get("text")
            detail = f" — {target_name}" if target_name else ""
            if action == "Verify Text":
                detail = f" — {step['expected']}"
            if action == "Wait":
                detail = f" — {step['milliseconds']} ms"
            lines.append(f"  {number}. {action}{detail}")
        lines.append("")
    return "\n".join(lines).strip()


def save_regression_suite(application: str, cases: list[dict], target_url: str = "") -> dict:
    """Write reusable pytest/POM sources from validated, data-only generated cases."""
    slug = _slugify(application)
    GENERATED_DIR.mkdir(exist_ok=True)
    (GENERATED_DIR / "__init__.py").write_text("", encoding="utf-8")
    app_dir = GENERATED_DIR / slug
    pages_dir = app_dir / "pages"
    pages_dir.mkdir(parents=True, exist_ok=True)
    (app_dir / "__init__.py").write_text("", encoding="utf-8")
    (pages_dir / "__init__.py").write_text("", encoding="utf-8")
    tests_dir = app_dir / "tests"
    tests_dir.mkdir(exist_ok=True)
    (tests_dir / "__init__.py").write_text("", encoding="utf-8")
    test_file = f"tests/test_{slug}_regression.py"
    page_object_file = f"pages/{slug}_page.py"
    (app_dir / "cases.json").write_text(json.dumps(cases, ensure_ascii=False, indent=2), encoding="utf-8")
    (app_dir / "suite_config.json").write_text(
        json.dumps({"target_url": target_url,
                    "wait_policy": {"mode": "condition", "version": 1, **{key:getattr(get_settings(),key) for key in
                        ('readiness_timeout_ms','navigation_timeout_ms','action_timeout_ms','search_timeout_ms','download_timeout_ms')}},
                    "healing_policy": {"safe_to_repeat": False, "allow_ai_healing": False, "eligible_tests": [], "locator_contracts": {}}}, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    (app_dir / "conftest.py").write_text(_conftest_source(), encoding="utf-8")
    (app_dir / "pages" / "base_page.py").write_text(_page_object_source(), encoding="utf-8")
    (app_dir / page_object_file).write_text(_application_page_source(slug), encoding="utf-8")
    (app_dir / test_file).write_text(_test_source(slug, cases), encoding="utf-8")
    readme = (
        f"# {application} regression suite\n\n"
        "Generated Playwright + pytest suite with separate test functions, a reusable BasePage, and an application-specific Page Object. Review selectors and assertions before running. "
        "The script calls wait_until_ready before every step. suite_config.json saves its condition-wait policy; targets and dependent options are awaited on every replay, without AI loading decisions. Task/suite deadlines still apply.\n\n"
        "Run from the project root:\n\n"
        f"```powershell\n.\\.venv\\Scripts\\python.exe -m pytest generated_suites/{slug} --target-url \"https://your-authorized-app.example\" -v\n```\n\n"
        "Chromium always launches visibly (`headless=False`). The URL used during generation is saved in `suite_config.json` as the default; pass `--target-url` to override it. "
        "The private project `.env` is loaded with precedence over inherited PyCharm environment values. Saved QA_USERNAME and QA_PASSWORD values are used only when test steps explicitly require login.\n"
    )
    (app_dir / "README.md").write_text(readme, encoding="utf-8")
    return {
        "slug": slug,
        "case_count": len(cases),
        "test_file": f"/generated/{slug}/{test_file}",
        "page_object_file": f"/generated/{slug}/{page_object_file}",
        "cases_file": f"/generated/{slug}/cases.json",
        "readme_file": f"/generated/{slug}/README.md",
        "run_api": f"/qa/suite/{slug}/run",
        "test_plan": _format_plan(cases),
    }
