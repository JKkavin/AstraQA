"""Discover independent workflows before saving any reusable regression source."""
from __future__ import annotations

import json
from pathlib import Path
from uuid import uuid4

from qa_agent.diagnostics import root_cause_report
from qa_agent.final_report import write_final_report
from qa_agent.suites import save_regression_suite


async def discover_suite(application, target_url, cases, inspect, knowledge, root: Path, *, heal_locators=True):
    results, observations, verified = [], [], []
    counts = {'browser_sessions': 0, 'discovery_snapshots': 0,
              'discovery_action_attempts': 0, 'failed_discovery_attempts': 0, 'pytest_runs': 0}
    waiting = []
    for number, case in enumerate(cases, 1):
        is_download = case.expected_outcome == 'nonempty_download'
        requirement = ('Required final action: download the requested report and verify a nonempty saved file.' if is_download else
                       f'Required final assertion: verify visible text {json.dumps(case.expected_text)}.')
        task = (f"Test only this ONE end-to-end scenario: {case.name}\nSteps: {case.steps}\n{requirement} "
                "Do not replace the expected result. Declare done only after this outcome succeeds. "
                "The runner closes the browser; closing it is not a test action.")
        if case.use_saved_credentials:
            task += '\nSign in using saved credentials from the private environment file.'
        else:
            task += '\nDo not use saved credentials.'
        evidence = None
        try:
            evidence = await inspect(target_url, task, knowledge, heal_locators=heal_locators,
                                     terminal_outcome={'kind':case.expected_outcome,'expected_text':case.expected_text})
            actions = evidence.get('task_plan', [])
            complete = evidence.get('test_summary', {}).get('status') == 'PASS'
            final = actions[-1] if actions else {}
            asserted = (final.get('action') == 'download' and any(
                isinstance(item.get('bytes'), int) and item['bytes'] > 0 for item in evidence.get('downloads', []))
                if is_download else final.get('action') == 'verify_text' and final.get('expected') == case.expected_text)
            passed = complete and asserted
            details = ('Requested nonempty report download passed. Pytest replay has not run.' if passed and is_download else
                       'Requested final visible-text assertion passed. Pytest replay has not run.' if passed else
                       'Discovery did not complete with the requested final assertion; no suite was saved.')
            if not complete:
                details += '\n' + '\n'.join(str(row.get('details', '')) for row in evidence.get('test_cases', [])
                                            if row.get('status') == 'FAIL')[:1500]
            for key in counts:
                counts[key] += evidence.get('discovery', {}).get('counts', {}).get(key, 0)
            waiting.append({'node_id': f'CASE-{number:02d}',
                            'events': evidence.get('discovery', {}).get('adaptive_waiting', [])})
            if passed:
                verified.append({'id': f'CASE-{number:02d}', 'name': case.name,
                                 'priority': 'High', 'steps': actions})
        except Exception as exc:
            # Other independent cases still receive their own result and fresh session.
            passed = False
            details = f'Discovery could not finish ({type(exc).__name__}). No suite was saved.'
        observations.append({'id': f'CASE-{number:02d}', 'name': case.name,
                             'expected_outcome': case.expected_outcome,
                             'expected_text': case.expected_text, 'evidence': evidence})
        results.append({'id': f'CASE-{number:02d}', 'name': case.name,
                        'status': 'PASS' if passed else 'FAIL', 'details': details})
    passed = sum(row['status'] == 'PASS' for row in results)
    result = {'status': 'completed' if passed == len(cases) else 'failed',
              'workflow_mode': 'website_first', 'stage': 'discovery',
              'application': application, 'target_url': target_url,
              'test_summary': {'status': 'PASS' if passed == len(cases) else 'FAIL',
                               'passed': passed, 'failed': len(cases)-passed, 'skipped': 0, 'total': len(cases)},
              'test_cases': results, 'discovery_cases': observations, 'attempt_counts': counts,
              'locator_healing': [repair for item in observations for repair in
                                  (item.get('evidence') or {}).get('discovery', {}).get('locator_healing', [])],
              'downloads': [file for item in observations for file in (item.get('evidence') or {}).get('downloads', [])],
              'discovery_healing_enabled': heal_locators,
              'adaptive_waiting': waiting, 'generated_suite': None,
              'note': 'These are browser discovery results, not pytest results. Every case starts a fresh session. '
                      'A new suite is saved only when every requested final outcome passes.'}
    if passed == len(cases):
        # A unique name prevents discovery from replacing reviewed application suites.
        suite = save_regression_suite(f'{application[:28]} discovered {uuid4().hex[:8]}', verified, target_url)
        result['test_plan'] = suite.pop('test_plan')
        result['generated_suite'] = suite
        from qa_agent import suites
        (suites.GENERATED_DIR / suite['slug'] / 'verified_locators.json').write_text(
            json.dumps(observations, indent=2), encoding='utf-8')
    result['root_cause_analysis'] = root_cause_report(results)
    result['final_report'] = write_final_report(root, 'website-first', result)
    return result
