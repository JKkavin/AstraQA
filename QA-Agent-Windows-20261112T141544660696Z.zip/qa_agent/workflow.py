"""Bounded observe/act/verify workflow; discovery attempts are separate from pytest runs."""
from __future__ import annotations
import json
import time
from pathlib import Path
from qa_agent.discovery import snapshot, validate_targets, wait_for_observed_busy, redact
from qa_agent.pages.task_page import TaskPage
from qa_agent.settings import get_settings
from qa_agent.healing import propose_repair, repairable_control
from qa_agent.diagnostics import diagnose_failure, root_cause_report
from qa_agent.readiness import ensure_ready


def discover_workflow(page,task,credentials,knowledge,planner,evidence_dir:Path,cancel=None,deadline=None,healing_enabled=None,terminal_outcome=None):
    runtime=get_settings()
    healing_enabled=runtime.locator_healing_enabled if healing_enabled is None else healing_enabled
    executor=TaskPage(page,replay=False)
    attempts=[];successful=[];snapshots=[];cases=[]
    verified=False;done=False;recovery_used=0
    deadline=min(deadline,time.monotonic()+runtime.task_timeout_seconds) if deadline is not None else time.monotonic()+runtime.task_timeout_seconds
    waiting=[]
    executor.deadline=deadline
    executor.cancel=cancel
    executor.readiness_events=waiting
    evidence_dir.mkdir(parents=True,exist_ok=True)
    last_failure=None
    pending_repair=None
    healing=[]
    for round_number in range(1,runtime.discovery_max_rounds+1):
        if time.monotonic()>deadline or (cancel and cancel.is_set()):
            last_failure='Discovery reached the task deadline or was cancelled';break
        try:
            state=ensure_ready(page,credentials,deadline=deadline,cancel=cancel,events=waiting)
        except Exception as exc:
            last_failure=redact(str(exc),credentials)[:1200];break
        snapshots.append(state)
        context={'discovery':True,'history':attempts[-5:],'completed_actions':successful,
                 'dropdowns':state['dropdowns'],'controls':state['controls'],'busy':state['busy'],
                 'visible_text':state['visible_text'],'url':state['url'],'title':state['title']}
        context['assertion_targets']=state.get('assertion_targets',[])
        repair_evidence=None
        if pending_repair:
            repaired_action,repair_evidence=pending_repair
            pending_repair=None
            plan={'actions':[repaired_action]}
        else:
            plan=planner(task,context,bool(credentials.get('username') and credentials.get('password')),knowledge)
        if time.monotonic()>deadline or (cancel and cancel.is_set()):
            last_failure='Discovery reached the task deadline or was cancelled';break
        actions=plan.get('actions',[])
        if plan.get('done') and not actions:
            done=verified and bool(successful)
            if not done:last_failure='Planner claimed completion without an executed assertion or download'
            break
        if not actions:
            last_failure=plan.get('error') or 'No next action could be verified from the current controls';break
        action=actions[0]
        # Reject unchanged repeated actions unless the previous one failed and a read-only/fill recovery is allowed.
        same=bool(attempts and attempts[-1]['action']==action)
        if same and (attempts[-1]['status']=='PASS' or action.get('action') not in {'fill','select','verify_text','wait'}):
            last_failure='Planner repeated an action without progress; stopped to avoid duplicate side effects';break
        entry={'attempt':len(attempts)+1,'round':round_number,'action':action}
        dispatch_started=False
        try:
            validate_targets(action,state,page)
            if action.get('action')=='fill' and '{{QA_PASSWORD}}' in str(action.get('value','')):
                if page.locator(action['target']['selector']).get_attribute('type')!='password':
                    raise ValueError('Saved passwords may only be entered into observed password fields')
            dispatch_started=True
            detail=executor.execute(action,credentials)
            entry.update(status='PASS',details=detail)
            successful.append(action)
            verified=verified or action['action'] in {'verify_text','download'}
            if terminal_outcome:
                done = ((terminal_outcome['kind']=='visible_text' and action['action']=='verify_text'
                         and action.get('expected')==terminal_outcome.get('expected_text'))
                        or (terminal_outcome['kind']=='nonempty_download' and action['action']=='download'
                            and bool(executor.downloads) and executor.downloads[-1]['bytes']>0))
            recovery_used=0
            if repair_evidence is not None:
                repair_evidence['status']='applied'
                entry['locator_repair']=repair_evidence
        except Exception as exc:
            entry.update(status='FAIL',details=redact(str(exc),credentials)[:1200])
            entry['diagnosis']=diagnose_failure(entry['details'],type(exc).__name__)
            if repair_evidence is not None:
                repair_evidence['status']='failed'
            try:
                shot=evidence_dir/f'attempt-{len(attempts)+1}-failure.png'
                page.screenshot(path=str(shot),full_page=True,mask=[page.locator('input,textarea')])
                entry['screenshot']=f'/reports/{evidence_dir.name}/{shot.name}'
            except Exception:pass
            recovery_used+=1
            # Clicks and downloads are never automatically retried; re-inspection may choose a DIFFERENT target.
            if recovery_used>runtime.discovery_recovery_attempts:last_failure='Recovery budget exhausted'
            if (not last_failure and healing_enabled and repairable_control(action,state)
                    and action.get('action')!='download'
                    and (not dispatch_started or action.get('action') in {'fill','select','verify_text','check','uncheck'})
                    and page.locator(action['target']['selector']).count()==0):
                updated=snapshot(page,credentials)
                snapshots.append(updated)
                pending_repair=propose_repair(action,state,updated)
                if pending_repair:
                    healing.append(pending_repair[1])
        attempts.append(redact(entry,credentials))
        (evidence_dir/'attempts.json').write_text(json.dumps(attempts,indent=2),encoding='utf-8')
        if done:break
        if last_failure:break
    if not done:
        last_failure=last_failure or 'Discovery round limit reached before verified completion'
    status='PASS' if done else 'FAIL'
    for entry in attempts:
        if entry['status']!='PASS':continue
        cases.append({'id':f"DISC-{entry['attempt']:03d}",'name':entry['action']['action'].replace('_',' ').title(),
                      'status':'PASS' if entry['status']=='PASS' else 'SKIPPED',
                      'details':entry['details'] if entry['status']=='PASS' else 'Discovery attempt failed; recovery recorded: '+entry['details']})
    cases.append({'id':'DISC-OUTCOME','name':'Verify complete requested workflow','status':status,
                  'details':'Planner declared completion after executed assertion/download.' if done else last_failure})
    inspected=snapshots[-1] if snapshots else {}
    inspection={'status':'completed','snapshots':len(snapshots),'url':inspected.get('url',''),
                'controls':len(inspected.get('controls',[])),'dropdowns':len(inspected.get('dropdowns',[])),
                'busy_indicators':len(inspected.get('busy',[]))}
    diagnostic_cases=[{'name':f"Discovery attempt {entry['attempt']}",'status':'FAIL','details':entry['details']}
                      for entry in attempts if entry['status']=='FAIL']
    root_cause=root_cause_report(diagnostic_cases or cases)
    root_cause['recovered']=status=='PASS' and bool(diagnostic_cases)
    manifest={'status':status,'attempts':attempts,'successful_actions':successful,'snapshots':snapshots,
              'dom_inspection':inspection,'locator_healing':healing,'root_cause_analysis':root_cause,'adaptive_waiting':waiting,
              'counts':{'browser_sessions':1,'discovery_snapshots':len(snapshots),'discovery_action_attempts':len(attempts),
                        'failed_discovery_attempts':sum(a['status']=='FAIL' for a in attempts),'pytest_runs':0}}
    manifest=redact(manifest,credentials)
    (evidence_dir/'discovery.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    return {'actions':successful,'test_cases':cases,'downloads':executor.downloads,'discovery':manifest,
            'manifest_url':f'/reports/{evidence_dir.name}/discovery.json'}
