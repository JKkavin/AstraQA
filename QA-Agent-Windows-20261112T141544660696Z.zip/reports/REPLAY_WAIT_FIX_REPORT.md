# Saved-script loading waits — verification report

Verified 12 November 2026. **Result: PASS.**

## Fix

The generated script previously relied on general loading checks but could use the shorter action timeout for a control that appeared later, or reject a dropdown option before dependent options finished loading. The first discovery run and a subsequent saved-script run could therefore behave differently.

New generated tests explicitly call `app.wait_until_ready()` before each step. Their `suite_config.json` stores a versioned `wait_policy` for readiness, navigation, actions, search, and downloads, and the generated Page Object loads it. Waiting is based on conditions rather than repeating the elapsed seconds from discovery.

The shared replay executor now:

- Waits for document readiness, visible loading indicators to clear, and page content.
- Allows the next control to appear and become actionable within the readiness window.
- Waits for a requested custom-dropdown option to load before checking it against the observed options, opening the popup, and selecting it.
- Retains existing selected-value and nonempty-download checks.
- Bounds waits using task/suite deadlines and cancellation.
- Uses native browser conditions for saved-script loading; no AI loading decision is needed on replay. Discovery retains bounded AI-assisted waiting.

Existing scripts that use the shared `TaskPage` receive the fix without regeneration. Saved-pytest instrumentation also uses native readiness waits before supported locator operations. Arbitrary third-party code bypassing these helpers retains its own waits. Reviewed custom scripts were not silently regenerated or overwritten. Failure analysis or enabled locator healing can still use AI separately.

## Verification

| Check | Result |
|---|---|
| Identical generated script: first local run with 120 ms delays | PASS |
| Same script: second run with 500 ms delays | PASS |
| Same script: third run with 900 ms delays | PASS |
| Delayed initial page, dependent options, disabled Go button, report preparation | PASS |
| Nonempty downloads on all three generated-script runs | PASS |
| Generated test source hash unchanged across all three runs | PASS |
| AI calls prohibited during generated-script replay | PASS |
| Missing option respects deadline without selecting a different option | PASS |
| Full local regression suite | **131 passed** |
| Existing RMM saved script, fresh-browser rerun 1 | **PASS — 34,675-byte XLSX** |
| Same RMM saved script, fresh-browser rerun 2 | **PASS — 34,675-byte XLSX** |
| AI loading decisions on both RMM reruns | **0** |

The full local suite retains one existing third-party pytest fixture deprecation warning. The local timing fixture ignores favicon requests so its delay progression counts actual page runs only. A generated-source unit test was updated to supply a real module path/configuration when executing the Page Object template.

## Artifacts

- [Full regression report](http://127.0.0.1:8000/reports/expert-qa-verification.html).
- [First RMM rerun report](http://127.0.0.1:8000/reports/generated/rmm_audit360-6836cb3e2d604cc39ed02d7644f890a6-final.html).
- [Second RMM rerun report](http://127.0.0.1:8000/reports/generated/rmm_audit360-3e87abf1479548d9b72d487928f4c75b-final.html).
- [Latest downloaded Excel report](http://127.0.0.1:8000/qa/downloads/ba2f22138a5d43ac816084b454127f99.xlsx).
- Structured repeat-run results: `reports/rmm-replay-waits-verification.json`.
- Repeatability coverage: `tests/test_replay_waits.py`.

Use **Load saved suites → rmm_audit360 → Run selected suite** to repeat the existing workflow. Newly generated suites include explicit readiness calls and saved policy. A page that stays stuck or a permanently absent option still fails within configured limits; waiting does not weaken assertions or guarantee recovery from application errors.

## Portability of these results

This report records verification on the original machine. The source transfer package includes this summary, but excludes referenced raw HTML/images/downloads unless copied privately. Refer to [the transfer guide](../TRANSFER_TO_COMPANY_LAPTOP.md). A destination setup check and RMM baseline are required; original passing results do not establish company-laptop network or credential access.
