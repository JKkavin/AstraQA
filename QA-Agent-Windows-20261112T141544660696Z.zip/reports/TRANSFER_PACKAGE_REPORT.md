# Transfer-package verification

Updated 12 November 2026.

- Maintained application documents, all saved-suite READMEs, and report summaries reference the current transfer procedure.
- `COMPANY_LAPTOP_QUICK_START.md` gives ten steps; `TRANSFER_TO_COMPANY_LAPTOP.md` gives the complete installation, configuration, and destination baseline instructions.
- `setup_company_laptop.cmd` checks Python 3.11 64-bit, installs pinned dependencies and Chromium, initializes local private settings, checks dependency compatibility, and saves a local HTML verification report.
- `scripts/prepare_transfer.py` builds the source ZIP with manifest/per-file hashes, SHA-256 sidecar, and consistent usage-ledger backup. Credential files, downloaded company reports, raw DOM/screenshots/HTML evidence, caches, virtual environments, and temporary retries are excluded.
- Package coverage verified exclusions and restored committed SQLite/WAL history with integrity check `ok`.
- All pinned versions match the installed working environment; `pip check` passed.
- The package was extracted into a fresh folder. No private `.env` was present; new blank-key settings were generated. The extracted source passed **132 tests**, with one existing third-party pytest fixture deprecation warning.

The extracted-copy test reused this machine's installed interpreter/dependencies. It did not install dependencies on the company laptop or exercise its RMM/VPN connection. No paid AI call or live RMM run was made by transfer verification. A destination setup check followed by one RMM baseline is required before saying that laptop works the same.

Local detailed evidence: `reports/company-transfer-verification.html`. The source ZIP includes this summary but omits raw HTML/images; copy selected original evidence separately through an approved private method if needed.

Python installation reference: https://www.python.org/downloads/windows/. Browser requirements/reference: https://playwright.dev/python/docs/intro. Use the company's approved maintained Python 3.11 x64 build and package/certificate/proxy configuration.
