from __future__ import annotations

import secrets
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
env_file = ROOT / ".env"
example_file = ROOT / ".env.example"

if env_file.exists():
    print(".env already exists; left unchanged.")
else:
    content = example_file.read_text(encoding="utf-8")
    content = content.replace("QA_API_TOKEN=", f"QA_API_TOKEN={secrets.token_urlsafe(32)}")
    env_file.write_text(content, encoding="utf-8")
    print("Created private .env with a random local API token.")
