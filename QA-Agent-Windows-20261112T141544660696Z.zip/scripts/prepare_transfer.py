"""Build a portable source ZIP and consistent usage backup, without credential files."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import zipfile

ROOT = Path(__file__).resolve().parents[1]
ROOT_FILES = {
    'main.py','mcp_server.py','pytest.ini','.env.example','.gitignore',
    'requirements.txt','requirements-transfer.txt','requirements-reports.txt',
    'setup_company_laptop.cmd','start_qa_agent.cmd','docker-compose.yml',
    'report_sources.example.json',
}
SOURCE_FOLDERS = {'qa_agent','web','tests','generated_suites','scripts','n8n'}
BLOCKED_PARTS = {'.git','.venv','.idea','__pycache__','.pytest_cache','.qa_runs',
                 'downloads','vector_store','transfer','.codex','.agents','.aws'}
SOURCE_SUFFIXES = {'.py','.html','.css','.js','.json','.md','.cmd','.yml','.yaml'}


def source_files(root):
    root=Path(root).resolve()
    for current,dirs,files in os.walk(root,followlinks=False):
        directory=Path(current);parts=directory.relative_to(root).parts
        dirs[:]=sorted(name for name in dirs if name not in BLOCKED_PARTS
                       and not (directory/name).is_symlink()
                       and (parts or name in SOURCE_FOLDERS|{'reports'})
                       and (not parts or parts[0]!='reports'))
        for name in sorted(files):
            path=directory/name;relative=path.relative_to(root)
            if path.is_symlink() or not path.resolve().is_relative_to(root):continue
            if path.name.startswith('.env') and relative.as_posix()!='.env.example':continue
            if path.name=='verified_locators.json':continue
            if not parts:allowed=path.name in ROOT_FILES or path.suffix=='.md'
            elif parts[0] in SOURCE_FOLDERS:allowed=path.suffix.lower() in SOURCE_SUFFIXES
            else:allowed=parts[0]=='reports' and path.suffix=='.md'
            if allowed:yield relative,path


def build_package(root=ROOT):
    root=Path(root).resolve()
    if not (root/'main.py').is_file():raise ValueError('Use the QA application project root')
    output=root/'transfer'
    output.mkdir(exist_ok=True)
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    target=output/f'QA-Agent-Windows-{stamp}.zip'
    entries=[]
    usage_included=False
    def add(archive,name,data):
        archive.writestr(name,data)
        entries.append({'file':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
    with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED) as archive:
        for relative,path in source_files(root):add(archive,relative.as_posix(),path.read_bytes())
        for name in ('reports/.gitkeep','knowledge/.gitkeep'):
            add(archive,name,b'')
        ledger=root/'usage'/'openai.sqlite3'
        if ledger.is_file():
            if ledger.is_symlink() or not ledger.resolve().is_relative_to(root):
                raise ValueError('Usage ledger must stay inside this project')
            # SQLite backup preserves committed WAL transactions while the app is running.
            with sqlite3.connect(ledger.as_uri()+'?mode=ro',uri=True) as source:
                with sqlite3.connect(':memory:') as copy:
                    source.backup(copy)
                    add(archive,'usage/openai.sqlite3',copy.serialize())
            usage_included=True
        manifest={'created_at_utc':datetime.now(timezone.utc).isoformat(),
                  'usage_ledger_included':usage_included,
                  'credentials_included':False,
                  'excluded':'Private .env/configuration, PDFs, downloads, DOM evidence, screenshots, HTML run reports, vector stores, virtual environments, temporary retries and IDE/Git state',
                  'files':entries}
        archive.writestr('TRANSFER_MANIFEST.json',json.dumps(manifest,indent=2))
    checksum=hashlib.sha256(target.read_bytes()).hexdigest()
    target.with_suffix('.zip.sha256').write_text(f'{checksum}  {target.name}\n',encoding='ascii')
    return {'archive':str(target),'checksum':checksum,'file_count':len(entries),
            'usage_ledger_included':usage_included,'bytes':target.stat().st_size}


if __name__=='__main__':
    print(json.dumps(build_package(),indent=2))
