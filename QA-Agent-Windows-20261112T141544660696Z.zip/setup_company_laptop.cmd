@echo off
setlocal
set PYTHONDONTWRITEBYTECODE=1
cd /d "%~dp0"
echo [1/6] Checking Python 3.11 64-bit...
py -3.11 -c "import sys; assert sys.maxsize > 2**32" >nul 2>&1
if errorlevel 1 (
  echo Install company-approved Python 3.11 64-bit with the Python launcher, then retry.
  pause
  exit /b 1
)
if not exist .venv\Scripts\python.exe (
  py -3.11 -m venv .venv
  if errorlevel 1 goto failed
)
.venv\Scripts\python.exe -c "import sys; assert sys.version_info[:2] == (3, 11) and sys.maxsize > 2**32" >nul 2>&1
if errorlevel 1 (
  echo The local virtual environment is unusable or has the wrong Python version.
  echo Do not copy .venv from another laptop. Rebuild it here using approved Python 3.11 64-bit.
  goto failed
)
echo [2/6] Installing the pinned Python dependencies...
.venv\Scripts\python.exe -m pip install -r requirements-transfer.txt
if errorlevel 1 goto failed
echo [3/6] Installing Playwright Chromium...
.venv\Scripts\python.exe -m playwright install chromium
if errorlevel 1 goto failed
echo [4/6] Preparing private local settings...
.venv\Scripts\python.exe scripts\init_env.py
if errorlevel 1 goto failed
echo [5/6] Checking installed dependency compatibility...
.venv\Scripts\python.exe -m pip check
if errorlevel 1 goto failed
echo [6/6] Running local verification. Browser windows may open; no live RMM run is started.
if not exist reports mkdir reports
.venv\Scripts\python.exe -m pytest tests -q -p no:cacheprovider --html=reports/company-setup-check.html --self-contained-html
if errorlevel 1 goto failed
echo Setup and local tests passed. Run start_qa_agent.cmd next.
echo Local verification report: reports\company-setup-check.html
echo Add your permitted OpenAI key and RMM credentials to .env before live use.
pause
exit /b 0
:failed
echo Setup failed. Keep this window open and share the error text without credentials.
pause
exit /b 1
