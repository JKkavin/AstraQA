import asyncio
import threading
from pathlib import Path

from dotenv import dotenv_values
from fastapi.testclient import TestClient

import main
import qa_agent.browser as browser_module
from main import app
from qa_agent.browser import _settings, is_headless, validate_target_url


client = TestClient(app)


def test_headless_false_opens_visible_browser():
    assert is_headless("false") is False
    assert is_headless("0") is False
    assert is_headless("true") is True


def test_runtime_settings_force_visible_mode_even_if_env_requests_headless(monkeypatch):
    monkeypatch.setenv("QA_HEADLESS", "true")
    assert _settings()["headless"] == "false"


def test_page_inspection_runs_off_the_asgi_loop_thread(monkeypatch):
    main_thread_id = threading.get_ident()
    monkeypatch.setattr(
        browser_module,
        "_inspect_page_sync",
        lambda _target_url, _task, _knowledge=None: threading.get_ident() != main_thread_id,
    )

    assert asyncio.run(browser_module.inspect_page("https://example.test/", "Inspect the page", [])) is True


def test_health_endpoint_reports_ready_api():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_qa_run_rejects_non_http_target():
    response = client.post(
        "/qa/run",
        json={"target_url": "file:///C:/secret.txt"},
        headers={"Authorization": f"Bearer {dotenv_values(Path(__file__).parents[1] / '.env')['QA_API_TOKEN']}"},
    )
    assert response.status_code == 400


def test_page_task_accepts_authorized_target_url():
    assert validate_target_url("https://example.com/login").startswith("https://")


def test_target_url_cannot_contain_embedded_credentials():
    try:
        validate_target_url("https://user:secret@example.com/login")
    except ValueError as exc:
        assert "embedded credentials" in str(exc)
    else:
        raise AssertionError("URL-embedded credentials were accepted")


def test_pdf_upload_requires_local_token():
    response = client.post("/knowledge/upload", files={"file": ("requirements.pdf", b"%PDF-fake", "application/pdf")})
    assert response.status_code == 401


def test_failed_generated_suite_response_includes_rerun_details(monkeypatch):
    monkeypatch.setattr(
        main,
        "run_generated_suite",
        lambda _slug, _url: {
            "status": "failed",
            "exit_code": 1,
            "output": "synthetic test failure",
            "html_report": "/reports/generated/demoqa-regression.html",
        },
    )
    monkeypatch.setattr(main.knowledge_base, "search", lambda *_args, **_kwargs: [])
    monkeypatch.setattr(main, "analyze", lambda *_args, **_kwargs: "Failure summary")
    token = dotenv_values(Path(__file__).parents[1] / ".env")["QA_API_TOKEN"]

    response = client.post(
        "/qa/suite/demoqa/run",
        json={"target_url": "https://demoqa.com/text-box"},
        headers={"Authorization": f"Bearer {token}"},
    )

    assert response.status_code == 200
    assert response.json()["suite_slug"] == "demoqa"
    assert response.json()["target_url"] == "https://demoqa.com/text-box"
    assert response.json()["failure_analysis"] == "Failure summary"


def test_dashboard_includes_generated_suite_rerun_control():
    response = client.get("/")

    assert response.status_code == 200
    assert "Rerun saved tests" in response.text
