from pathlib import Path

import pytest
from playwright.sync_api import expect


@pytest.fixture
def dashboard(page):
    html = (Path(__file__).parents[1] / 'web' / 'index.html').read_text(encoding='utf-8')
    html = html.replace('<body>', '<body data-local-access="true">')

    def serve(route):
        path = route.request.url.split('qa.test', 1)[1]
        if path == '/':
            route.fulfill(body=html, content_type='text/html')
        elif path == '/health':
            route.fulfill(json={'pdf_chunks': 0})
        elif path == '/qa/settings':
            route.fulfill(json={'settings': {}, 'schema': {'properties': {}}})
        else:
            route.fulfill(status=500, json={'detail': 'Unexpected test request'})

    page.route('http://qa.test/**', serve)
    page.goto('http://qa.test/')
    page.locator('#url').fill('https://example.test/')
    page.locator('#requirements').fill('Users can log in and view the dashboard.')
    return page


def test_dashboard_replaces_results_and_prevents_overlapping_operations(dashboard):
    page = dashboard
    pending = []
    page.route('**/qa/plan', lambda route: pending.append(route))
    page.locator('#plan').click()
    expect(page.locator('#run')).to_be_disabled()
    expect(page.locator('#upload')).to_be_disabled()
    expect(page.locator('#compare-reports')).to_be_disabled()
    expect(page.locator('#result')).to_have_attribute('aria-busy', 'true')
    assert len(pending) == 1
    pending.pop().fulfill(json={'status': 'completed', 'test_plan': 'First result'})
    expect(page.locator('#result')).to_contain_text('First result')
    expect(page.locator('#plan')).to_be_enabled()
    page.locator('#plan').click()
    expect(page.locator('#result')).not_to_contain_text('First result')
    pending.pop().fulfill(json={'status': 'completed', 'test_plan': 'Second result'})
    expect(page.locator('#result')).to_contain_text('Second result')
    expect(page.locator('#result')).not_to_contain_text('First result')


def test_dashboard_recovers_from_non_json_server_error(dashboard):
    page = dashboard
    page.route('**/qa/plan', lambda route: route.fulfill(status=502, body='<html>Bad gateway</html>', content_type='text/html'))
    page.locator('#plan').click()
    expect(page.locator('#result')).to_contain_text('HTTP 502')
    expect(page.locator('#plan')).to_be_enabled()
    expect(page.locator('#metric-outcome')).to_have_text('Request failed')
    expect(page.locator('#result')).to_have_attribute('aria-busy', 'false')


def test_dashboard_validates_requests_before_submission(dashboard):
    page = dashboard
    page.locator('#url').fill('file:///secret')
    page.locator('#plan').click()
    expect(page.locator('#result')).to_contain_text('HTTP or HTTPS')
    page.locator('#upload').click()
    expect(page.locator('#result')).to_have_text('Choose a PDF first.')
    page.locator('#compare-reports').click()
    expect(page.locator('#result')).to_have_text('Enter at least one key column.')


def test_report_uploads_and_comparison_use_current_inputs(dashboard):
    page = dashboard
    uploads = []
    def uploaded(route):
        uploads.append(route.request.post_data_buffer)
        route.fulfill(json={'id': f'file-{len(uploads)}'})
    page.route('**/qa/reports/upload', uploaded)
    comparisons = []
    def compared(route):
        comparisons.append(route.request.post_data_json)
        route.fulfill(json={'status': 'PASS', 'download_rows': 1, 'reference_rows': 1,
                            'matched_rows': 1, 'mismatched_cells': 0})
    page.route('**/qa/reports/compare', compared)
    for field in ('report-left', 'report-right'):
        page.locator('#' + field).set_input_files({'name': 'sample.csv', 'mimeType': 'text/csv', 'buffer': b'id,amount\na,10\n'})
    page.locator('#report-keys').fill('id')
    page.locator('#compare-reports').click()
    expect(page.locator('#result')).to_contain_text('Result: PASS')
    assert comparisons[0]['downloaded_file_id'] == 'file-1'
    assert comparisons[0]['reference_file_id'] == 'file-2'
    assert comparisons[0]['keys'] == ['id']
    expect(page.locator('#compare-reports')).to_be_enabled()


def test_suite_result_shows_cases_and_counts(dashboard):
    page = dashboard
    page.route('**/tests/run', lambda route: route.fulfill(json={
        'status': 'passed', 'exit_code': 0, 'output': '1 passed',
        'test_summary': {'status': 'PASS', 'passed': 1, 'failed': 0, 'skipped': 0, 'total': 1},
        'test_cases': [{'id': 'TEST-001', 'name': 'Admin login' + '_' * 150, 'status': 'PASS', 'details': ''}],
        'html_report': '/reports/current-run.html'}))
    page.locator('#tests').click()
    expect(page.locator('#result')).to_contain_text('Overall: PASS')
    expect(page.locator('#result')).to_contain_text('Admin login')
    expect(page.locator('#result a')).to_have_attribute('href', '/reports/current-run.html')
    expect(page.locator('#token')).to_be_hidden()
    page.set_viewport_size({'width': 390, 'height': 844})
    assert page.evaluate('document.documentElement.scrollWidth <= innerWidth')
    assert page.locator('#result').evaluate('(element)=>element.scrollWidth <= element.clientWidth')


def test_ai_usage_panel_displays_measured_totals_and_activation_state(dashboard):
    page = dashboard
    data = {'provider': 'openai', 'model': 'gpt-6.1-terra', 'configured': False,
            'input_tokens': 1200, 'output_tokens': 300, 'cached_tokens': 0,
            'estimated_cost_usd': 0.0027, 'estimated_cost_inr': 0.2538,
            'reserved_usd': 0.03, 'remaining_usd': 4.4673, 'budget_usd': 4.5,
            'usd_to_inr': 94, 'pricing_date': '2026-11-12', 'recent': []}
    page.route('**/qa/ai/usage', lambda route: route.fulfill(json=data))
    page.locator('#refresh-ai-usage').click()
    expect(page.locator('#ai-usage-status')).to_contain_text('Activation needed')
    expect(page.locator('#ai-tokens')).to_have_text('1,200 + 300')
    expect(page.locator('#ai-spent')).to_contain_text('$0.0027')
    expect(page.locator('#ai-reserved')).to_have_text('$0.0300')
    expect(page.locator('#ai-budget-note')).to_contain_text('not your account balance')
    data['configured'] = True
    page.locator('#refresh-ai-usage').click()
    expect(page.locator('#ai-usage-status')).to_contain_text('not yet proof of billing')
    page.set_viewport_size({'width': 390, 'height': 844})
    assert page.evaluate('document.documentElement.scrollWidth <= innerWidth')


def test_dashboard_shows_recovery_evidence_without_hiding_original_failure(dashboard):
    page = dashboard
    page.route('**/tests/run', lambda route: route.fulfill(json={
        'status': 'passed', 'exit_code': 0,
        'test_summary': {'status': 'PASS_WITH_RETRY', 'passed': 1, 'failed': 0, 'skipped': 0, 'flaky': 1, 'total': 1},
        'test_cases': [{'id': 'TEST-001', 'name': 'Navigation', 'status': 'FLAKY', 'details': 'Passed after retry',
                        'first_attempt': {'status': 'FAIL', 'details': 'Page.goto: Timeout'}}],
        'dom_inspection': {'snapshots': 3, 'controls': 5, 'dropdowns': 1, 'url': 'https://example.test'},
        'locator_healing': [{'status': 'applied', 'original_selector': '#old', 'replacement_selector': '#new', 'matched_by': 'text'}],
        'root_cause_analysis': {'note': 'Observed symptoms only', 'findings': []},
        'automatic_rerun': {'executed': True, 'retried_tests': ['test_navigation'], 'retry_status': 'passed'},
        'run_reports': [{'label': 'Initial run', 'html_report': '/reports/first.html'},
                        {'label': 'Automatic rerun', 'html_report': '/reports/retry.html'}]}))
    expect(page.locator('#auto-rerun')).not_to_be_checked()
    page.locator('#tests').click()
    expect(page.locator('#result')).to_contain_text('DOM inspection')
    expect(page.locator('#result')).to_contain_text('1 applied')
    expect(page.locator('#result .FLAKY')).to_have_text('FLAKY')
    expect(page.locator('#result')).to_contain_text('PASS_WITH_RETRY')
    expect(page.locator('#result').get_by_text('Original failure', exact=True)).to_be_visible()
    expect(page.locator('#result a[href="/reports/first.html"]')).to_be_visible()
    expect(page.locator('#result a[href="/reports/retry.html"]')).to_be_visible()


def test_dashboard_links_final_report_and_pending_repair_review(dashboard):
    page = dashboard
    page.route('**/tests/run', lambda route: route.fulfill(json={
        'status': 'passed', 'exit_code': 0,
        'test_summary': {'status': 'PASS_AFTER_HEALING', 'passed': 1, 'failed': 0, 'skipped': 0, 'total': 1, 'healed': 1},
        'test_cases': [{'id': 'T1', 'name': 'Login', 'status': 'HEALED', 'details': 'Validated locator repair',
                        'first_attempt': {'status': 'FAIL', 'details': 'Missing locator'}}],
        'healing': {'requested': True, 'review_required': True, 'original_suite_unchanged': True,
                    'proposals': [{'node_id': 'test_login', 'status': 'passed_after_healing'}],
                    'review_file': '/reports/review.json'},
        'final_report': '/reports/final.html'}))
    expect(page.locator('#auto-heal')).not_to_be_checked()
    page.locator('#tests').click()
    expect(page.locator('#result .HEALED')).to_have_text('HEALED')
    expect(page.locator('#result')).to_contain_text('permanent change not saved')
    expect(page.locator('#result a[href="/reports/final.html"]')).to_be_visible()
    expect(page.locator('#result a[href="/reports/review.json"]')).to_be_visible()


def test_existing_suite_can_run_without_regenerating_and_sends_healing_options(dashboard):
    page = dashboard
    page.route('**/qa/suites', lambda route: route.fulfill(json={'suites': [
        {'slug': 'orangehrm', 'target_url': 'https://example.test/login', 'test_functions': 5, 'healing_reviewed': True}]}))
    requests = []
    def run(route):
        requests.append(route.request.post_data_json)
        route.fulfill(json={'status': 'passed', 'exit_code': 0, 'output': 'Saved suite result'})
    page.route('**/qa/suite/orangehrm/run', run)
    page.locator('#load-suites').click()
    page.locator('#saved-suite').select_option('orangehrm')
    expect(page.locator('#url')).to_have_value('https://example.test/login')
    expect(page.locator('#saved-suite-status')).to_contain_text('Reviewed')
    page.locator('#auto-heal').check()
    page.locator('#run-saved-suite').click()
    expect(page.locator('#result')).to_contain_text('Saved suite result')
    assert requests == [{'target_url': 'https://example.test/login', 'auto_rerun': False, 'auto_heal': True}]


def test_website_first_cases_validate_and_preserve_explicit_expectations(dashboard):
    page = dashboard
    page.locator('#discover-suite').click()
    expect(page.locator('#result')).to_contain_text('Case 1: enter a test name')
    page.locator('#orangehrm-example').click()
    expect(page.locator('[data-discovery-case]')).to_have_count(5)
    requests = []
    def discover(route):
        requests.append(route.request.post_data_json)
        route.fulfill(json={'status': 'completed', 'workflow_mode': 'website_first',
            'note': 'Browser discovery results, not pytest results.',
            'test_summary': {'status': 'PASS', 'passed': 5, 'failed': 0, 'skipped': 0, 'total': 5},
            'discovery_cases': [], 'attempt_counts': {'browser_sessions': 5, 'pytest_runs': 0}})
    page.route('**/qa/discover-suite', discover)
    page.locator('#discover-suite').click()
    expect(page.locator('#result')).to_contain_text('pytest replay pending')
    assert len(requests[0]['cases']) == 5
    assert requests[0]['cases'][1]['expected_text'] == 'Invalid credentials'
    assert requests[0]['cases'][1]['use_saved_credentials'] is False
    assert requests[0]['cases'][0]['use_saved_credentials'] is True
    assert requests[0]['cases'][-1]['expected_text'] == 'Login'
    assert page.locator('#inspect-panel').evaluate('(element)=>element.getBoundingClientRect().top') < page.locator('#plan-panel').evaluate('(element)=>element.getBoundingClientRect().top')


def test_discovery_rerun_keeps_submitted_cases_and_evidence_is_read_only(dashboard):
    page = dashboard
    page.locator('#orangehrm-example').click()
    requests = []
    def discover(route):
        requests.append(route.request.post_data_json)
        route.fulfill(json={'status': 'failed', 'workflow_mode': 'website_first', 'note': 'No suite was saved.',
            'discovery_cases': [{'name': 'Login', 'evidence': {'discovery_manifest': '/reports/demo.json'}}]})
    page.route('**/qa/discover-suite', discover)
    page.locator('#discover-suite').click()
    rerun = page.get_by_role('button', name='Rerun discovery', exact=True)
    expect(rerun).to_be_visible()
    evidence = page.locator('#result details').filter(has=page.get_by_text('Evidence and screenshots · viewing uses no AI tokens', exact=True))
    expect(evidence).not_to_have_attribute('open', '')
    evidence.locator('summary').click()
    expect(evidence.locator('a')).to_have_attribute('href', '/reports/demo.json')
    assert len(requests) == 1
    page.locator('#url').fill('https://changed.test/')
    rerun.click()
    expect(page.get_by_role('button', name='Rerun discovery', exact=True)).to_be_visible()
    assert len(requests) == 2
    assert requests[0] == requests[1]


def test_passed_saved_suite_has_a_rerun_button(dashboard):
    page = dashboard
    page.route('**/tests/run', lambda route: route.fulfill(json={
        'status': 'passed', 'suite_slug': 'demo', 'target_url': 'https://example.test/'}))
    page.locator('#tests').click()
    requests = []
    def replay(route):
        requests.append(route.request.post_data_json)
        route.fulfill(json={'status': 'passed', 'suite_slug': 'demo', 'target_url': 'https://example.test/'})
    page.route('**/qa/suite/demo/run', replay)
    page.get_by_role('button', name='Rerun saved tests', exact=True).click()
    expect(page.get_by_role('button', name='Rerun saved tests', exact=True)).to_be_visible()
    assert requests == [{'target_url': 'https://example.test/', 'auto_rerun': False, 'auto_heal': False}]


def test_rmm_is_one_download_case_and_healing_controls_are_visible(dashboard):
    page=dashboard
    page.locator('#rmm-example').click()
    expect(page.locator('[data-discovery-case]')).to_have_count(1)
    expect(page.locator('[data-case-field="expected_outcome"]')).to_have_value('nonempty_download')
    expect(page.locator('[data-case-field="expected_text"]')).to_be_hidden()
    expect(page.locator('#discovery-heal')).to_be_visible()
    expect(page.locator('#auto-heal')).to_be_visible()
    requests=[]
    def discover(route):
        requests.append(route.request.post_data_json)
        route.fulfill(json={'status':'failed','workflow_mode':'website_first','note':'Fixture result'})
    page.route('**/qa/discover-suite',discover)
    page.locator('#discovery-heal').uncheck()
    page.locator('#discover-suite').click()
    expect(page.locator('#result')).to_contain_text('Fixture result')
    assert len(requests[0]['cases'])==1
    assert requests[0]['cases'][0]['expected_outcome']=='nonempty_download'
    assert requests[0]['heal_locators'] is False


def test_validation_identifies_missing_outcome_and_accepts_download_without_text(dashboard):
    page=dashboard
    page.locator('[data-case-field="name"]').fill('Download report')
    page.locator('[data-case-field="steps"]').fill('Select the requested filters and save the report.')
    requests=[]
    def discover(route):
        requests.append(route.request.post_data_json)
        route.fulfill(json={'status':'completed','note':'Submitted download'})
    page.route('**/qa/discover-suite',discover)
    page.locator('#discover-suite').click()
    expect(page.locator('#result')).to_contain_text('Case 1 (Download report): enter the text to verify')
    expect(page.locator('#result')).to_contain_text('Nonempty report download')
    expect(page.locator('[data-case-field="expected_text"]')).to_have_attribute('aria-invalid','true')
    assert requests==[]
    page.locator('[data-case-field="expected_outcome"]').select_option('nonempty_download')
    page.locator('#discover-suite').click()
    expect(page.locator('#result')).to_contain_text('COMPLETED')
    assert len(requests)==1
    assert requests[0]['cases'][0]['expected_text']==''
