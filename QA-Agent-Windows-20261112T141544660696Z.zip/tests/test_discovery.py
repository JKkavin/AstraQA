import json
from pathlib import Path
import pytest
from qa_agent.discovery import snapshot, safe_url, redact, wait_for_observed_busy, validate_targets
from qa_agent.workflow import discover_workflow
from qa_agent.pages.task_page import TaskPage


def test_snapshot_and_custom_dropdown_use_observed_dom(page):
    page.set_content('''<x-picker name="program"><div><select name="program" aria-hidden="true" style="position:absolute;opacity:0;pointer-events:none"><option>Alpha</option><option>Beta</option></select>
    <label onclick="this.parentElement.querySelector('ul').hidden=false">Alpha</label>
    <ul hidden><li onclick="const r=this.closest('x-picker');r.querySelector('label').textContent=this.textContent;this.parentElement.hidden=true">Beta</li></ul></div></x-picker>''')
    state=snapshot(page)
    assert len(state['dropdowns'])==1
    dropdown=state['dropdowns'][0]
    action={'action':'select','target':{'selector':dropdown['selector']},'value':'Beta'}
    validate_targets(action,state,page)
    TaskPage(page).execute(action,{})
    assert page.locator('label').inner_text()=='Beta'
    with pytest.raises(ValueError,match='not observed'):
        TaskPage(page,replay=False).execute({**action,'value':'Invented'}, {})


def test_multiple_busy_overlays_wait_until_all_clear(page):
    page.set_content('''<div class="spinner-overlay">Loading</div><div class="spinner-overlay">Loading</div>
    <button>Continue</button><script>setTimeout(()=>document.querySelectorAll('.spinner-overlay').forEach(e=>e.remove()),150)</script>''')
    state=snapshot(page)
    assert len(state['busy'])==2
    wait_for_observed_busy(page,state,2000)
    assert page.locator('.spinner-overlay').count()==0


def test_adaptive_discovery_reinspects_menu_and_recovers_without_new_browser(page,tmp_path):
    page.set_content('''<button id="menu" onclick="document.getElementById('next').hidden=false">Menu</button><button id="next" hidden onclick="document.getElementById('result').textContent='Complete'">Open report</button><p id="result"></p>''')
    seen=[]
    def planner(task,state,allow,knowledge):
        seen.append(state)
        i=len(seen)
        if i==1:return {'actions':[{'action':'click','target':{'selector':'#invented'}}]}
        if i==2:return {'actions':[{'action':'click','target':{'selector':'#menu'}}]}
        if i==3:
            assert any(c['selector']=='#next' for c in state['controls'])
            return {'actions':[{'action':'click','target':{'selector':'#next'}}]}
        if i==4:return {'actions':[{'action':'verify_text','target':{'selector':'#menu'},'expected':'Complete'}]}
        return {'done':True,'actions':[]}
    result=discover_workflow(page,'Open report',{},[],planner,tmp_path/'evidence')
    assert result['discovery']['status']=='PASS'
    assert result['discovery']['counts']=={'browser_sessions':1,'discovery_snapshots':5,'discovery_action_attempts':4,'failed_discovery_attempts':1,'pytest_runs':0}
    assert len(result['actions'])==3
    assert result['test_cases'][-1]['status']=='PASS'
    assert (tmp_path/'evidence/attempt-1-failure.png').exists()


def test_discovery_does_not_accept_unverified_done_or_repeat_clicks(page,tmp_path):
    page.set_content('<button id="menu">Menu</button>')
    result=discover_workflow(page,'Test',{},[],lambda *a:{'done':True,'actions':[]},tmp_path/'a')
    assert result['discovery']['status']=='FAIL'
    click={'actions':[{'action':'click','target':{'selector':'#menu'}}]}
    result=discover_workflow(page,'Test',{},[],lambda *a:click,tmp_path/'b')
    assert result['discovery']['counts']['discovery_action_attempts']==1
    assert result['discovery']['status']=='FAIL'


def test_redaction_and_unobserved_selector_rejection(page):
    url='https://test.example/auth?code=private#access_token=private&id_token=private'
    assert safe_url(url)=='https://test.example/auth'
    assert 'private' not in redact('access_token=private password=private')
    assert redact('saved password value',{'username':'sa','password':'value'})=='saved password [REDACTED]'
    page.set_content('<input id="user" value="secret"><button id="go">Go</button>')
    state=snapshot(page,{'password':'secret'})
    assert 'secret' not in json.dumps(state)
    with pytest.raises(ValueError):validate_targets({'target':{'selector':'#fake'}},state,page)


def test_saved_password_cannot_be_sent_to_nonpassword_field(page,tmp_path):
    page.set_content('<input id="search">')
    planner=lambda *args:{'actions':[{'action':'fill','target':{'selector':'#search'},'value':'{{QA_PASSWORD}}'}]}
    result=discover_workflow(page,'Login',{'password':'synthetic-secret'},[],planner,tmp_path/'c')
    assert result['discovery']['status']=='FAIL'
    assert page.locator('#search').input_value()==''
    assert 'synthetic-secret' not in json.dumps(result)


def test_live_discovery_api_saves_verified_suite_and_replays_actions(monkeypatch,page,tmp_path):
    from functools import partial
    from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
    from threading import Thread
    from fastapi.testclient import TestClient
    import main
    import qa_agent.browser as browser
    import qa_agent.suites as suites
    site=tmp_path/'site';site.mkdir()
    (site/'index.html').write_text('<button id="menu" onclick="document.getElementById(\'next\').hidden=false">Menu</button><button id="next" hidden onclick="document.getElementById(\'result\').textContent=\'Complete\'">Report</button><p id="result"></p>')
    server=ThreadingHTTPServer(('127.0.0.1',0),partial(SimpleHTTPRequestHandler,directory=str(site)))
    thread=Thread(target=server.serve_forever,daemon=True);thread.start()
    def planner(task,state,allow,knowledge):
        count=len(state['completed_actions'])
        if count==0:return {'actions':[{'action':'click','target':{'selector':'#menu'}}]}
        if count==1:return {'actions':[{'action':'click','target':{'selector':'#next'}}]}
        if count==2:return {'actions':[{'action':'verify_text','target':{'selector':'#menu'},'expected':'Complete'}]}
        return {'done':True,'actions':[]}
    destination=tmp_path/'generated'
    monkeypatch.setattr(suites,'GENERATED_DIR',destination)
    monkeypatch.setattr(main,'GENERATED_DIR',destination)
    monkeypatch.setattr(browser,'REPORT_DIR',tmp_path/'evidence')
    monkeypatch.setattr(browser,'plan_browser_task',planner)
    monkeypatch.setenv('QA_API_TOKEN','discovery-test')
    monkeypatch.setattr(main.knowledge_base,'search',lambda *a,**kw:[])
    url=f'http://127.0.0.1:{server.server_port}/'
    try:
        response=TestClient(main.app).post('/qa/run',headers={'Authorization':'Bearer discovery-test'},json={
            'target_url':url,'question':'Open report and verify Complete, then close browser',
            'include_ai':False,'save_verified_suite':True,'application':'Discovery fixture'})
        assert response.status_code==200,response.text
        data=response.json()
        assert data['test_summary']['status']=='PASS'
        assert data['attempt_counts']['pytest_runs']==0
        assert data['attempt_counts']['discovery_action_attempts']==3
        assert (destination/'discovery_fixture/verified_locators.json').exists()
        for source in destination.rglob('*.py'):compile(source.read_text(encoding='utf-8'),str(source),'exec')
        page.goto(url)
        for action in data['browser_observations']['task_plan']:TaskPage(page).execute(action,{})
        assert page.locator('#result').inner_text()=='Complete'
    finally:
        server.shutdown();server.server_close();thread.join(timeout=3)


def test_pytest_attempt_count_records_executions_separately(monkeypatch,tmp_path):
    from types import SimpleNamespace
    import qa_agent.execution as execution
    monkeypatch.setattr(execution,'ROOT',tmp_path)
    test_file=tmp_path/'generated_suites/demo/tests/test_demo_regression.py'
    test_file.parent.mkdir(parents=True);test_file.write_text('')
    monkeypatch.setattr(execution.subprocess,'run',lambda *args,**kwargs:SimpleNamespace(returncode=0,stdout='passed',stderr=''))
    assert execution.run_generated_suite('demo','http://example.test')['attempt_counts']=={'pytest_runs':1}
    assert execution.run_generated_suite('demo','http://example.test')['attempt_counts']=={'pytest_runs':2}
