from pathlib import Path
from types import SimpleNamespace

import pytest

from qa_agent import execution


@pytest.mark.parametrize('generated', [False, True])
def test_each_run_returns_only_its_own_report(monkeypatch, tmp_path, generated):
    monkeypatch.setattr(execution, 'ROOT', tmp_path)
    suite = tmp_path / 'generated_suites' / 'sample' / 'tests'
    suite.mkdir(parents=True)
    (suite / 'test_sample_regression.py').write_text('')
    reports = []

    def run(command, **kwargs):
        report = Path(next(arg.split('=', 1)[1] for arg in command if arg.startswith('--html=')))
        reports.append(report)
        if len(reports) < 3:
            report.write_text(f'Run {len(reports)}')
        return SimpleNamespace(returncode=0 if len(reports) < 3 else 1, stdout='current run', stderr='')

    monkeypatch.setattr(execution.subprocess, 'run', run)
    invoke = (lambda: execution.run_generated_suite('sample', 'https://example.test')) if generated else execution.run_saved_test_suite
    first, second, failed = invoke(), invoke(), invoke()
    assert first['html_report'] != second['html_report']
    assert (tmp_path / second['html_report'].lstrip('/')).read_text() == 'Run 2'
    assert failed['status'] == 'failed'
    assert failed['html_report'] is None


def test_junit_results_include_failures_errors_and_skips(tmp_path):
    report = tmp_path / 'results.xml'
    report.write_text("""<testsuites><testsuite><testcase name="login"/>
      <testcase name="search"><failure message="Wrong employee"/></testcase>
      <testcase name="logout"><error message="Fixture failed"/></testcase>
      <testcase name="optional"><skipped message="Unavailable"/></testcase>
      </testsuite></testsuites>""")
    result = execution._test_results(report, 1)
    assert result['test_summary'] == {'status': 'FAIL', 'passed': 1, 'failed': 2, 'skipped': 1, 'total': 4}
    assert [case['status'] for case in result['test_cases']] == ['PASS', 'FAIL', 'FAIL', 'SKIPPED']
    assert result['test_cases'][2]['details'] == 'Fixture failed'


def test_junit_never_claims_pass_for_empty_or_failed_session(tmp_path):
    report = tmp_path / 'results.xml'
    report.write_text('<testsuites><testsuite/></testsuites>')
    assert execution._test_results(report, 0)['test_summary']['status'] == 'SKIPPED'
    assert execution._test_results(report, 5)['test_summary']['status'] == 'FAIL'
    report.write_text('<broken>')
    assert execution._test_results(report, 1) == {}
