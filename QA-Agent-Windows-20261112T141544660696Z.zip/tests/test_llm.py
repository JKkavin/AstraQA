import sys
from types import ModuleType, SimpleNamespace

from qa_agent.llm import _gemini_model_candidates, analyze


def test_gemini_models_are_ordered_and_deduplicated(monkeypatch):
    monkeypatch.setenv("GEMINI_MODEL", "gemini-4-argon")
    monkeypatch.setenv(
        "GEMINI_FALLBACK_MODELS",
        "gemini-3.8-flash, gemini-3.6-flash, gemini-3.8-flash",
    )

    assert _gemini_model_candidates() == [
        "gemini-4-argon",
        "gemini-3.8-flash",
        "gemini-3.6-flash",
    ]


def test_gemini_analysis_falls_back_in_configured_order(monkeypatch):
    calls = []

    class BusyError(Exception):
        status_code = 503

    class FakeModels:
        def generate_content(self, *, model, contents):
            calls.append(model)
            if model == "gemini-4-argon":
                raise BusyError("temporarily unavailable")
            return SimpleNamespace(text="QA findings")

    fake_google = ModuleType("google")
    fake_google.genai = SimpleNamespace(Client=lambda **_: SimpleNamespace(models=FakeModels()))
    monkeypatch.setitem(sys.modules, "google", fake_google)
    monkeypatch.setenv("LLM_PROVIDER", "gemini")
    monkeypatch.setenv("GEMINI_API_KEY", "synthetic-key")
    monkeypatch.setenv("GEMINI_MODEL", "gemini-4-argon")
    monkeypatch.setenv("GEMINI_FALLBACK_MODELS", "gemini-3.8-flash,gemini-3.6-flash")

    result = analyze("Review the login page", None, [])

    assert calls == ["gemini-4-argon", "gemini-3.8-flash"]
    assert result.startswith("Analysis model: gemini-3.8-flash")
    assert "QA findings" in result
