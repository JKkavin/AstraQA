import pytest
from fastapi.testclient import TestClient
import main


@pytest.mark.parametrize('host,allowed', [('127.0.0.1', True), ('::1', True), ('192.168.1.5', False)])
def test_local_token_free_access(monkeypatch, host, allowed):
    monkeypatch.setenv('QA_ALLOW_LOCAL_NO_TOKEN', 'true')
    monkeypatch.setenv('QA_API_TOKEN', 'test-token')
    with TestClient(main.app, client=(host, 50000), base_url='http://127.0.0.1:8000') as client:
        response = client.get('/qa/settings')
        assert response.status_code == (200 if allowed else 401)
        assert ('data-local-access="true"' in client.get('/').text) == allowed


def test_local_access_can_require_token(monkeypatch):
    monkeypatch.setenv('QA_ALLOW_LOCAL_NO_TOKEN', 'false')
    monkeypatch.setenv('QA_API_TOKEN', 'test-token')
    with TestClient(main.app, client=('127.0.0.1', 50000), base_url='http://127.0.0.1:8000') as client:
        assert client.get('/qa/settings').status_code == 401
        assert client.get('/qa/settings', headers={'Authorization': 'Bearer test-token'}).status_code == 200


def test_cross_origin_local_request_requires_token(monkeypatch):
    monkeypatch.setenv('QA_ALLOW_LOCAL_NO_TOKEN', 'true')
    monkeypatch.setenv('QA_API_TOKEN', 'test-token')
    with TestClient(main.app, client=('127.0.0.1', 50000), base_url='http://127.0.0.1:8000') as client:
        assert client.get('/qa/settings', headers={'Origin': 'https://other.example'}).status_code == 401
        assert client.get('/qa/settings', headers={'Sec-Fetch-Site': 'cross-site'}).status_code == 401


def test_local_access_rejects_nonlocal_host_header(monkeypatch):
    monkeypatch.setenv('QA_ALLOW_LOCAL_NO_TOKEN', 'true')
    monkeypatch.setenv('QA_API_TOKEN', 'test-token')
    with TestClient(main.app, client=('127.0.0.1', 50000), base_url='http://127.0.0.1:8000') as client:
        assert client.get('/qa/settings', headers={'Host': 'other.example'}).status_code == 401
