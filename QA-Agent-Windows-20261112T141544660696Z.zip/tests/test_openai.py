import json
from concurrent.futures import ThreadPoolExecutor
from decimal import Decimal
from types import SimpleNamespace

import pytest
from fastapi.testclient import TestClient
import main

from qa_agent import ai_usage, openai_provider as provider, llm


@pytest.fixture
def trial(monkeypatch, tmp_path):
    monkeypatch.setattr(provider, 'ENV_PATH', tmp_path / '.env')
    monkeypatch.setattr(ai_usage, 'LEDGER_PATH', tmp_path / 'usage.sqlite3')
    monkeypatch.setenv('OPENAI_API_KEY', 'synthetic-test-key')
    monkeypatch.setenv('OPENAI_MODEL', 'gpt-6.1-terra')
    monkeypatch.setenv('OPENAI_BUDGET_USD', '4.50')
    monkeypatch.setenv('OPENAI_MAX_CALL_USD', '0.10')
    monkeypatch.setenv('QA_USD_TO_INR', '94')
    monkeypatch.setenv('LLM_PROVIDER', 'openai')
    calls = []
    state = {'response': SimpleNamespace(status='completed', output_text='{"actions":[],"done":false,"error":null}',
        id='resp_synthetic', usage=SimpleNamespace(input_tokens=150, output_tokens=10,
                                                 input_tokens_details=SimpleNamespace(cached_tokens=50)))}
    def create(**kwargs):
        calls.append(kwargs)
        if state.get('error'):
            raise state['error']
        return state['response']
    import openai
    monkeypatch.setattr(openai, 'OpenAI', lambda **kwargs: SimpleNamespace(responses=SimpleNamespace(create=create)))
    return calls, state


def test_openai_uses_structured_responses_and_records_cached_usage(trial):
    calls, _ = trial
    assert json.loads(provider.generate('Test an observed page', 'browser')) == {'actions': [], 'done': False}
    request = calls[0]
    assert request['model'] == 'gpt-6.1-terra'
    assert request['store'] is False
    assert 'tools' not in request
    assert request['text']['format']['strict'] is True
    assert request['max_output_tokens'] == 1536
    status = provider.public_status()
    assert status['calls'] == 1
    assert status['input_tokens'] == 150 and status['output_tokens'] == 10
    assert status['cached_tokens'] == 50
    assert status['estimated_cost_usd'] == pytest.approx(0.0001525)
    assert status['estimated_cost_inr'] == pytest.approx(0.0001525 * 94)
    assert status['reserved_usd'] == 0
    assert 'synthetic-test-key' not in json.dumps(status)


def test_budget_rejects_before_making_paid_call(trial, monkeypatch):
    calls, _ = trial
    monkeypatch.setenv('OPENAI_BUDGET_USD', '0.000001')
    with pytest.raises(ValueError, match='budget reached'):
        provider.generate('Test page', 'plan')
    assert calls == []


def test_per_call_limit_and_context_limit_reject_before_api(trial, monkeypatch):
    calls, _ = trial
    monkeypatch.setenv('OPENAI_MAX_CALL_USD', '0.000001')
    with pytest.raises(ValueError, match='per-call'):
        provider.generate('Test page', 'analysis')
    with pytest.raises(ValueError, match='context is too large'):
        provider.generate('x' * 65000, 'browser')
    assert calls == []


@pytest.mark.parametrize('status,released', [(401, True), (429, True), (503, False), (None, False)])
def test_failed_calls_preserve_uncertain_reservations(trial, status, released):
    _, state = trial
    error = RuntimeError('synthetic-secret-never-return-this')
    error.status_code = status
    state['error'] = error
    with pytest.raises(ValueError) as captured:
        provider.generate('Inspect page', 'analysis')
    assert 'synthetic-secret-never-return-this' not in str(captured.value)
    summary = provider.public_status()
    assert (summary['reserved_usd'] == 0) is released
    assert summary['estimated_cost_usd'] == 0
    assert summary['uncertain_calls'] == (0 if released else 1)


def test_incomplete_response_records_usage_but_never_executes_partial_plan(trial):
    _, state = trial
    state['response'].status = 'incomplete'
    with pytest.raises(ValueError, match='complete answer'):
        provider.generate('Inspect page', 'browser')
    assert provider.public_status()['output_tokens'] == 10


def test_missing_usage_does_not_claim_zero_cost(trial):
    _, state = trial
    state['response'].usage = None
    provider.generate('Inspect page', 'browser')
    summary = provider.public_status()
    assert summary['uncertain_calls'] == 1
    assert summary['reserved_usd'] > 0


def test_missing_key_and_unpriced_models_do_not_fallback(trial, monkeypatch):
    calls, _ = trial
    monkeypatch.setenv('OPENAI_API_KEY', '')
    with pytest.raises(ValueError, match='not activated'):
        provider.generate('Inspect page', 'browser')
    assert llm.plan_browser_task('Inspect page', {}, False)['error'].startswith('OpenAI is not activated')
    assert llm.analyze('Inspect', None, []).startswith('OpenAI analysis unavailable')
    monkeypatch.setenv('OPENAI_MODEL', 'another-model')
    with pytest.raises(ValueError, match='Update pricing'):
        provider.public_status()
    assert calls == []


def test_api_key_is_reread_from_private_file(trial):
    provider.ENV_PATH.write_text('OPENAI_API_KEY=first-synthetic-key\n')
    assert provider.config()['api_key'] == 'first-synthetic-key'
    provider.ENV_PATH.write_text('OPENAI_API_KEY=second-synthetic-key\n')
    assert provider.config()['api_key'] == 'second-synthetic-key'


def test_reservations_are_atomic_across_concurrent_calls(trial):
    def reserve():
        try:
            return ai_usage.reserve('browser', provider.MODEL, 30_000_000, 50_000_000, 100_000_000)
        except ValueError:
            return None
    with ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(lambda _: reserve(), range(2)))
    assert sum(value is not None for value in results) == 1
    assert ai_usage.summary(50_000_000, Decimal('94'))['reserved_usd'] == 0.03


def test_openai_routes_all_three_workloads_without_changing_validators(trial, monkeypatch):
    purposes = []
    action = {'action': 'verify_text', 'target': {'text': 'Dashboard'}, 'expected': 'Dashboard'}
    def generate(prompt, purpose):
        purposes.append(purpose)
        if purpose == 'plan':
            return json.dumps({'test_cases': [{'id': 'TC-01', 'name': 'Dashboard visible', 'priority': 'High', 'steps': [action]}]})
        if purpose == 'browser':
            return json.dumps({'actions': [action], 'done': False})
        return 'Observed dashboard'
    monkeypatch.setattr(provider, 'generate', generate)
    assert len(llm.generate_regression_cases('Example', 'Verify dashboard heading')) == 1
    assert llm.plan_browser_task('Verify dashboard', {'discovery': True}, False)['actions'] == [action]
    assert 'Observed dashboard' in llm.analyze('Review', None, [])
    assert purposes == ['plan', 'browser', 'analysis']


def test_usage_endpoint_is_protected_and_does_not_expose_key(trial, monkeypatch):
    monkeypatch.setenv('QA_API_TOKEN', 'usage-test-token')
    remote = TestClient(main.app)
    assert remote.get('/qa/ai/usage').status_code == 401
    local = TestClient(main.app, client=('127.0.0.1', 50000), base_url='http://127.0.0.1:8000')
    response = local.get('/qa/ai/usage')
    assert response.status_code == 200
    assert response.json()['configured'] is True
    assert 'synthetic-test-key' not in response.text


def test_locator_repair_uses_small_strict_schema_and_reports_exact_call_usage(trial):
    calls, state = trial
    state['response'].output_text = '{"selector":"#username","reason":"Exact observed label"}'
    result = provider.generate_with_usage('Choose the observed Username input', 'locator_repair')
    assert result['usage']['input_tokens'] == 150
    assert result['usage']['estimated_cost_usd'] == pytest.approx(0.0001525)
    assert calls[0]['max_output_tokens'] == 768
    assert calls[0]['text']['format']['schema']['required'] == ['selector', 'reason']
