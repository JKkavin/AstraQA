import time

import pytest

from qa_agent import settings
from qa_agent.readiness import ensure_ready


@pytest.fixture(autouse=True)
def bounded_settings(monkeypatch, tmp_path):
    monkeypatch.setattr(settings, 'SETTINGS_PATH', tmp_path / 'settings.json')
    settings.save_settings(settings.RuntimeSettings(readiness_probe_ms=100,
        readiness_timeout_ms=2000, max_wait_ms=500, max_ai_wait_decisions=2))


def forbidden(_):
    raise AssertionError('A ready page must not call AI')


def test_ready_page_does_not_call_ai(page):
    page.set_content('<h1>Dashboard</h1>')
    assert ensure_ready(page, decider=forbidden)['visible_text']


def test_short_loading_uses_condition_without_ai(page):
    page.set_content('<p>Dashboard</p><div class="loading">Loading</div>')
    page.evaluate("setTimeout(()=>document.querySelector('.loading').remove(),30)")
    events = []
    ensure_ready(page, decider=forbidden, events=events)
    assert all(event['source'] == 'page_condition' for event in events)


def test_ai_wait_is_capped_and_finishes_when_ready(page):
    page.set_content('<p>Dashboard</p><div class="loading">Loading</div>')
    page.evaluate("setTimeout(()=>document.querySelector('.loading').remove(),350)")
    events = []
    ensure_ready(page, events=events, decider=lambda _: {
        'decision': 'wait', 'milliseconds': 999999, 'reason': 'Loading indicator remains'})
    decision = next(e for e in events if e['source'] == 'ai')
    assert decision['wait_cap_ms'] <= 500
    assert events[-1]['decision'] == 'ready'


def test_stalled_page_stops_at_decision_limit(page):
    page.set_content('<div class="loading">Loading</div>')
    calls = []
    def decide(context):
        calls.append(context)
        return {'decision': 'wait', 'milliseconds': 100, 'reason': 'Observe progress'}
    with pytest.raises(TimeoutError, match='decision limit'):
        ensure_ready(page, decider=decide)
    assert len(calls) == 2
    assert calls[1]['progress_changed'] is False


def test_ai_can_stop_without_dispatching_actions(page):
    page.set_content('<div class="loading">Unavailable</div>')
    with pytest.raises(TimeoutError, match='Unavailable'):
        ensure_ready(page, decider=lambda _: {'decision': 'stop', 'reason': 'Unavailable'})


@pytest.mark.parametrize('duration', [True, 0, -1, '100'])
def test_invalid_ai_duration_is_rejected(page, duration):
    page.set_content('<div class="loading">Loading</div>')
    with pytest.raises(TimeoutError, match='positive bounded duration'):
        ensure_ready(page, decider=lambda _: {'decision': 'wait', 'milliseconds': duration})


def test_expired_deadline_prevents_ai_calls(page):
    page.set_content('<div class="loading">Loading</div>')
    with pytest.raises(TimeoutError):
        ensure_ready(page, deadline=time.monotonic()-1, decider=forbidden)


def test_readiness_is_rechecked_after_ai_decision(page):
    page.set_content('<p>Ready</p><div class="loading">Loading</div>')
    events = []
    def decide(_):
        page.locator('.loading').evaluate('element=>element.remove()')
        return {'decision': 'stop', 'reason': 'Old snapshot still loading'}
    ensure_ready(page, events=events, decider=decide)
    assert events[0]['outcome'] == 'page_became_ready_during_decision'
