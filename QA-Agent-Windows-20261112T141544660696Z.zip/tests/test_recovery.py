import json
from pathlib import Path

import pytest

from qa_agent import settings, execution
from qa_agent.diagnostics import diagnose_failure
from qa_agent.discovery import snapshot
from qa_agent.healing import propose_repair
from qa_agent.workflow import discover_workflow


@pytest.fixture
def recovery_settings(monkeypatch, tmp_path):
    monkeypatch.setattr(settings, 'SETTINGS_PATH', tmp_path / 'settings.json')
    settings.save_settings(settings.RuntimeSettings(action_timeout_ms=150, readiness_timeout_ms=1000,
                                                   discovery_recovery_attempts=1))


def test_dom_inspection_reports_labels_disabled_state_and_test_ids(page):
    page.set_content('<label for="employee">Employee ID</label><input id="employee" data-testid="employee-id"><button disabled>Search</button>')
    state = snapshot(page)
    employee = next(control for control in state['controls'] if control['tag'] == 'input')
    assert employee['associated_label'] == 'Employee ID'
    assert employee['test_id'] == 'employee-id'
    assert next(control for control in state['controls'] if control['tag'] == 'button')['disabled'] is True
    assert next(control for control in state['controls'] if control['tag'] == 'button')['text'] == 'Search'


def test_discovery_repairs_changed_locator_without_an_extra_ai_call(page, tmp_path, recovery_settings):
    page.set_content('<button id="old" onclick="document.getElementById(\'result\').textContent=\'Complete\'">Continue</button><p id="result"></p>')
    calls = []
    def planner(task, state, allow, knowledge):
        calls.append(state)
        if len(calls) == 1:
            page.locator('#old').evaluate("element=>element.id='new'")
            return {'actions': [{'action': 'click', 'target': {'selector': '#old'}}]}
        if len(calls) == 2:
            return {'actions': [{'action': 'verify_text', 'target': {'selector': '#new'}, 'expected': 'Complete'}]}
        return {'done': True, 'actions': []}
    result = discover_workflow(page, 'Continue and verify Complete', {}, [], planner, tmp_path / 'evidence')
    manifest = result['discovery']
    assert manifest['status'] == 'PASS'
    assert len(calls) == 3
    assert manifest['locator_healing'][0]['status'] == 'applied'
    assert manifest['locator_healing'][0]['replacement_selector'] == '#new'
    assert manifest['attempts'][0]['status'] == 'FAIL'
    assert manifest['root_cause_analysis']['recovered'] is True
    assert manifest['dom_inspection']['controls'] > 0
    assert json.loads((tmp_path / 'evidence/discovery.json').read_text())['locator_healing']


def test_healing_refuses_ambiguous_or_different_password_field(page):
    page.set_content('<input id="old" name="password" type="password">')
    before = snapshot(page)
    action = {'action': 'fill', 'target': {'selector': '#old'}, 'value': '{{QA_PASSWORD}}'}
    page.set_content('<input id="new" name="password" type="text">')
    assert propose_repair(action, before, snapshot(page)) is None
    page.set_content('<input id="a" name="password" type="password"><input id="b" name="password" type="password">')
    assert propose_repair(action, before, snapshot(page)) is None


def test_click_is_not_replayed_after_dispatch(page, monkeypatch, tmp_path, recovery_settings):
    from qa_agent.pages.task_page import TaskPage
    page.set_content('<button id="old" onclick="window.clicks=(window.clicks||0)+1;this.id=\'new\'">Continue</button>')
    def execute(self, action, credentials):
        self.page.locator(action['target']['selector']).click()
        raise RuntimeError('Timeout after dispatch; outcome uncertain')
    monkeypatch.setattr(TaskPage, 'execute', execute)
    calls = []
    def planner(*args):
        calls.append(1)
        return {'actions': [{'action': 'click', 'target': {'selector': '#old'}}]} if len(calls) == 1 else {'actions': [], 'error': 'Stop'}
    result = discover_workflow(page, 'Continue', {}, [], planner, tmp_path / 'evidence')
    assert page.evaluate('window.clicks') == 1
    assert result['discovery']['status'] == 'FAIL'
    assert result['discovery']['locator_healing'] == []


@pytest.mark.parametrize('message,category,retry', [
    ('strict mode violation: matched 2 elements', 'ambiguous_locator', False),
    ('Page.goto: Timeout 100ms exceeded while navigating to example', 'navigation_timeout', True),
    ('net::ERR_CONNECTION_RESET', 'network', True),
    ('AssertionError: expected Dashboard', 'assertion', False),
    ('AssertionError: expected no net::ERR_CONNECTION_RESET', 'assertion', False),
    ('OpenAI budget reached', 'configuration', False),
])
def test_diagnosis_preserves_evidence_and_does_not_claim_a_proven_cause(message, category, retry):
    report = diagnose_failure(message)
    assert report['category'] == category
    assert report['automatic_rerun_eligible'] is retry
    assert report['cause_confirmed'] is False
    assert report['evidence'] == message


@pytest.mark.parametrize('retry_skips', [False, True])
def test_real_pytest_reruns_only_transient_failed_test_once(monkeypatch, tmp_path, retry_skips):
    monkeypatch.setattr(execution, 'ROOT', tmp_path)
    root = tmp_path / 'generated_suites'
    suite = root / 'sample'
    tests = suite / 'tests'
    tests.mkdir(parents=True)
    for directory in (root, suite, tests):
        (directory / '__init__.py').write_text('')
    (suite / 'conftest.py').write_text("def pytest_addoption(parser): parser.addoption('--target-url', default='')")
    (tests / 'test_sample_regression.py').write_text('''from pathlib import Path
import pytest
ROOT=Path(__file__).parents[3]
def test_stable():
    counter=ROOT/'stable-count.txt'
    counter.write_text(str(int(counter.read_text())+1) if counter.exists() else '1')
def test_transient():
    marker=ROOT/'transient.txt'
    if not marker.exists():
        marker.write_text('first failure')
        pytest.fail('Page.goto: Timeout 100ms exceeded while navigating to example')
    if RETRY_SKIPS: pytest.skip('Temporarily unavailable')
'''.replace('RETRY_SKIPS', repr(retry_skips)))
    result = execution.run_generated_suite('sample', 'https://example.test', auto_rerun=True)
    assert result['status'] == ('failed' if retry_skips else 'passed'), result['output']
    assert result['automatic_rerun']['executed'] is True
    assert len(result['automatic_rerun']['retried_tests']) == 1
    assert result['test_summary'] == ({'status': 'FAIL', 'passed': 1, 'failed': 1, 'skipped': 0, 'flaky': 0, 'total': 2} if retry_skips else {'status': 'PASS_WITH_RETRY', 'passed': 2, 'failed': 0, 'skipped': 0, 'flaky': 1, 'total': 2})
    assert (tmp_path / 'stable-count.txt').read_text() == '1'
    assert result['test_cases'][1]['status'] == ('FAIL' if retry_skips else 'FLAKY')
    assert result['test_cases'][1]['first_attempt']['status'] == 'FAIL'
    assert result['run_reports'][0]['html_report'] != result['run_reports'][1]['html_report']
    assert result['attempt_counts']['pytest_runs'] == 2


def test_assertion_failures_are_not_automatically_rerun(monkeypatch):
    calls = []
    def run(*args):
        calls.append(args)
        return {'status': 'failed', 'exit_code': 1, 'output': 'AssertionError', 'test_cases': [
            {'id': 'T1', 'name': 'check', 'status': 'FAIL', 'details': 'AssertionError: expected value',
             'node_id': 'generated_suites/sample/tests/test_sample_regression.py::test_check'}]}
    monkeypatch.setattr(execution, '_run_generated_suite_once', run)
    result = execution.run_generated_suite('sample', 'https://example.test', auto_rerun=True)
    assert len(calls) == 1
    assert result['status'] == 'failed'
    assert result['automatic_rerun']['executed'] is False


def test_locator_healing_can_be_disabled(page, monkeypatch, tmp_path, recovery_settings):
    from qa_agent.healing import propose_repair
    import qa_agent.workflow as workflow
    current = settings.get_settings()
    current.locator_healing_enabled = False
    settings.save_settings(current)
    page.set_content('<button id="old">Continue</button>')
    calls = []
    monkeypatch.setattr(workflow, 'propose_repair', lambda *a: pytest.fail('Healing must be disabled'))
    def planner(*args):
        calls.append(1)
        if len(calls) == 1:
            page.locator('#old').evaluate("element=>element.id='new'")
            return {'actions': [{'action': 'click', 'target': {'selector': '#old'}}]}
        return {'actions': [], 'error': 'Stop'}
    result = discover_workflow(page, 'Continue', {}, [], planner, tmp_path / 'evidence')
    assert result['discovery']['locator_healing'] == []


def test_rerun_is_explicitly_opted_in_at_api(monkeypatch):
    import main
    from fastapi.testclient import TestClient
    calls = []
    monkeypatch.setenv('QA_API_TOKEN', 'rerun-test')
    def run(slug, url, auto_rerun=False):
        calls.append(auto_rerun)
        return {'status': 'passed', 'exit_code': 0, 'output': 'synthetic result'}
    monkeypatch.setattr(main, 'run_generated_suite', run)
    client = TestClient(main.app)
    headers = {'Authorization': 'Bearer rerun-test'}
    assert client.post('/qa/suite/sample/run', json={'target_url': 'https://example.test'}, headers=headers).status_code == 200
    assert client.post('/qa/suite/sample/run', json={'target_url': 'https://example.test', 'auto_rerun': True}, headers=headers).status_code == 200
    assert calls == [False, True]


def test_discovery_api_preserves_original_failure_diagnosis(monkeypatch):
    import main
    from fastapi.testclient import TestClient
    from qa_agent.diagnostics import root_cause_report
    monkeypatch.setenv('QA_API_TOKEN', 'diagnosis-test')
    original = root_cause_report([{'name': 'Attempt 1', 'status': 'FAIL', 'details': 'Observed target no longer exists'}])
    async def inspect(*args):
        return {'test_cases': [{'id': 'DISC-OUTCOME', 'name': 'Workflow', 'status': 'FAIL', 'details': 'Recovery budget exhausted'}],
                'test_summary': {'status': 'FAIL', 'passed': 0, 'failed': 1, 'skipped': 0, 'total': 1},
                'discovery': {'root_cause_analysis': original}}
    monkeypatch.setattr(main, 'inspect_page', inspect)
    monkeypatch.setattr(main.knowledge_base, 'search', lambda *args, **kwargs: [])
    response = TestClient(main.app).post('/qa/run', headers={'Authorization': 'Bearer diagnosis-test'},
        json={'target_url': 'https://example.test', 'include_ai': False})
    assert response.status_code == 200
    assert response.json()['root_cause_analysis']['findings'][0]['category'] == 'locator_timeout'
