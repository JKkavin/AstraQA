"""Saved scripts must survive slower subsequent runs without rediscovery or AI."""
import hashlib
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from threading import Thread
import time

import pytest
from playwright.sync_api import TimeoutError as PlaywrightTimeoutError

from qa_agent import execution, settings, suites
from qa_agent.pages.task_page import TaskPage


def test_same_generated_script_runs_three_times_with_slower_loading(monkeypatch, tmp_path):
    hits=[]
    class Site(BaseHTTPRequestHandler):
        def log_message(self,*args):pass
        def do_GET(self):
            self.send_response(200)
            if self.path=='/report.csv':
                self.send_header('Content-Type','text/csv');self.end_headers()
                self.wfile.write(b'measure,count\nTEST,3\n');return
            if self.path!='/':self.end_headers();return
            delay=[120,500,900][min(len(hits),2)];hits.append(delay)
            self.send_header('Content-Type','text/html');self.end_headers()
            html='''<div id="app"><div class="loading">Loading page</div></div><script>
            const delay=DELAY;
            setTimeout(()=>{app.innerHTML='<button id="open">Open filters</button>';
              document.querySelector('#open').onclick=()=>{
                app.innerHTML='<div id="program"><select hidden><option>Select</option></select><label>Select</label><ul hidden></ul></div><button id="go" disabled>Go</button>';
                const root=document.querySelector('#program'),label=root.querySelector('label');
                label.onclick=()=>root.querySelector('ul').hidden=false;
                setTimeout(()=>{
                  root.querySelector('select').insertAdjacentHTML('beforeend','<option value="b">Beta</option>');
                  root.querySelector('ul').innerHTML='<li>Beta</li>';
                  root.querySelector('li').onclick=()=>{label.textContent='Beta';root.querySelector('ul').hidden=true;setTimeout(()=>document.querySelector('#go').disabled=false,delay)};
                },delay);
                document.querySelector('#go').onclick=()=>{
                  app.innerHTML='<div class="loading">Preparing report</div><a id="download" href="/report.csv" download hidden>Download Report</a>';
                  setTimeout(()=>{document.querySelector('.loading').remove();document.querySelector('#download').hidden=false},delay);
                };
              };
            },delay);
            </script>'''.replace('DELAY',str(delay))
            self.wfile.write(html.encode())
    server=ThreadingHTTPServer(('127.0.0.1',0),Site)
    thread=Thread(target=server.serve_forever,daemon=True);thread.start()
    monkeypatch.setattr(settings,'SETTINGS_PATH',tmp_path/'settings.json')
    runtime=settings.RuntimeSettings(action_timeout_ms=100,search_timeout_ms=100,
        readiness_timeout_ms=2500,navigation_timeout_ms=1500,download_timeout_ms=2000,suite_timeout_seconds=25)
    settings.save_settings(runtime)
    monkeypatch.setattr(suites,'GENERATED_DIR',tmp_path/'generated_suites')
    monkeypatch.setattr(execution,'ROOT',tmp_path)
    url=f'http://127.0.0.1:{server.server_port}/'
    saved=suites.save_regression_suite('Repeat loading fixture',[{'id':'ONE','name':'Prepare and download',
        'priority':'High','steps':[
            {'action':'click','target':{'selector':'#open'}},
            {'action':'select','target':{'selector':'#program'},'value':'Beta'},
            {'action':'click','target':{'selector':'#go'}},
            {'action':'download','target':{'selector':'#download'}}]}],url)
    folder=tmp_path/'generated_suites'/saved['slug']
    (folder/'replay-settings.json').write_text(runtime.model_dump_json())
    with (folder/'conftest.py').open('a') as conftest:
        conftest.write('''
from qa_agent import settings as replay_settings, llm, openai_provider
replay_settings.SETTINGS_PATH = Path(__file__).with_name('replay-settings.json')
def no_ai(*args, **kwargs):
    raise AssertionError('Saved replay must not invoke AI')
llm.decide_page_wait = no_ai
openai_provider.generate = no_ai
''')
    source=folder/'tests'/f"test_{saved['slug']}_regression.py"
    digest=hashlib.sha256(source.read_bytes()).hexdigest()
    assert source.read_text().count('app.wait_until_ready()')==4
    assert json.loads((folder/'suite_config.json').read_text())['wait_policy']['readiness_timeout_ms']==2500
    try:
        for attempt in range(3):
            result=execution.run_generated_suite(saved['slug'],url)
            assert result['test_summary']['passed']==1,(attempt,result['output'])
            assert result['downloads'][0]['bytes']>0
            assert not result['adaptive_waiting']
            assert hashlib.sha256(source.read_bytes()).hexdigest()==digest
        assert hits==[120,500,900]
    finally:
        server.shutdown();server.server_close();thread.join(timeout=3)


def test_replay_wait_for_missing_option_obeys_deadline_and_does_not_choose_another(page, monkeypatch,tmp_path):
    monkeypatch.setattr(settings,'SETTINGS_PATH',tmp_path/'settings.json')
    settings.save_settings(settings.RuntimeSettings(readiness_timeout_ms=1000,search_timeout_ms=100))
    page.set_content('<div id="program"><select hidden><option>Alpha</option></select><label>Select</label><ul hidden><li>Alpha</li></ul></div>')
    executor=TaskPage(page)
    executor.deadline=time.monotonic()+0.2
    started=time.monotonic()
    with pytest.raises((TimeoutError,PlaywrightTimeoutError)):
        executor.execute({'action':'select','target':{'selector':'#program'},'value':'Missing'}, {})
    assert time.monotonic()-started<1
    assert page.locator('label').inner_text()=='Select'
