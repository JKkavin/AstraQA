import json
from decimal import Decimal
from types import SimpleNamespace

import pytest
from fastapi.testclient import TestClient

import main
from qa_agent import reconciliation as r
from qa_agent.pages.task_page import TaskPage


def data(rows):
    return r.table(['id', 'amount'], rows)


def test_reconciliation_order_numeric_and_leading_zero_ids():
    left = data([['001', '10.00'], ['002', '20']])
    right = data([['002', Decimal('20.0')], ['001', 10]])
    result = r.compare_tables(left, right, ['id'], numeric_columns=['amount'])
    assert result['status'] == 'PASS'
    assert result['matched_rows'] == 2
    assert r.compare_tables(data([['001', '1']]), data([['1', '1']]), ['id'])['status'] == 'FAIL'


def test_missing_duplicate_columns_and_values_fail():
    result = r.compare_tables(data([['a','1'], ['a','1'], ['b','2']]), data([['a','3'], ['c','2']]), ['id'])
    assert result['status'] == 'FAIL'
    assert result['mismatched_cells'] == 1
    assert result['duplicate_download_keys'] == [{'key':['a'], 'count':2}]
    assert result['missing_from_download'] == [['c']]
    assert result['missing_from_reference'] == [['b']]
    result = r.compare_tables(data([['a','1']]), r.table(['id'], [['a']]), ['id'])
    assert result['missing_columns']['reference'] == ['amount']
    assert result['status'] == 'FAIL'


def test_empty_null_invalid_and_tolerance():
    assert r.compare_tables(data([]),data([]),['id'])['status'] == 'INCONCLUSIVE'
    assert r.compare_tables(data([['a',None]]),data([['a','']]),['id'])['status'] == 'FAIL'
    assert r.compare_tables(data([['a','1.01']]),data([['a','1']]),['id'],numeric_columns=['amount'],tolerance='.02')['status'] == 'PASS'
    with pytest.raises(ValueError):
        r.compare_tables(data([['','1']]),data([['a','1']]),['id'])
    with pytest.raises(ValueError):
        r.compare_tables(data([]),data([]),['id'],tolerance='NaN')
    with pytest.raises(ValueError):
        r.table(['id','id'], [])


def test_csv_json_xlsx_readers(tmp_path):
    csv = tmp_path/'orders.csv'
    csv.write_text('\ufeffid,amount\n001,10\n',encoding='utf-8')
    assert r.read_report(csv)[1][0]['id'] == '001'
    js = tmp_path/'orders.json'
    js.write_text(json.dumps([{'id':'001','amount':10}]))
    assert r.compare_tables(r.read_report(csv),r.read_report(js),['id'],numeric_columns=['amount'])['status'] == 'PASS'
    from openpyxl import Workbook
    book = Workbook()
    book.active.append(['id','amount'])
    book.active.append(['001',10])
    xlsx = tmp_path/'orders.xlsx'
    book.save(xlsx)
    book.close()
    assert r.read_report(xlsx)[1][0] == {'id':'001','amount':10}


def test_report_api_upload_compare_server_and_access(monkeypatch,tmp_path):
    monkeypatch.setattr(r,'DOWNLOAD_DIR',tmp_path)
    monkeypatch.setenv('QA_API_TOKEN','test-local-token')
    headers={'Authorization':'Bearer test-local-token'}
    client=TestClient(main.app)
    assert client.post('/qa/reports/upload',files={'file':('a.csv',b'id,amount\na,1\n')}).status_code == 401
    first=client.post('/qa/reports/upload',headers=headers,files={'file':('a.csv',b'id,amount\na,1\n')}).json()
    second=client.post('/qa/reports/upload',headers=headers,files={'file':('b.csv',b'id,amount\na,2\n')}).json()
    payload={'downloaded_file_id':first['id'],'reference_file_id':second['id'],'keys':['id']}
    result=client.post('/qa/reports/compare',headers=headers,json=payload)
    assert result.status_code == 200
    assert result.json()['status'] == 'FAIL'
    assert client.get('/qa/downloads/'+first['id']).status_code == 401
    assert client.get('/qa/downloads/'+first['id'],headers=headers).content == b'id,amount\na,1\n'
    monkeypatch.setattr(r,'query_report',lambda source,params: data([['a','1']]))
    payload.pop('reference_file_id');payload['source_id']='orders'
    assert client.post('/qa/reports/compare',headers=headers,json=payload).json()['status'] == 'PASS'
    payload['reference_file_id']=second['id']
    assert client.post('/qa/reports/compare',headers=headers,json=payload).status_code == 400
    with pytest.raises(ValueError):
        r.file_path('../../.env')


@pytest.mark.parametrize('provider',['sqlserver','databricks'])
def test_query_binding_and_connection_cleanup(monkeypatch,provider):
    calls=[]
    class Cursor:
        description=[('id',),('amount',)]
        def execute(self,query,args): calls.append((query,args))
        def fetchmany(self,count): return [('a',Decimal('1'))]
        def close(self): calls.append('cursor closed')
    class Connection:
        def cursor(self): return Cursor()
        def close(self): calls.append('connection closed')
    query='SELECT id, amount FROM orders WHERE id = '+('?' if provider=='sqlserver' else ':id')
    monkeypatch.setattr(r,'sources',lambda:{'orders':{'provider':provider,'query':query,'parameters':['id']}})
    for name in ['QA_SQLSERVER_CONNECTION_STRING','DATABRICKS_SERVER_HOSTNAME','DATABRICKS_HTTP_PATH','DATABRICKS_TOKEN']:
        monkeypatch.setenv(name,'synthetic')
    if provider=='sqlserver':
        import pyodbc
        monkeypatch.setattr(pyodbc,'connect',lambda *a,**kw:Connection())
    else:
        from databricks import sql
        monkeypatch.setattr(sql,'connect',lambda *a,**kw:Connection())
    hostile="a' OR 1=1 --"
    result=r.query_report('orders',{'id':hostile})
    assert result[1][0]['id']=='a'
    assert calls[0] == (query,[hostile] if provider=='sqlserver' else {'id':hostile})
    assert calls[-2:]==['cursor closed','connection closed']
    with pytest.raises(ValueError):r.query_report('orders',{'unexpected':'x'})


def test_search_dropdown_download_and_ambiguous_results(page,tmp_path):
    from functools import partial
    from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
    from threading import Thread
    (tmp_path/'orders.csv').write_text('id,amount\na,1\n')
    (tmp_path/'index.html').write_text('''<label>Patient<input aria-label="Patient" oninput="setTimeout(()=>document.querySelector('[role=option]').hidden=false,100)"></label>
    <div role="option" hidden onclick="document.querySelector('#selected').textContent='TEST-001'">Test Patient TEST-001</div><div id="selected"></div>
    <a href="/orders.csv" download>Download orders</a>''')
    server=ThreadingHTTPServer(('127.0.0.1',0),partial(SimpleHTTPRequestHandler,directory=str(tmp_path)))
    thread=Thread(target=server.serve_forever,daemon=True)
    thread.start()
    try:
        page.goto(f'http://127.0.0.1:{server.server_port}/')
        executor=TaskPage(page,tmp_path)
        executor.execute({'action':'search_select','target':{'label':'Patient'},'value':'Test','option_target':{'role':'option','name':'Test Patient TEST-001'}},{})
        assert page.locator('#selected').inner_text()=='TEST-001'
        executor.execute({'action':'download','target':{'role':'link','name':'Download orders'}},{})
        assert executor.downloads[0]['filename']=='orders.csv'
        assert (tmp_path/executor.downloads[0]['id']).read_text()=='id,amount\na,1\n'
        page.set_content('<div role="option">Test Patient</div><div role="option">Test Patient</div>')
        with pytest.raises(Exception,match='strict mode violation'):
            executor._locator({'role':'option','name':'Test Patient'}).click(timeout=500)
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=3)


def test_dashboard_scripts_run_in_browser(page):
    errors=[]
    page.on('pageerror',lambda error:errors.append(str(error)))
    page.goto('about:blank')
    # A real origin is required for sessionStorage.
    page.route('http://qa.test/**',lambda route:route.fulfill(content_type='text/html',body=(main.ROOT/'web/index.html').read_text(encoding='utf-8')))
    page.goto('http://qa.test/')
    page.select_option('#reference-kind','server')
    assert page.locator('#reference-server-fields').is_visible()
    page.evaluate("renderResult({status:'PASS',download_rows:1,reference_rows:1,matched_rows:1,mismatched_cells:0,missing_from_download_count:0,missing_from_reference_count:0})")
    assert 'Downloaded rows: 1' in page.locator('#result').inner_text()
    assert errors==[]


def test_planner_and_generated_suite_keep_search_and_download(monkeypatch,tmp_path):
    from types import SimpleNamespace
    from qa_agent import llm, suites
    actions=[{'action':'search_select','target':{'label':'Patient'},'value':'Test',
              'option_target':{'role':'option','name':'Test Patient TEST-001'}},
             {'action':'download','target':{'role':'button','name':'Download'}},
             {'action':'verify_text','target':{'text':'Reports'},'expected':'Reports'}]
    raw={'actions':actions}
    class Client:
        def __init__(self,**kwargs):pass
        def chat(self,**kwargs):return SimpleNamespace(message=SimpleNamespace(content=json.dumps(raw)))
    monkeypatch.setattr(llm,'Client',Client)
    monkeypatch.setenv('LLM_PROVIDER','ollama')
    assert llm.plan_browser_task('Search and download',{},False)['actions']==actions
    raw={'test_cases':[{'id':'TC-01','name':'Search and export','steps':actions}]}
    cases=llm.generate_regression_cases('Test','Search for Test Patient and download report')
    assert cases[0]['steps'][0]['option_target']==actions[0]['option_target']
    source=suites._test_source('example',cases)
    compile(source,'generated_test','exec')
    (tmp_path/'suite').mkdir()
    (tmp_path/'suite/suite_config.json').write_text('{}')
    namespace={'__file__':str(tmp_path/'suite/pages/base_page.py')}
    exec(suites._page_object_source(),namespace)
    calls=[]
    base=namespace['BasePage'](None)
    base.task_executor=SimpleNamespace(execute=lambda step,credentials:calls.append(step))
    base.perform(cases[0]['steps'][0])
    base.perform(cases[0]['steps'][1])
    assert [step['action'] for step in calls]==['search_select','download']


def test_runtime_settings_api_persists_and_validates(monkeypatch,tmp_path):
    from qa_agent import settings
    monkeypatch.setattr(settings,'SETTINGS_PATH',tmp_path/'runtime.json')
    monkeypatch.setenv('QA_API_TOKEN','settings-test')
    client=TestClient(main.app)
    headers={'Authorization':'Bearer settings-test'}
    assert client.get('/qa/settings').status_code==401
    current=client.get('/qa/settings',headers=headers).json()
    assert current['browser']=='chromium' and current['headless'] is False
    values=current['settings']
    values.update(target_url='https://example.test',max_report_rows=2,report_detail_limit=1)
    saved=client.put('/qa/settings',headers=headers,json=values)
    assert saved.status_code==200
    assert settings.get_settings().target_url=='https://example.test'
    with pytest.raises(ValueError,match='exceeds 2'):
        r.table(['id'],[['a'],['b'],['c']])
    result=r.compare_tables(data([['a','1'],['b','1']]),data([['a','2'],['b','2']]),['id'])
    assert len(result['differences'])==1 and result['mismatched_cells']==2
    values['max_report_rows']=0
    assert client.put('/qa/settings',headers=headers,json=values).status_code==422
    values['max_report_rows']=2;values['target_url']='https://user:password@example.test'
    assert client.put('/qa/settings',headers=headers,json=values).status_code==422
    assert settings.get_settings().max_report_rows==2


def test_runtime_excel_sheet_header_and_environment_defaults(monkeypatch,tmp_path):
    from qa_agent import settings
    from openpyxl import Workbook
    monkeypatch.setattr(settings,'SETTINGS_PATH',tmp_path/'settings.json')
    monkeypatch.setenv('QA_SEARCH_TIMEOUT_MS','2345')
    assert settings.get_settings().search_timeout_ms==2345
    configured=settings.get_settings().model_copy(update={'excel_sheet':'Report','excel_header_row':2,'search_timeout_ms':4567})
    settings.save_settings(configured)
    assert settings.get_settings().search_timeout_ms==4567
    book=Workbook();book.active.title='Ignore';sheet=book.create_sheet('Report')
    sheet.append(['Title']);sheet.append(['id','amount']);sheet.append(['a',12])
    path=tmp_path/'report.xlsx';book.save(path);book.close()
    assert r.read_report(path)[1]==[{'id':'a','amount':12}]


def test_runtime_task_timeout_and_no_application_fallbacks(monkeypatch):
    from qa_agent import settings, suites
    source=suites._page_object_source()
    assert 'oxd-' not in source and 'logout_sidebar_link' not in source
    assert 'react-burger' not in source
    compile(suites._conftest_source(),'conftest','exec')
    compile(suites._application_page_source('example'),'page','exec')


def test_login_requests_do_not_require_magic_phrase():
    from qa_agent.browser import wants_saved_login
    for task in ['login','Log in and search for patient','Sign in','Authenticate','Use saved credentials']:
        assert wants_saved_login(task),task
    for task in ['Inspect this page','Do not login','Skip the login','Without signing in']:
        assert not wants_saved_login(task),task


def test_credentials_reload_and_preserve_literal_password(monkeypatch,tmp_path):
    import qa_agent.browser as browser
    monkeypatch.setattr(browser,'ROOT',tmp_path)
    env=tmp_path/'.env'
    env.write_text('QA_USERNAME=test_user\nQA_PASSWORD="  literal${UNCHANGED}  "\n')
    assert browser._settings()['password']=='  literal${UNCHANGED}  '
    env.write_text('QA_USERNAME=updated_user\nQA_PASSWORD="updated"\n')
    assert browser._settings()['username']=='updated_user'
    assert browser._settings()['password']=='updated'


def test_credentials_status_only_returns_presence_and_checkbox_requests_login(monkeypatch):
    import main
    monkeypatch.setenv('QA_API_TOKEN','credential-test')
    monkeypatch.setattr(main,'_settings',lambda:{'username':'synthetic-user','password':'synthetic-password'})
    headers={'Authorization':'Bearer credential-test'}
    client=TestClient(main.app)
    assert client.get('/qa/credentials/status').status_code==401
    response=client.get('/qa/credentials/status',headers=headers)
    assert response.json()=={'username_configured':True,'password_configured':True,'ready':True}
    assert 'synthetic' not in response.text
    tasks=[]
    async def inspect(url,task,knowledge):
        tasks.append(task)
        return {'test_cases':[], 'test_summary':{'status':'PASS'}}
    monkeypatch.setattr(main,'inspect_page',inspect)
    monkeypatch.setattr(main.knowledge_base,'search',lambda *args,**kw:[])
    result=client.post('/qa/run',headers=headers,json={'target_url':'http://example.test','question':'Inspect dashboard','use_saved_credentials':True,'include_ai':False})
    assert result.status_code==200
    assert 'Sign in using saved credentials' in tasks[0]
    assert 'synthetic' not in tasks[0]


def test_saved_credentials_fill_login_fields_without_returning_secrets(page):
    from qa_agent.pages.task_page import TaskPage
    page.set_content('<label>User<input></label><label>Password<input type="password"></label>')
    executor=TaskPage(page)
    creds={'username':'synthetic-user','password':'  synthetic-password  '}
    for label,marker in [('User','{{QA_USERNAME}}'),('Password','{{QA_PASSWORD}}')]:
        detail=executor.execute({'action':'fill','target':{'label':label},'value':marker},creds)
        assert 'synthetic' not in detail
    assert page.get_by_label('User',exact=True).input_value()==creds['username']
    assert page.get_by_label('Password',exact=True).input_value()==creds['password']
