import ast
import hashlib
import json
from pathlib import Path

import pytest

from qa_agent import execution, saved_healing


def _fixture_suite(tmp_path, mode='normal', adapter='direct'):
    suite = tmp_path / 'generated_suites' / 'sample'
    tests = suite / 'tests'
    tests.mkdir(parents=True)
    for directory in (suite.parent, suite, tests):
        (directory / '__init__.py').write_text('')
    (suite / 'suite_config.json').write_text(json.dumps({'healing_policy': {
        'safe_to_repeat': mode != 'not_reviewed', 'allow_ai_healing': True,
        'eligible_tests': ['test_missing_locator']}}))
    (suite / 'conftest.py').write_text('''import pytest
from playwright.sync_api import sync_playwright
def pytest_addoption(parser): parser.addoption('--target-url',default='')
@pytest.fixture
def page():
    with sync_playwright() as p:
        browser=p.chromium.launch(headless=True)
        page=browser.new_page()
        yield page
        browser.close()
''')
    content = '''<label for="username">Username</label><input id="username" placeholder="Enter your username">'''
    if mode == 'ambiguous':
        content += '<label for="other">Username</label><input id="other" placeholder="Other username">'
    action = 'page.get_by_placeholder("Username",exact=True).fill("demo",timeout=100)'
    if mode == 'assertion':
        action = 'page.get_by_placeholder("Enter your username",exact=True).fill("demo",timeout=100)'
    if adapter == 'pom':
        action = 'App(page).fill({"placeholder":"Username"},"demo")'
    code = '''from pathlib import Path
from playwright.sync_api import expect
class App:
    def __init__(self,page): self.page=page
    def fill(self,target,value):
        locator=self.page.locator(target['selector']) if 'selector' in target else self.page.get_by_placeholder(target['placeholder'],exact=True)
        locator.fill(value,timeout=100)
def test_stable(page):
    counter=Path(COUNTER_PATH)
    counter.write_text(str(int(counter.read_text())+1) if counter.exists() else '1')
    page.set_content('<p>Ready</p>')
    expect(page.get_by_text('Ready')).to_be_visible()
def test_missing_locator(page):
    page.set_content(CONTENT)
    DRIFT
    ACTION
    expect(page.locator('#username')).to_have_value(EXPECTED,timeout=100)
'''
    code = code.replace('COUNTER_PATH', repr(str(tmp_path / 'stable.txt'))).replace('CONTENT', repr(content))
    code = code.replace('ACTION', action).replace('EXPECTED', repr('wrong' if mode == 'assertion' else 'demo'))
    code = code.replace('DRIFT', "\n    if '.qa_runs' in __file__: page.locator('label').evaluate(\"element=>element.textContent='Different control'\")" if mode == 'drift' else 'pass')
    test_file = tests / 'test_sample_regression.py'
    test_file.write_text(code)
    return suite, test_file


@pytest.mark.parametrize('adapter', ['direct', 'pom'])
def test_complete_saved_test_healing_pipeline_preserves_source_and_assertions(monkeypatch, tmp_path, adapter):
    suite, source = _fixture_suite(tmp_path, adapter=adapter)
    original = source.read_bytes()
    calls = []
    def ai(prompt, purpose):
        calls.append((prompt, purpose))
        return json.dumps({'selector': '#username', 'reason': 'Same observed Username field, identified by its label.'})
    monkeypatch.setattr(execution, 'ROOT', tmp_path)
    monkeypatch.setattr(saved_healing, 'request_ai', ai)
    result = execution.run_generated_suite('sample', 'https://example.test', auto_heal=True)
    assert result['status'] == 'passed', result['output']
    assert result['test_summary']['status'] == 'PASS_AFTER_HEALING'
    assert result['test_summary']['healed'] == 1
    assert result['test_cases'][1]['status'] == 'HEALED'
    assert result['test_cases'][1]['first_attempt']['status'] == 'FAIL'
    assert source.read_bytes() == original
    assert (tmp_path / 'stable.txt').read_text() == '1'
    assert len(calls) == 1 and calls[0][1] == 'locator_repair'
    assert result['healing']['review_required'] is True
    assert result['healing']['proposals'][0]['status'] == 'passed_after_healing'
    copied = tmp_path / result['healing']['temporary_suite'] / 'tests/test_sample_regression.py'
    assert copied.exists() and copied.read_bytes() != original
    assert saved_healing._assertions(ast.parse(original)) == saved_healing._assertions(ast.parse(copied.read_text()))
    evidence = result['failure_evidence'][0]
    assert (tmp_path / evidence['dom_file'].lstrip('/')).is_file()
    assert (tmp_path / evidence['screenshot'].lstrip('/')).is_file()
    assert result['attempt_counts']['pytest_runs'] == 2


@pytest.mark.parametrize('mode,expected_calls', [('ambiguous', 0), ('assertion', 0), ('not_reviewed', 0), ('drift', 1), ('bad_ai', 1)])
def test_unsafe_or_invalid_repairs_never_become_a_pass(monkeypatch, tmp_path, mode, expected_calls):
    suite, source = _fixture_suite(tmp_path, mode=mode)
    original = source.read_bytes()
    calls = []
    def ai(*args):
        calls.append(args)
        return json.dumps({'selector': '#unobserved' if mode == 'bad_ai' else '#username', 'reason': 'Fixture proposal'})
    monkeypatch.setattr(execution, 'ROOT', tmp_path)
    monkeypatch.setattr(saved_healing, 'request_ai', ai)
    result = execution.run_generated_suite('sample', 'https://example.test', auto_heal=True)
    assert result['status'] == 'failed', result['output']
    assert source.read_bytes() == original
    assert len(calls) == expected_calls
    assert all(case['status'] != 'HEALED' for case in result['test_cases'])
    if mode != 'drift': assert result['automatic_rerun']['executed'] is False


def test_literal_edit_refuses_assertions_and_ambiguous_source():
    origin = {'kind': 'placeholder', 'value': 'Username', 'name': None}
    with pytest.raises(ValueError, match='assertion'):
        saved_healing.locator_edit('assert page.get_by_placeholder("Username").fill("x") is None\n', 1, origin, '#user')
    with pytest.raises(ValueError, match='ambiguous'):
        saved_healing.locator_edit('page.get_by_placeholder("Username").click();page.get_by_placeholder("Username").click()\n', 1, origin, '#user')


def test_password_repair_rejects_nonpassword_and_css_without_contract():
    record = {'node_id': 'test.py::test_x', 'phase': 'call', 'failed_locator': {'missing_before_dispatch': True,
        'operation': 'fill', 'password_value': True, 'origin': {'kind': 'placeholder', 'value': 'Password', 'locations': []}}}
    intent = saved_healing.intent_from(record, {})
    with pytest.raises(ValueError):
        saved_healing.validate_candidate(intent, {'controls': [{'selector': '#x', 'tag': 'input', 'type': 'text', 'placeholder': 'Password'}]}, '#x')
    record['failed_locator']['origin'] = {'kind': 'locator', 'value': '#old', 'locations': []}
    with pytest.raises(ValueError, match='contract'):
        saved_healing.intent_from(record, {})


def test_semantic_validation_rejects_conflicting_accessible_name_and_truncated_dom():
    intent = {'kind': 'role', 'value': 'button', 'name': 'Login', 'operation': 'click', 'password': False}
    dom = {'controls': [{'selector': '#wrong', 'tag': 'button', 'type': None, 'label': 'Delete', 'text': 'Login', 'name': 'Login'}]}
    with pytest.raises(ValueError): saved_healing.validate_candidate(intent, dom, '#wrong')
    dom['controls'][0]['label'] = 'Login'
    dom['controls_truncated'] = True
    with pytest.raises(ValueError): saved_healing.validate_candidate(intent, dom, '#wrong')


def test_source_changes_after_evidence_prevent_retry(monkeypatch, tmp_path):
    suite, source = _fixture_suite(tmp_path)
    calls = []
    def ai(*args):
        calls.append(args)
        with (suite / 'conftest.py').open('a') as handle: handle.write('\n# concurrent edit\n')
        return json.dumps({'selector': '#username', 'reason': 'Same Username field'})
    monkeypatch.setattr(execution, 'ROOT', tmp_path)
    monkeypatch.setattr(saved_healing, 'request_ai', ai)
    result = execution.run_generated_suite('sample', 'https://example.test', auto_heal=True)
    assert result['status'] == 'failed'
    assert result['automatic_rerun']['executed'] is False
    assert result['healing']['proposals'][0]['status'] == 'refused'
    assert 'changed' in result['healing']['proposals'][0]['reason']
    assert result['healing']['original_suite_unchanged'] is False


def test_final_report_escapes_page_and_model_text(tmp_path):
    from qa_agent.final_report import write_final_report
    result = {'status': 'failed', 'test_cases': [{'name': '<script>alert(1)</script>', 'status': 'FAIL', 'details': '<img src=x onerror=alert(1)>'}],
              'healing': {'proposals': [{'node_id': 'test_x', 'status': 'refused', 'reason': '<script>bad</script>'}]}}
    url = write_final_report(tmp_path, 'sample', result)
    content = (tmp_path / url.lstrip('/')).read_text()
    assert '<script>' not in content
    assert '&lt;script&gt;' in content


def test_saved_suite_listing_is_protected_and_skips_invalid_config(monkeypatch, tmp_path):
    import main
    from fastapi.testclient import TestClient
    root = tmp_path / 'generated'
    for name, config in [('good', {'target_url': 'https://example.test', 'healing_policy': {'safe_to_repeat': True, 'allow_ai_healing': True, 'eligible_tests': ['test_one']}}), ('bad', [])]:
        suite = root / name
        (suite / 'tests').mkdir(parents=True)
        (suite / 'tests' / f'test_{name}_regression.py').write_text('def test_one(): pass')
        (suite / 'suite_config.json').write_text(json.dumps(config))
    monkeypatch.setattr(main, 'GENERATED_DIR', root)
    monkeypatch.setenv('QA_API_TOKEN', 'suite-list-test')
    client = TestClient(main.app)
    assert client.get('/qa/suites').status_code == 401
    response = client.get('/qa/suites', headers={'Authorization': 'Bearer suite-list-test'})
    assert response.json()['suites'] == [{'slug': 'good', 'target_url': 'https://example.test', 'test_functions': 1, 'healing_reviewed': True}]


def test_saved_healing_api_passes_explicit_opt_in(monkeypatch):
    import main
    from fastapi.testclient import TestClient
    calls = []
    def run(slug, url, **options):
        calls.append(options)
        return {'status': 'passed', 'exit_code': 0, 'output': 'Fixture'}
    monkeypatch.setattr(main, 'run_generated_suite', run)
    monkeypatch.setenv('QA_API_TOKEN', 'healing-api-test')
    response = TestClient(main.app).post('/qa/suite/sample/run', headers={'Authorization': 'Bearer healing-api-test'},
        json={'target_url': 'https://example.test', 'auto_heal': True})
    assert response.status_code == 200
    assert calls == [{'auto_rerun': False, 'auto_heal': True}]
