import hashlib
import json
from pathlib import Path
import sqlite3
import zipfile

from scripts.prepare_transfer import build_package


def test_transfer_excludes_private_files_and_preserves_committed_usage(tmp_path):
    (tmp_path/'main.py').write_text('print("app")')
    (tmp_path/'.env.example').write_text('OPENAI_API_KEY=\n')
    (tmp_path/'.env').write_text('OPENAI_API_KEY=private-key')
    for name in ['runtime_settings.json','report_sources.json','downloads/report.csv',
                 '.venv/secrets.py','qa_agent/__pycache__/secret.py',
                 'generated_suites/demo/verified_locators.json','reports/raw.html']:
        path=tmp_path/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_text('private-data')
    for name in ['qa_agent/waits.py','generated_suites/demo/suite_config.json',
                 'reports/REPLAY_WAIT_FIX_REPORT.md','README.md']:
        path=tmp_path/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_text('{}')
    ledger=tmp_path/'usage/openai.sqlite3';ledger.parent.mkdir()
    with sqlite3.connect(ledger) as db:
        db.execute('PRAGMA journal_mode=WAL')
        db.execute('CREATE TABLE calls(charged INTEGER)')
        db.execute('INSERT INTO calls VALUES(12345)');db.commit()
        result=build_package(tmp_path)
    with zipfile.ZipFile(result['archive']) as archive:
        names=archive.namelist()
        assert '.env' not in names and 'runtime_settings.json' not in names
        assert 'generated_suites/demo/verified_locators.json' not in names
        assert 'reports/raw.html' not in names and 'downloads/report.csv' not in names
        assert archive.read('.env.example')==(tmp_path/'.env.example').read_bytes()
        assert b'private-key' not in b''.join(archive.read(name) for name in names)
        manifest=json.loads(archive.read('TRANSFER_MANIFEST.json'))
        assert manifest['usage_ledger_included'] is True
        for item in manifest['files']:
            assert hashlib.sha256(archive.read(item['file'])).hexdigest()==item['sha256']
        restored_file=tmp_path/'restored.sqlite3'
        restored_file.write_bytes(archive.read('usage/openai.sqlite3'))
        with sqlite3.connect(restored_file) as restored:
            assert restored.execute('SELECT charged FROM calls').fetchone()[0]==12345
            assert restored.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
    assert Path(result['archive']).with_suffix('.zip.sha256').is_file()
