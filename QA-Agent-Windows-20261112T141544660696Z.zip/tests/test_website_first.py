import ast
import asyncio
import json
from concurrent.futures import ThreadPoolExecutor

import pytest
from fastapi.testclient import TestClient

import main
from qa_agent import suites
from qa_agent.website_first import discover_suite


def run(coroutine):
    # The session-scoped synchronous Playwright fixture owns the main thread's loop.
    with ThreadPoolExecutor(max_workers=1) as pool:
        return pool.submit(asyncio.run, coroutine).result()


def case(name='Login', expected='Dashboard', saved=True):
    return main.DiscoveryCaseRequest(name=name, steps='Perform the requested scenario',
                                     expected_text=expected, use_saved_credentials=saved)


def observed(expected='Dashboard', status='PASS', final_action=True):
    actions = [{'action': 'verify_text', 'target': {'selector': 'h1'}, 'expected': expected}]
    if not final_action: actions.append({'action': 'click', 'target': {'selector': '#logout'}})
    return {'test_summary': {'status': status}, 'task_plan': actions, 'test_cases': [],
            'discovery': {'counts': {'browser_sessions': 1, 'pytest_runs': 0}},
            'discovery_manifest': '/reports/discovery-fixture/discovery.json'}


def test_independent_observed_cases_saved_only_after_verification(monkeypatch, tmp_path):
    destination = tmp_path/'generated_suites'
    monkeypatch.setattr(suites, 'GENERATED_DIR', destination)
    calls = []
    async def inspect(url, task, knowledge, **kwargs):
        assert not destination.exists()  # No Python suite is written before discovery ends.
        calls.append(task)
        return observed('Dashboard' if len(calls) == 1 else 'Invalid credentials')
    result = run(discover_suite('OrangeHRM', 'https://example.test',
        [case(), case('Invalid login', 'Invalid credentials', False)], inspect, [], tmp_path))
    assert result['test_summary'] == {'status': 'PASS', 'passed': 2, 'failed': 0, 'skipped': 0, 'total': 2}
    assert result['attempt_counts']['pytest_runs'] == 0
    assert result['attempt_counts']['browser_sessions'] == 2
    assert all('runner closes the browser' in task for task in calls)
    assert 'Do not use saved credentials.' in calls[1]
    folder = destination/result['generated_suite']['slug']
    tree = ast.parse(next((folder/'tests').glob('test_*.py')).read_text())
    assert len([node for node in tree.body if isinstance(node, ast.FunctionDef)]) == 2
    assert json.loads((folder/'cases.json').read_text())[1]['steps'][-1]['expected'] == 'Invalid credentials'
    assert (folder/'verified_locators.json').exists()
    assert 'pytest replay pending' in (tmp_path/result['final_report'].lstrip('/')).read_text()
    for file in folder.rglob('*.py'): compile(file.read_text(), str(file), 'exec')


@pytest.mark.parametrize('response', [observed('Other text'), observed(status='FAIL'), observed(final_action=False)])
def test_incomplete_or_wrong_final_assertion_refuses_to_save(monkeypatch, tmp_path, response):
    destination = tmp_path/'generated_suites'
    monkeypatch.setattr(suites, 'GENERATED_DIR', destination)
    async def inspect(*args, **kwargs): return response
    result = run(discover_suite('App', 'https://example.test', [case()], inspect, [], tmp_path))
    assert result['test_summary']['failed'] == 1
    assert result['generated_suite'] is None
    assert not destination.exists()


def test_error_does_not_prevent_other_independent_cases_or_leak_details(monkeypatch, tmp_path):
    monkeypatch.setattr(suites, 'GENERATED_DIR', tmp_path/'generated_suites')
    calls = []
    async def inspect(*args, **kwargs):
        calls.append(1)
        if len(calls) == 1: raise ValueError('synthetic-secret-value')
        return observed()
    result = run(discover_suite('App', 'https://example.test', [case(), case()], inspect, [], tmp_path))
    assert len(calls) == 2
    assert result['test_summary']['failed'] == 1
    assert result['generated_suite'] is None
    assert 'synthetic-secret-value' not in json.dumps(result)


def test_discovery_api_validates_and_requires_authorization(monkeypatch):
    monkeypatch.setenv('QA_API_TOKEN', 'website-first-test')
    client = TestClient(main.app)
    payload = {'target_url': 'https://example.test', 'cases': [case().model_dump()]}
    assert client.post('/qa/discover-suite', json=payload).status_code == 401
    headers = {'Authorization': 'Bearer website-first-test'}
    assert client.post('/qa/discover-suite', headers=headers, json={**payload, 'cases': []}).status_code == 422
    assert client.post('/qa/discover-suite', headers=headers, json={**payload, 'target_url': 'file:///secret'}).status_code == 400


@pytest.mark.parametrize('size,expected_pass', [(10,True),(0,False),(None,False)])
def test_single_download_outcome_requires_actual_nonempty_file_evidence(monkeypatch,tmp_path,size,expected_pass):
    monkeypatch.setattr(suites,'GENERATED_DIR',tmp_path/'generated_suites')
    download_case=main.DiscoveryCaseRequest(name='Measure report',steps='Select the requested filters and download the report',
                                          expected_outcome='nonempty_download')
    async def inspect(url,task,knowledge,**kwargs):
        assert 'verify visible text' not in task
        assert kwargs['terminal_outcome']['kind']=='nonempty_download'
        assert kwargs['heal_locators'] is False
        response=observed()
        response['task_plan']=[{'action':'download','target':{'selector':'#download'}}]
        response['downloads']=[] if size is None else [{'bytes':size,'id':'fixture.csv'}]
        return response
    result=run(discover_suite('RMM','https://example.test',[download_case],inspect,[],tmp_path,heal_locators=False))
    assert result['test_summary']['passed']==int(expected_pass)
    assert bool(result['generated_suite']) is expected_pass
    if expected_pass:
        source=next((tmp_path/'generated_suites'/result['generated_suite']['slug']/'tests').glob('test_*.py')).read_text()
        assert len([node for node in ast.parse(source).body if isinstance(node,ast.FunctionDef)])==1
        assert "'action': 'download'" in source


def test_live_website_first_discovers_then_runs_separate_pytest_cases(monkeypatch, tmp_path):
    from functools import partial
    from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
    from threading import Thread
    from qa_agent import browser, execution
    site = tmp_path/'site'
    site.mkdir()
    (site/'index.html').write_text('<h1>Ready</h1><button id="go" onclick="document.querySelector(\'h1\').textContent=\'Complete\'">Go</button>')
    server = ThreadingHTTPServer(('127.0.0.1', 0), partial(SimpleHTTPRequestHandler, directory=str(site)))
    thread = Thread(target=server.serve_forever, daemon=True)
    thread.start()
    monkeypatch.setattr(suites, 'GENERATED_DIR', tmp_path/'generated_suites')
    monkeypatch.setattr(browser, 'REPORT_DIR', tmp_path/'reports')
    monkeypatch.setattr(main, 'ROOT', tmp_path)
    monkeypatch.setattr(execution, 'ROOT', tmp_path)
    monkeypatch.setenv('QA_API_TOKEN', 'live-website-test')
    monkeypatch.setattr(main.knowledge_base, 'search', lambda *args, **kwargs: [])
    seen = []
    def planner(task, state, allow, knowledge):
        seen.append((task, len(state['completed_actions'])))
        completed = state['completed_actions']
        if 'Complete flow' in task and not completed:
            return {'actions': [{'action': 'click', 'target': {'selector': '#go'}}]}
        if not completed or completed[-1]['action'] != 'verify_text':
            return {'actions': [{'action': 'verify_text', 'target': {'selector': '#go'},
                                 'expected': 'Complete' if 'Complete flow' in task else 'Ready'}]}
        return {'done': True, 'actions': []}
    monkeypatch.setattr(browser, 'plan_browser_task', planner)
    url = f'http://127.0.0.1:{server.server_port}/'
    try:
        response = TestClient(main.app).post('/qa/discover-suite',
            headers={'Authorization': 'Bearer live-website-test'}, json={
                'application': 'Website fixture', 'target_url': url, 'cases': [
                    case('Complete flow', 'Complete', False).model_dump(),
                    case('Initial page', 'Ready', False).model_dump()]})
        assert response.status_code == 200, response.text
        result = response.json()
        assert result['test_summary']['passed'] == 2, result
        assert result['attempt_counts']['pytest_runs'] == 0
        assert result['attempt_counts']['browser_sessions'] == 2
        plan_calls = len(seen)
        replay = execution.run_generated_suite(result['generated_suite']['slug'], url)
        assert replay['test_summary']['passed'] == 2, replay['output']
        assert replay['test_summary']['failed'] == 0
        assert len(seen) == plan_calls  # Replay uses saved actions, not fresh AI planning.
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=3)


def test_live_single_download_discovery_saves_and_replays_nonempty_report(monkeypatch,tmp_path):
    from functools import partial
    from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
    from threading import Thread
    from qa_agent import browser,execution
    site=tmp_path/'site';site.mkdir()
    (site/'index.html').write_text('<a id="download" href="report.csv" download>Download Report</a>')
    (site/'report.csv').write_text('measure,count\nTEST,3\n')
    server=ThreadingHTTPServer(('127.0.0.1',0),partial(SimpleHTTPRequestHandler,directory=str(site)))
    thread=Thread(target=server.serve_forever,daemon=True);thread.start()
    monkeypatch.setattr(suites,'GENERATED_DIR',tmp_path/'generated_suites')
    monkeypatch.setattr(browser,'REPORT_DIR',tmp_path/'reports')
    monkeypatch.setattr(main,'ROOT',tmp_path)
    monkeypatch.setattr(execution,'ROOT',tmp_path)
    monkeypatch.setenv('QA_API_TOKEN','download-test')
    monkeypatch.setattr(main.knowledge_base,'search',lambda *a,**kw:[])
    calls=[]
    def planner(*args):
        calls.append(1)
        if len(calls)>1:raise AssertionError('An executed terminal download needs no AI completion call')
        return {'actions':[{'action':'download','target':{'selector':'#download'}}]}
    monkeypatch.setattr(browser,'plan_browser_task',planner)
    url=f'http://127.0.0.1:{server.server_port}/'
    try:
        response=TestClient(main.app).post('/qa/discover-suite',headers={'Authorization':'Bearer download-test'},json={
            'application':'Download fixture','target_url':url,'cases':[{'name':'Download report',
            'steps':'Click the requested Download Report link and save a nonempty file','expected_outcome':'nonempty_download'}]})
        assert response.status_code==200,response.text
        data=response.json()
        assert data['test_summary']['passed']==1,data
        assert data['downloads'][0]['bytes']>0
        assert len(calls)==1
        replay=execution.run_generated_suite(data['generated_suite']['slug'],url)
        assert replay['test_summary']['passed']==1,replay['output']
        assert replay['downloads'][0]['bytes']>0
        assert not replay['failure_evidence']
    finally:
        server.shutdown();server.server_close();thread.join(timeout=3)


def test_single_case_planning_refuses_split_cases_and_keeps_download_assertion(monkeypatch):
    from qa_agent import llm,openai_provider
    monkeypatch.setenv('LLM_PROVIDER','openai')
    payload={'test_cases':[{'id':'RMM-1','name':'Full report workflow','steps':[{
        'action':'download','target':{'role':'link','name':'Download Report'}}]}]}
    prompts=[]
    def generate(prompt,purpose):
        prompts.append(prompt)
        return json.dumps(payload)
    monkeypatch.setattr(openai_provider,'generate',generate)
    cases=llm.generate_regression_cases('RMM','One end-to-end report workflow',single_case=True)
    assert len(cases)==1 and cases[0]['steps'][-1]['action']=='download'
    assert 'exactly ONE end-to-end' in prompts[0]
    payload['test_cases']*=2
    with pytest.raises(ValueError,match='single end-to-end'):
        llm.generate_regression_cases('RMM','One report workflow',single_case=True)
